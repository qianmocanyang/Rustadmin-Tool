const fs = require('fs');

const src = 'C:/Users/Administrator/.cursor/projects/c-Users-Administrator-Desktop-rust-RustAdmin/agent-tools/83232988-7ccc-4b26-8d5d-0bd114e67596.txt';
const dst = 'C:/Users/Administrator/Desktop/rust/RustAdmin/renderer/rust_items.json';

function inferCategory(shortname) {
  const s = String(shortname || '').toLowerCase();
  if (s.startsWith('ammo.') || s.startsWith('arrow.') || s.includes('rocket')) return 'Ammunition';
  if (s.startsWith('rifle.') || s.startsWith('pistol.') || s.startsWith('smg.') || s.startsWith('shotgun.') || s.startsWith('lmg.') || s.startsWith('bow.') || s.startsWith('crossbow')) return 'Weapon';
  if (s.startsWith('attire.') || s.startsWith('mask.') || s.startsWith('hat.') || s.startsWith('shirt.') || s.startsWith('pants.') || s.startsWith('hoodie.') || s.startsWith('shoes.') || s.startsWith('jacket.') || s.startsWith('gloves.') || s.startsWith('armor.')) return 'Attire';
  if (s.includes('syringe') || s.includes('med') || s.includes('bandage')) return 'Medical';
  if (s.includes('ore') || s.includes('wood') || s.includes('stones') || s.includes('metal') || s.includes('sulfur') || s.includes('scrap')) return 'Resources';
  return 'Misc';
}

const raw = fs.readFileSync(src, 'utf8');
const lines = raw.split(/\r?\n/);
const parsed = [];

for (let i = 0; i < lines.length; i++) {
  const line = lines[i].trim();
  if (!line.startsWith('### ')) continue;
  const name = line.slice(4).trim();
  let shortname = '';
  let id = '';
  for (let j = i + 1; j < Math.min(i + 12, lines.length); j++) {
    const t = lines[j].trim();
    if (!shortname) {
      const m = t.match(/^([a-zA-Z0-9._-]+)已复制$/);
      if (m) shortname = m[1];
    }
    if (!id) {
      const m = t.match(/^(-?\d+)已复制$/);
      if (m) id = m[1];
    }
    if (shortname && id) break;
  }
  if (!shortname) continue;
  parsed.push({
    id: id || '',
    image: `https://rustlabs.com/img/items180/${shortname}.png`,
    displayName: name,
    shortName: shortname,
    category: inferCategory(shortname)
  });
}

let existing = [];
try {
  existing = JSON.parse(fs.readFileSync(dst, 'utf8'));
} catch {}

const map = new Map();
for (const it of parsed) {
  if (!map.has(it.shortName)) map.set(it.shortName, it);
}
for (const row of existing) {
  const sn = String(row.shortName || row.shortname || '').trim();
  if (!sn) continue;
  if (!map.has(sn)) {
    map.set(sn, {
      id: String(row.id ?? ''),
      image: row.image || `https://rustlabs.com/img/items180/${sn}.png`,
      displayName: row.displayName || row.name || sn,
      shortName: sn,
      category: row.category || inferCategory(sn)
    });
  } else {
    const cur = map.get(sn);
    if (row.image) cur.image = row.image;
    if (row.category) cur.category = row.category;
    if (row.id != null && String(row.id).trim()) cur.id = String(row.id);
  }
}

const out = [...map.values()].sort((a, b) => a.displayName.localeCompare(b.displayName, 'en'));
fs.writeFileSync(dst, JSON.stringify(out, null, 2));
console.log(`parsed=${parsed.length}, merged=${out.length}`);
