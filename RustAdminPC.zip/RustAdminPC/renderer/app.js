/* ===== RustAdmin app.js - Facepunch风格界面逻辑 ===== */

const api = window.rustAPI;

// ===== 状态 =====
let state = {
  connected: false,
  currentServer: null,
  players: [],
  offlinePlayers: [],
  serverHostname: null,
  maxPlayers: null,
  serverNameFallback: null,
  cmdHistory: [],
  chatLog: [],
  consoleLines: [],
  chatChannel: 'all',
  consoleFilter: 'all',
  // Steam 封禁信息缓存（用于在线玩家表格内的点击详情）
  // 结构: { [steamid]: { count, daysSinceLastBan, games: [{name}], fetchedAt } }
  steamGameBanInfoCache: {},
  // IP 地理位置缓存（用于在线玩家表格“所在地区”列）
  // 结构: { [ip]: { locationText, fetchedAt } }
  ipGeoCache: {},
  joiningCount: 0,
  queueCount: 0,
};
let currentContextPlayer = null;
let currentBanTarget = null;
const PLAYER_META_KEY = 'rustadmin.playerMeta';
const PLAYER_HISTORY_KEY = 'rustadmin.playerHistory';

function ensureStartupPopupsHidden() {
  const ids = [
    'add-server-modal',
    'dev-password-modal',
    'player-modal',
    'steam-ban-modal',
    'perm-picker-modal',
    'ban-config-modal',
    'player-context-menu',
    'dev-config-panel',
    'dev-password-error',
  ];
  ids.forEach((id) => {
    const el = document.getElementById(id);
    if (el) el.style.display = 'none';
  });
  const devModal = document.querySelector('.dev-modal');
  if (devModal) devModal.style.display = 'block';
}
ensureStartupPopupsHidden();

function loadPlayerMetaStore() {
  try { return JSON.parse(localStorage.getItem(PLAYER_META_KEY) || '{}') || {}; } catch { return {}; }
}
function savePlayerMetaStore(data) {
  localStorage.setItem(PLAYER_META_KEY, JSON.stringify(data || {}));
}
function getPlayerMeta(steamid) {
  const sid = String(steamid || '').trim();
  if (!sid) return {};
  const store = loadPlayerMetaStore();
  return store[sid] || {};
}
function setPlayerMeta(steamid, patch) {
  const sid = String(steamid || '').trim();
  if (!sid) return;
  const store = loadPlayerMetaStore();
  store[sid] = { ...(store[sid] || {}), ...(patch || {}) };
  savePlayerMetaStore(store);
}
function clearPlayerMeta(steamid) {
  const sid = String(steamid || '').trim();
  if (!sid) return;
  const store = loadPlayerMetaStore();
  delete store[sid];
  savePlayerMetaStore(store);
}
function loadPlayerHistoryStore() {
  try { return JSON.parse(localStorage.getItem(PLAYER_HISTORY_KEY) || '{}') || {}; } catch { return {}; }
}
function savePlayerHistoryStore(data) {
  localStorage.setItem(PLAYER_HISTORY_KEY, JSON.stringify(data || {}));
}
function addPlayerHistory(steamid, action, detail = '') {
  const sid = String(steamid || '').trim();
  if (!sid) return;
  const store = loadPlayerHistoryStore();
  const arr = Array.isArray(store[sid]) ? store[sid] : [];
  arr.unshift({ time: new Date().toISOString(), action, detail: String(detail || '') });
  store[sid] = arr.slice(0, 100);
  savePlayerHistoryStore(store);
}

function localizeGeoParts(parts) {
  const map = {
    china: '中国',
    'united states': '美国',
    usa: '美国',
    us: '美国',
    'hong kong': '中国香港',
    macao: '中国澳门',
    taiwan: '中国台湾',

    guangdong: '广东',
    guangzhou: '广州',
    shanghai: '上海',
    beijing: '北京',
    shenzhen: '深圳',
    zhejiang: '浙江',
    hangzhou: '杭州',
    jiangsu: '江苏',
    nanjing: '南京',
    fujian: '福建',
    xiamen: '厦门',

    'new york': '纽约',
    california: '加利福尼亚',
    'los angeles': '洛杉矶',
  };

  return (parts || []).map((p) => {
    const key = String(p || '').trim().toLowerCase();
    return map[key] || (p || '');
  });
}

function formatGeoText(locationText) {
  const raw = String(locationText || '').trim();
  if (!raw) return '-';
  const parts = raw.split('/').map((s) => s.trim()).filter(Boolean);
  if (!parts.length) return raw;

  // 只保留“第一段 + 最后一段”
  const keep = parts.length === 1 ? [parts[0]] : [parts[0], parts[parts.length - 1]];
  const localized = localizeGeoParts(keep).filter(Boolean);
  return localized.join('');
}

// ===== Toast 通知 =====
function toast(msg, type = 'info', dur = 3000) {
  const c = document.getElementById('toast-container');
  const el = document.createElement('div');
  el.className = `toast ${type}`;
  el.textContent = msg;
  c.appendChild(el);
  setTimeout(() => {
    el.style.animation = 'toast-in 0.3s ease reverse forwards';
    setTimeout(() => el.remove(), 300);
  }, dur);
}

// ===== 窗口控制 =====
document.getElementById('btn-min')?.addEventListener('click', () => api?.windowMinimize?.());
document.getElementById('btn-max')?.addEventListener('click', () => api?.windowMaximize?.());
document.getElementById('btn-close')?.addEventListener('click', () => api?.windowClose?.());

function safeCall(label, fn) {
  try {
    fn();
  } catch (e) {
    console.error('[RustAdmin]', label, e);
    toast(`${label} 出错，请打开开发者工具查看控制台`, 'error');
  }
}

// ===== Tab 切换 =====
document.querySelectorAll('.tab-btn').forEach(btn => {
  btn.addEventListener('click', () => {
    document.querySelectorAll('.tab-btn').forEach(b => b.classList.remove('active'));
    document.querySelectorAll('.tab-panel').forEach(p => p.classList.remove('active'));
    btn.classList.add('active');
    const panel = document.getElementById('panel-' + btn.dataset.tab);
    if (panel) panel.classList.add('active');
    const tab = btn.dataset.tab;
    if (tab === 'players') safeCall('在线玩家', () => refreshPlayers());
    if (tab === 'bans') safeCall('封禁记录', () => refreshBans());
    if (tab === 'groups') safeCall('权限组', () => refreshGroups());
    if (tab === 'allplugins') safeCall('插件列表', () => refreshPlugins());
    if (tab === 'offline') safeCall('离线玩家', () => refreshOfflinePlayers());
    if (tab === 'playerperm') safeCall('玩家授权', () => { refreshPermOnline(); refreshPermOffline(); renderPermGrid(); });
    if (tab === 'serverconfig') safeCall('服务器配置', () => loadServerConfigSnapshot());
    if (tab === 'admincmds') safeCall('管理员指令', () => renderAdminCommands());
    if (tab === 'itemshop') safeCall('物品发放', () => initItemShop());
    if (tab === 'battle') safeCall('战斗记录', () => {});
    if (tab === 'usagelog') {
      loadUsageLog().catch(e => {
        console.error('[RustAdmin] 使用日志', e);
        toast('使用日志加载失败，请查看控制台', 'error');
      });
    }
  });
});

// ===== 服务器管理 =====
async function loadServerList() {
  const data = await api.getServers();
  const sel = document.getElementById('server-select');
  sel.innerHTML = '<option value="">-- 选择服务器 --</option>';
  (data.servers || []).forEach(s => {
    const opt = document.createElement('option');
    opt.value = s.Name;
    opt.textContent = s.Name;
    sel.appendChild(opt);
  });
  if (data.lastSelected) {
    sel.value = data.lastSelected;
    const srv = (data.servers || []).find(s => s.Name === data.lastSelected);
    if (srv) fillServerBar(srv);
  }
}

function fillServerBar(srv) {
  document.getElementById('server-ip').value = srv.IpAddress || '';
  document.getElementById('server-port').value = srv.RconPort || 28016;
  document.getElementById('server-pass').value = srv.RconPassword || '';
}

document.getElementById('server-select').onchange = async function() {
  const name = this.value;
  if (!name) return;
  const data = await api.getServers();
  const srv = (data.servers || []).find(s => s.Name === name);
  if (srv) { fillServerBar(srv); await api.setLastServer(name); }
};

// 添加服务器
document.getElementById('btn-add-server').onclick = () => {
  document.getElementById('new-srv-name').value = '';
  document.getElementById('new-srv-ip').value = document.getElementById('server-ip').value || '';
  document.getElementById('new-srv-port').value = document.getElementById('server-port').value || '28016';
  document.getElementById('new-srv-pass').value = '';
  document.getElementById('add-server-modal').style.display = 'flex';
};
document.getElementById('btn-cancel-modal').onclick = () => { document.getElementById('add-server-modal').style.display = 'none'; };
document.getElementById('btn-cancel-add-server').onclick = () => { document.getElementById('add-server-modal').style.display = 'none'; };
document.getElementById('btn-confirm-add-server').onclick = async () => {
  const name = document.getElementById('new-srv-name').value.trim();
  const ip = document.getElementById('new-srv-ip').value.trim();
  const port = parseInt(document.getElementById('new-srv-port').value) || 28016;
  const pass = document.getElementById('new-srv-pass').value;
  if (!name || !ip) { toast('请填写服务器名称和IP', 'error'); return; }
  await api.saveServer({ Name: name, IpAddress: ip, RconPort: port, RconPassword: pass });
  await loadServerList();
  document.getElementById('server-select').value = name;
  document.getElementById('add-server-modal').style.display = 'none';
  toast(`服务器 "${name}" 已保存`, 'success');
};

// 连接
document.getElementById('btn-connect').onclick = async () => {
  const ip = document.getElementById('server-ip').value.trim();
  const port = parseInt(document.getElementById('server-port').value) || 28016;
  const pass = document.getElementById('server-pass').value;
  if (!ip || !pass) { toast('请填写服务器地址和密码', 'error'); return; }
  const name = document.getElementById('server-select').value || ip;
  state.currentServer = { Name: name, IpAddress: ip, RconPort: port, RconPassword: pass };
  setStatusConnecting();
  await api.rconConnect(state.currentServer);
};

document.getElementById('btn-disconnect').onclick = async () => {
  await api.rconDisconnect();
  state.connected = false;
  setStatusDisconnected();
  toast('已断开服务器连接', 'info');
};

// ===== RCON 状态 =====
function setStatusConnecting() {
  document.getElementById('conn-dot').className = 'conn-dot connecting';
  document.getElementById('conn-text').textContent = '连接中...';
}
function setStatusConnected(serverName) {
  document.getElementById('conn-dot').className = 'conn-dot connected';
  state.serverNameFallback = serverName;
  state.connected = true;
  updateConnText();
  document.getElementById('btn-connect').style.display = 'none';
  document.getElementById('btn-disconnect').style.display = '';
}
function setStatusDisconnected(msg) {
  document.getElementById('conn-dot').className = 'conn-dot';
  document.getElementById('conn-text').textContent = msg || '未连接';
  state.connected = false;
  state.serverHostname = null;
  state.maxPlayers = null;
  state.serverNameFallback = null;
  document.getElementById('btn-connect').style.display = '';
  document.getElementById('btn-disconnect').style.display = 'none';
  const joiningEl = document.getElementById('stat-joining');
  const queueEl = document.getElementById('stat-queue');
  if (joiningEl) joiningEl.textContent = '0';
  if (queueEl) queueEl.textContent = '0';
}

function updateConnText() {
  const el = document.getElementById('conn-text');
  if (!el) return;

  const hn = state.serverHostname || state.serverNameFallback || '';
  // 顶部只显示服务器名称本身
  el.textContent = hn || '';
}

api.onRconStatus((status) => {
  if (status.connected) {
    setStatusConnected(status.server);
    // 连接成功提示只显示服务器名称
    toast(`${status.server}`, 'success');
    refreshPlayers();
    setTimeout(() => pollServerStats(), 600);
  } else {
    setStatusDisconnected(status.error || '未连接');
    if (status.error && status.error !== '已手动断开') toast(`连接断开: ${status.error}`, 'error');
  }
});

api.onRconServerMeta((meta) => {
  if (!meta) return;
  if (meta.hostname != null) state.serverHostname = String(meta.hostname);
  // 只展示服务器名称，maxPlayers 暂不使用
  if (state.connected) updateConnText();
});

api.onRconReconnecting(() => {
  setStatusConnecting();
  document.getElementById('conn-text').textContent = '重连中...';
});

// ===== 控制台 =====
const consoleArea = document.getElementById('console-area');
const MAX_CONSOLE_LINES = 2000;

function classifyLine(text) {
  const t = (text || '').toLowerCase();
  if (t.includes('[chat]') || t.includes('say ') || t.includes('聊天')) return 'type-chat';
  if (
    t.includes('joined') || t.includes('entering') || t.includes('connected') ||
    t.includes('加入') || t.includes('进入服务器') || t.includes('上线')
  ) return 'type-join';
  if (
    t.includes('disconnected') || t.includes('leaving') ||
    t.includes('离开') || t.includes('退出服务器') || t.includes('下线')
  ) return 'type-leave';
  if (
    t.includes('killed') || t.includes('died') || t.includes('was shot') ||
    t.includes('击杀') || t.includes('被击杀') || t.includes('死亡')
  ) return 'type-kill';
  if (t.includes('error') || t.includes('exception') || t.includes('错误') || t.includes('失败')) return 'type-error';
  if (t.includes('warning') || t.includes('warn') || t.includes('警告')) return 'type-warn';
  return 'type-normal';
}

function renderConsoleLine(line) {
  const { ts, text, cls } = line;
  const el = document.createElement('div');
  el.className = `console-line ${cls}`;
  el.dataset.type = cls;
  el.innerHTML = `<span class="ts">${ts}</span>${escHtml(text)}`;
  return el;
}

api.onRconConsole((data) => {
  const text = data.text || '';
  if (!text.trim()) return;

  // 控制台噪声过滤：定时拉取的 FPS/Entities 回包不需要出现在“控制台”面板
  const t = String(text);
  // 仅精确过滤状态轮询相关噪音，避免误杀正常日志
  const isFpsNoise = /(?:^|\s)(?:server\.fps\b|["']server\.fps["']\s*[=:])|^\s*\d+(?:\.\d+)?\s*fps\s*$/i.test(t);
  const isEntitiesNoise =
    /(?:^|\s)(?:server\.entities\b|["']server\.entities["']\s*[=:])|^\s*entities?\s*[:=]\s*\d+\s*$/i.test(t);

  const isPlayerListNoise =
    /^\s*\[\s*\{[\s\S]*\}\s*\]\s*$/.test(t) &&
    /"SteamID"\s*:\s*"?\d{10,}"?/i.test(t);

  if (isFpsNoise || isEntitiesNoise || isPlayerListNoise) return;

  const cls = classifyLine(text);
  const ts = new Date().toLocaleTimeString('zh-CN', { hour12: false });
  const lineData = { ts, text, cls };
  state.consoleLines.push(lineData);

  if (!consoleArea) return;
  const el = renderConsoleLine(lineData);
  consoleArea.appendChild(el);

  if (state.consoleLines.length > MAX_CONSOLE_LINES) {
    state.consoleLines.shift();
    if (consoleArea.firstChild) consoleArea.removeChild(consoleArea.firstChild);
  }
  applyConsoleFilter();
  if (document.getElementById('auto-scroll')?.checked) {
    consoleArea.scrollTop = consoleArea.scrollHeight;
  }

  // 在线玩家列表：仅在“玩家加入/离开”时按需刷新一次（去抖）
  if (state.connected && (cls === 'type-join' || cls === 'type-leave')) {
    schedulePlayersRefresh();
  }
});

let playersRefreshTimer = null;
function schedulePlayersRefresh() {
  if (playersRefreshTimer) clearTimeout(playersRefreshTimer);
  playersRefreshTimer = setTimeout(() => {
    playersRefreshTimer = null;
    refreshPlayers().catch(() => {});
  }, 1200);
}

// 控制台过滤器（仅绑定 #panel-console，避免与「使用日志」等面板的 .filter-btn 冲突导致全局状态错乱、点击无响应）
function applyConsoleFilter() {
  if (!consoleArea) return;
  const filter = state.consoleFilter || 'all';
  const searchEl = document.getElementById('console-search');
  const search = (searchEl && searchEl.value) ? searchEl.value.toLowerCase() : '';
  consoleArea.querySelectorAll('.console-line').forEach(el => {
    const matchFilter = filter === 'all' || (el.dataset.type && el.dataset.type.includes(filter));
    const matchSearch = !search || el.textContent.toLowerCase().includes(search);
    el.style.display = (matchFilter && matchSearch) ? '' : 'none';
  });
}

document.querySelectorAll('#panel-console .filter-btn').forEach(btn => {
  btn.addEventListener('click', () => {
    document.querySelectorAll('#panel-console .filter-btn').forEach(b => b.classList.remove('active'));
    btn.classList.add('active');
    state.consoleFilter = btn.dataset.filter || 'all';
    applyConsoleFilter();
  });
});

document.getElementById('console-search').addEventListener('input', applyConsoleFilter);
document.getElementById('btn-clear-console').onclick = () => {
  consoleArea.innerHTML = '';
  state.consoleLines = [];
};
document.getElementById('btn-clear-all').onclick = () => {
  consoleArea.innerHTML = '';
  state.consoleLines = [];
};
document.getElementById('btn-save-console-local').onclick = async () => {
  try {
    if (!state.consoleLines.length) {
      toast('控制台暂无日志可保存', 'warn');
      return;
    }
    const content = state.consoleLines
      .map((line) => `[${line.ts}] ${line.text}`)
      .join('\n');
    const r = await api.saveConsoleLogLocal(content);
    if (!r?.ok) {
      toast(`保存失败: ${r?.error || '未知错误'}`, 'error');
      return;
    }
    toast('控制台日志已保存到本地');
  } catch (e) {
    toast(`保存失败: ${e.message || e}`, 'error');
  }
};

// 发送命令
const consoleInput = document.getElementById('console-input');
document.getElementById('btn-send-cmd').onclick = sendConsoleCmd;
consoleInput.addEventListener('keydown', e => {
  if (e.key === 'Enter') sendConsoleCmd();
  if (e.key === 'ArrowUp') {
    const h = state.cmdHistory;
    if (h.length > 0) consoleInput.value = h[h.length - 1];
  }
});

async function sendConsoleCmd() {
  const cmd = consoleInput.value.trim();
  if (!cmd) return;
  if (!state.connected) { toast('未连接服务器', 'error'); return; }
  state.cmdHistory = state.cmdHistory.filter(c => c !== cmd);
  state.cmdHistory.push(cmd);
  if (state.cmdHistory.length > 50) state.cmdHistory.shift();
  updateCmdHistory();
  consoleInput.value = '';
  const ts = new Date().toLocaleTimeString('zh-CN', { hour12: false });
  const cmdText = `> ${cmd}`;
  const lineData = { ts, text: cmdText, cls: 'type-cmd' };
  state.consoleLines.push(lineData);
  const el = renderConsoleLine(lineData);
  consoleArea.appendChild(el);
  if (state.consoleLines.length > MAX_CONSOLE_LINES) {
    state.consoleLines.shift();
    if (consoleArea.firstChild) consoleArea.removeChild(consoleArea.firstChild);
  }
  applyConsoleFilter();
  consoleArea.scrollTop = consoleArea.scrollHeight;
  const r = await api.rconCommand(cmd);
  if (!r.ok) toast(`命令失败: ${r.error}`, 'error');
}

function updateCmdHistory() {
  const sel = document.getElementById('cmd-history-select');
  sel.innerHTML = '<option value="">历史命令</option>';
  [...state.cmdHistory].reverse().forEach(c => {
    const o = document.createElement('option');
    o.value = c; o.textContent = c;
    sel.appendChild(o);
  });
  sel.onchange = () => { if (sel.value) { consoleInput.value = sel.value; sel.value = ''; } };
}

// ===== 聊天 =====
const chatArea = document.getElementById('chat-area');

api.onRconChat((data) => {
  const sid = String(data?.steamid || '').trim();
  const meta = getPlayerMeta(sid);
  if (meta.ignoreAdmin && String(data?.channel || '') === '管理') {
    return;
  }
  const msg = document.createElement('div');
  msg.className = 'chat-msg';
  msg.dataset.channel = data.channel;
  const chClass = data.channel === '队伍' ? 'ch-team' : data.channel === '管理' ? 'ch-admin' : 'ch-all';
  const time = new Date(data.time).toLocaleTimeString('zh-CN', { hour12: false });
  msg.innerHTML = `
    <span class="chat-time">${time}</span>
    <span class="chat-channel ${chClass}">${data.channel}</span>
    <span class="chat-user">${escHtml(data.username)}</span>
    <span class="chat-text">: ${escHtml(data.text)}</span>
  `;
  chatArea.appendChild(msg);
  chatArea.scrollTop = chatArea.scrollHeight;
  state.chatLog.push(data);
  applyChatFilter();
});

// 聊天频道过滤
function applyChatFilter() {
  const ch = state.chatChannel;
  chatArea.querySelectorAll('.chat-msg').forEach(el => {
    const match = ch === 'all' || el.dataset.channel === ch;
    el.style.display = match ? '' : 'none';
  });
}

document.querySelectorAll('.channel-btn').forEach(btn => {
  btn.addEventListener('click', () => {
    document.querySelectorAll('.channel-btn').forEach(b => b.classList.remove('active'));
    btn.classList.add('active');
    state.chatChannel = btn.dataset.channel;
    applyChatFilter();
  });
});

document.getElementById('btn-send-chat').onclick = async () => {
  const msg = document.getElementById('chat-input').value.trim();
  if (!msg) return;
  if (!state.connected) { toast('未连接服务器', 'error'); return; }
  await api.rconCommand(`say ${msg}`);
  document.getElementById('chat-input').value = '';
  const el = document.createElement('div');
  el.className = 'chat-msg';
  el.dataset.channel = '管理';
  el.innerHTML = `<span class="chat-time">${new Date().toLocaleTimeString('zh-CN',{hour12:false})}</span><span class="chat-channel ch-admin">管理</span><span class="chat-user">SERVER</span><span class="chat-text">: ${escHtml(msg)}</span>`;
  chatArea.appendChild(el);
  chatArea.scrollTop = chatArea.scrollHeight;
};
document.getElementById('chat-input').addEventListener('keydown', e => {
  if (e.key === 'Enter') document.getElementById('btn-send-chat').click();
});
document.getElementById('btn-clear-chat').onclick = () => { chatArea.innerHTML = ''; };

// ===== 在线玩家 =====
let currentPlayerTarget = null;

async function refreshPlayers() {
  if (!state.connected) return;
  const r = await api.getPlayers();
  if (!r.ok) return;
  state.players = r.players || [];
  document.getElementById('stat-online').textContent = state.players.length;
  updateConnText();
  renderPlayers(state.players);
  ensureSteamGameBanInfo(state.players).catch(() => {});
  ensureIpGeoInfo(state.players).catch(() => {});
  syncItemShopAfterPlayersRefresh();
}

const STEAM_GAME_BAN_CACHE_TTL_MS = 6 * 3600 * 1000; // 6 小时（成功结果）
const STEAM_GAME_BAN_FAIL_RETRY_MS = 2 * 60 * 1000;  // 失败结果 2 分钟后重试

async function ensureSteamGameBanInfo(players) {
  if (!api.getSteamGameBansBatch) return;
  const now = Date.now();

  const unique = new Set();
  (players || []).forEach((p) => {
    const sid = String(p.SteamID || '').trim();
    if (sid) unique.add(sid);
  });
  const steamids = [...unique];
  const missing = steamids.filter((sid) => {
    const item = state.steamGameBanInfoCache[sid];
    if (!item) return true;
    if (!item.fetchedAt) return true;
    // 抓取失败不做长缓存，尽快重试
    if (item.ok === false) return (now - item.fetchedAt) > STEAM_GAME_BAN_FAIL_RETRY_MS;
    return (now - item.fetchedAt) > STEAM_GAME_BAN_CACHE_TTL_MS;
  });

  if (!missing.length) return;

  // 分段请求，避免一次拉太多导致卡顿
  const CHUNK = 25;
  for (let i = 0; i < missing.length; i += CHUNK) {
    const chunk = missing.slice(i, i + CHUNK);
    const r = await api.getSteamGameBansBatch(chunk);
    if (!r || !r.ok || !r.items) continue;
    Object.entries(r.items).forEach(([sid, info]) => {
      state.steamGameBanInfoCache[sid] = { ...info, fetchedAt: now };
    });
  }

  // 更新表格按钮上的封禁数量
  renderPlayers(state.players);
}

const IP_GEO_CACHE_TTL_MS = 24 * 3600 * 1000; // 24 小时

async function ensureIpGeoInfo(players) {
  if (!api.getIpGeoBatch) return;
  const now = Date.now();

  const uniqueIps = new Set();
  (players || []).forEach((p) => {
    const addr = p.Address || '';
    const ip = String(addr).split(':')[0];
    if (ip) uniqueIps.add(ip);
  });

  const ips = [...uniqueIps];
  const missing = ips.filter((ip) => {
    const item = state.ipGeoCache[ip];
    if (!item) return true;
    if (!item.fetchedAt) return true;
    return (now - item.fetchedAt) > IP_GEO_CACHE_TTL_MS;
  });

  if (!missing.length) return;

  const CHUNK = 40;
  for (let i = 0; i < missing.length; i += CHUNK) {
    const chunk = missing.slice(i, i + CHUNK);
    const r = await api.getIpGeoBatch(chunk);
    if (!r || !r.ok || !r.items) continue;
    Object.entries(r.items).forEach(([ip, info]) => {
      const locationText = info?.locationText || ip;
      state.ipGeoCache[ip] = { locationText, fetchedAt: now };
    });
  }

  renderPlayers(state.players);
}

function renderPlayers(players) {
  const q = document.getElementById('player-search').value.toLowerCase();
  const filtered = q ? players.filter(p =>
    (p.DisplayName || '').toLowerCase().includes(q) ||
    (p.SteamID || '').includes(q) ||
    (p.Address || '').includes(q)
  ) : players;
  document.getElementById('player-count').textContent = filtered.length;
  const tbody = document.getElementById('players-tbody');
  if (!filtered.length) {
    tbody.innerHTML = `<tr class="empty-row"><td colspan="10">
      <div class="empty-state">
        <svg viewBox="0 0 48 48" width="40" height="40" fill="none"><circle cx="24" cy="18" r="9" stroke="#2a3348" stroke-width="2"/><path d="M8 42c0-8.837 7.163-16 16-16s16 7.163 16 16" stroke="#2a3348" stroke-width="2" stroke-linecap="round"/></svg>
        <p>暂无在线玩家</p>
      </div>
    </td></tr>`;
    return;
  }
  tbody.innerHTML = filtered.map(p => {
    const ping = parseInt(p.Ping) || 0;
    const pingClass = ping < 80 ? 'ping-good' : ping < 150 ? 'ping-mid' : 'ping-bad';
    const pos = p.Position ? `${Math.round(p.Position.x||0)},${Math.round(p.Position.y||0)},${Math.round(p.Position.z||0)}` : '-';
    const onlineTime = p.ConnectedSeconds ? formatDuration(p.ConnectedSeconds) : '-';
    const timeBan = p.TimeBan ? new Date(p.TimeBan).toLocaleString('zh-CN') : '-';
    const sid = String(p.SteamID || '').trim();
    const banInfo = sid ? state.steamGameBanInfoCache[sid] : null;
    const banCount = (banInfo && banInfo.count != null) ? banInfo.count : '-';
    const banDays = (banInfo && banInfo.daysSinceLastBan != null) ? banInfo.daysSinceLastBan : null;
    const banTitle = banDays != null ? ('距上次封禁 ' + banDays + ' 天') : '点击查看封禁详情';
    const addr = p.Address ? String(p.Address) : '';
    const ip = addr.split(':')[0] || '';
    const geo = ip ? state.ipGeoCache[ip] : null;
    const locTextRaw = (geo && geo.locationText) ? geo.locationText : '-';
    const locText = formatGeoText(locTextRaw);
    const meta = getPlayerMeta(sid);
    const markPrefix = meta.marked ? '★ ' : '';
    return `<tr class="player-row" data-steamid="${escAttr(sid)}">
      <td class="steamid-cell">${p.SteamID || '-'}</td>
      <td><b>${escHtml(markPrefix + (p.DisplayName || p.Name || '?'))}</b></td>
      <td title="${escAttr(locText)}">${escHtml(locText)}</td>
      <td>${p.Address ? p.Address.split(':')[0] : '-'}</td>
      <td class="${pingClass}">${ping}ms</td>
      <td style="font-size:11px;color:#3d4f6a;font-family:monospace">${pos}</td>
      <td>${onlineTime}</td>
      <td>${escHtml(timeBan)}</td>
      <td>
        <button
          class="btn-xs steamban-count-btn"
          ${sid ? '' : 'disabled'}
          onclick="openSteamBanDetails('${escAttr(sid)}')"
          title="${escAttr(banTitle)}"
        >${banCount}</button>
      </td>
      <td><div class="td-actions">
        <button class="btn-xs" onclick="openPlayerModal(${JSON.stringify(p).replace(/"/g,'&quot;')})">操作</button>
        <button class="btn-xs btn-xs-danger" onclick="quickKick('${p.SteamID}','${escAttr(p.DisplayName||p.Name||'')}')">踢出</button>
        <button class="btn-xs btn-xs-danger" onclick="quickBan('${p.SteamID}','${escAttr(p.DisplayName||p.Name||'')}')">封禁</button>
      </div></td>
    </tr>`;
  }).join('');
  bindPlayerContextMenu(filtered);
}

function bindPlayerContextMenu(players) {
  const menu = document.getElementById('player-context-menu');
  if (!menu) return;
  document.querySelectorAll('#players-tbody .player-row').forEach((row) => {
    row.addEventListener('contextmenu', (e) => {
      e.preventDefault();
      const sid = row.getAttribute('data-steamid') || '';
      currentContextPlayer = players.find((p) => String(p.SteamID || '') === sid) || null;
      if (!currentContextPlayer) return;
      const meta = getPlayerMeta(currentContextPlayer.SteamID);
      const markBtn = document.getElementById('ctx-mark');
      const ignoreBtn = document.getElementById('ctx-ignore-admin');
      if (markBtn) markBtn.textContent = meta.marked ? '取消标记' : '设置标记';
      if (ignoreBtn) ignoreBtn.textContent = meta.ignoreAdmin ? "恢复 'Admin' 通知" : "Ignore 'Admin' chat notifications";
      menu.style.display = 'block';
      menu.style.left = `${e.clientX}px`;
      menu.style.top = `${e.clientY}px`;
    });
  });
}

document.addEventListener('click', () => {
  const menu = document.getElementById('player-context-menu');
  if (menu) menu.style.display = 'none';
});

document.getElementById('ctx-open-steam')?.addEventListener('click', () => {
  if (!currentContextPlayer?.SteamID) return;
  api.openUrl(`https://steamcommunity.com/profiles/${currentContextPlayer.SteamID}`);
});
document.getElementById('ctx-open-profile')?.addEventListener('click', () => {
  if (!currentContextPlayer?.SteamID) return;
  const sid = currentContextPlayer.SteamID;
  const meta = getPlayerMeta(sid);
  const history = (loadPlayerHistoryStore()[sid] || []).slice(0, 10);
  const lines = history.map((x) => `- ${new Date(x.time).toLocaleString('zh-CN')} ${x.action} ${x.detail || ''}`);
  alert([
    `玩家: ${currentContextPlayer.DisplayName || currentContextPlayer.Name || sid}`,
    `SteamID: ${sid}`,
    `标记: ${meta.marked ? '是' : '否'}`,
    `备注: ${meta.note || '-'}`,
    '',
    '最近记录:',
    ...(lines.length ? lines : ['- 无'])
  ].join('\n'));
});
document.getElementById('ctx-mark')?.addEventListener('click', () => {
  if (!currentContextPlayer?.SteamID) return;
  const sid = currentContextPlayer.SteamID;
  const meta = getPlayerMeta(sid);
  setPlayerMeta(sid, { marked: !meta.marked });
  addPlayerHistory(sid, meta.marked ? '取消标记' : '设置标记');
  renderPlayers(state.players);
});
document.getElementById('ctx-note')?.addEventListener('click', () => {
  if (!currentContextPlayer?.SteamID) return;
  const sid = currentContextPlayer.SteamID;
  const meta = getPlayerMeta(sid);
  const note = prompt('备注内容（留空可清除）', meta.note || '');
  if (note === null) return;
  setPlayerMeta(sid, { note: note.trim() });
  addPlayerHistory(sid, '更新备注', note.trim());
  toast('备注已更新', 'success');
});
document.getElementById('ctx-ignore-admin')?.addEventListener('click', () => {
  if (!currentContextPlayer?.SteamID) return;
  const sid = currentContextPlayer.SteamID;
  const meta = getPlayerMeta(sid);
  const next = !meta.ignoreAdmin;
  setPlayerMeta(sid, { ignoreAdmin: next });
  addPlayerHistory(sid, next ? '忽略Admin通知' : '恢复Admin通知');
  toast(next ? '已忽略该玩家Admin通知' : '已恢复该玩家Admin通知', 'info');
});
async function copyText(text, label) {
  try {
    await navigator.clipboard.writeText(String(text || ''));
    toast(`${label} 已复制`, 'success');
  } catch {
    toast(`复制${label}失败`, 'error');
  }
}
document.getElementById('ctx-copy-steamid')?.addEventListener('click', () => copyText(currentContextPlayer?.SteamID || '', 'SteamID'));
document.getElementById('ctx-copy-name')?.addEventListener('click', () => copyText(currentContextPlayer?.Name || '', '网名'));
document.getElementById('ctx-copy-displayname')?.addEventListener('click', () => copyText(currentContextPlayer?.DisplayName || currentContextPlayer?.Name || '', '玩家名字'));
document.getElementById('ctx-copy-ip')?.addEventListener('click', () => copyText(String(currentContextPlayer?.Address || '').split(':')[0] || '', 'IP'));
document.getElementById('ctx-kick')?.addEventListener('click', async () => {
  if (!currentContextPlayer?.SteamID) return;
  await quickKick(currentContextPlayer.SteamID, currentContextPlayer.DisplayName || currentContextPlayer.Name || currentContextPlayer.SteamID);
  addPlayerHistory(currentContextPlayer.SteamID, '踢出');
});
document.getElementById('ctx-ban')?.addEventListener('click', () => {
  if (!currentContextPlayer) return;
  openBanConfigModal(currentContextPlayer, false);
  addPlayerHistory(currentContextPlayer.SteamID, '封禁弹窗');
});
document.getElementById('ctx-temp-ban')?.addEventListener('click', () => {
  if (!currentContextPlayer) return;
  openBanConfigModal(currentContextPlayer, true);
  addPlayerHistory(currentContextPlayer.SteamID, '临时封禁弹窗');
});
document.getElementById('ctx-mute')?.addEventListener('click', async () => {
  if (!currentContextPlayer?.SteamID) return;
  const minutes = Number(prompt('禁言分钟数', '60') || 60);
  const hours = Math.max(1, Math.round((minutes / 60) * 100) / 100);
  await api.rconCommand(`mute ${currentContextPlayer.SteamID} ${hours}`);
  addPlayerHistory(currentContextPlayer.SteamID, '禁言', `${minutes}分钟`);
  toast('禁言命令已发送', 'success');
});
document.getElementById('ctx-unmute')?.addEventListener('click', async () => {
  if (!currentContextPlayer?.SteamID) return;
  await api.rconCommand(`unmute ${currentContextPlayer.SteamID}`);
  addPlayerHistory(currentContextPlayer.SteamID, '解除禁言');
  toast('已发送解除禁言', 'success');
});
document.getElementById('ctx-kill')?.addEventListener('click', async () => {
  if (!currentContextPlayer?.SteamID) return;
  const sid = currentContextPlayer.SteamID;
  let r = await api.rconCommand(`killplayer ${sid}`);
  if (!r?.ok) r = await api.rconCommand(`kill ${sid}`);
  if (r?.ok) {
    addPlayerHistory(sid, 'Kill');
    toast('Kill 命令已发送', 'success');
  } else {
    toast('Kill 失败（服务器可能不支持）', 'error');
  }
});
document.getElementById('ctx-teleport')?.addEventListener('click', async () => {
  if (!currentContextPlayer?.SteamID) return;
  const target = prompt('输入目标玩家 SteamID（传送到此玩家）');
  if (!target) return;
  const r = await api.rconCommand(`teleport ${currentContextPlayer.SteamID} ${target}`);
  if (r?.ok) {
    addPlayerHistory(currentContextPlayer.SteamID, '传送', `to ${target}`);
    toast('传送命令已发送', 'success');
  } else {
    toast('传送失败', 'error');
  }
});
document.getElementById('ctx-give-item')?.addEventListener('click', () => {
  if (!currentContextPlayer?.SteamID) return;
  const radioOnline = document.querySelector('input[name="item-target"][value="online"]');
  if (radioOnline) radioOnline.checked = true;
  const sidInput = document.getElementById('item-target-steamid');
  if (sidInput) sidInput.value = currentContextPlayer.SteamID;
  const itemTabBtn = document.querySelector('.tab-btn[data-tab="itemshop"]');
  if (itemTabBtn) itemTabBtn.click();
  addPlayerHistory(currentContextPlayer.SteamID, '给予物品入口');
});
document.getElementById('ctx-kd-stats')?.addEventListener('click', async () => {
  if (!currentContextPlayer?.SteamID) return;
  const sid = currentContextPlayer.SteamID;
  const r = await api.getBattleLog?.(sid, 80);
  if (!r?.ok) { toast('查询失败', 'error'); return; }
  const total = (r.rows || []).length;
  const lethal = (r.rows || []).filter((x) => Number(x.new_hp) <= 0).length;
  addPlayerHistory(sid, '查看K/D统计', `total=${total}, lethal=${lethal}`);
  alert(`玩家 ${sid}\n最近命中记录: ${total}\n疑似击杀条数(new_hp<=0): ${lethal}`);
});
document.getElementById('ctx-combat-records')?.addEventListener('click', async () => {
  if (!currentContextPlayer?.SteamID) return;
  const sid = currentContextPlayer.SteamID;
  const input = document.getElementById('battle-steamid');
  if (input) input.value = sid;
  const tabBtn = document.querySelector('.tab-btn[data-tab="battle"]');
  if (tabBtn) tabBtn.click();
  setTimeout(() => document.getElementById('btn-battle-query')?.click(), 0);
  addPlayerHistory(sid, '查看最近战斗记录');
});
document.getElementById('ctx-history')?.addEventListener('click', () => {
  if (!currentContextPlayer?.SteamID) return;
  const sid = currentContextPlayer.SteamID;
  const history = (loadPlayerHistoryStore()[sid] || []).slice(0, 20);
  const lines = history.map((x) => `${new Date(x.time).toLocaleString('zh-CN')} ${x.action}${x.detail ? ` (${x.detail})` : ''}`);
  alert(lines.length ? lines.join('\n') : '暂无玩家历史记录');
});
document.getElementById('ctx-search-ip')?.addEventListener('click', () => {
  const ip = String(currentContextPlayer?.Address || '').split(':')[0] || '';
  if (!ip) return;
  api.openUrl(`https://ipinfo.io/${encodeURIComponent(ip)}`);
});
document.getElementById('ctx-reset-data')?.addEventListener('click', () => {
  if (!currentContextPlayer?.SteamID) return;
  const sid = currentContextPlayer.SteamID;
  if (!confirm(`确认重置 ${sid} 的本地标记/备注/历史数据？`)) return;
  clearPlayerMeta(sid);
  const store = loadPlayerHistoryStore();
  delete store[sid];
  savePlayerHistoryStore(store);
  renderPlayers(state.players);
  toast('本地玩家数据已重置', 'success');
});

document.getElementById('player-search').addEventListener('input', () => renderPlayers(state.players));
document.getElementById('btn-refresh-players').onclick = refreshPlayers;
// 在线玩家：不做固定轮询，避免频繁获取
// 将在“连接成功 + 有玩家加入/离开日志”时按需刷新

// ===== Steam 游戏封禁详情弹窗（来自在线玩家表格点击）=====
const steamBanModalState = {
  open: false,
  steamid: null,
  reqId: 0,
};

function openSteamBanDetails(steamid) {
  const modal = document.getElementById('steam-ban-modal');
  const steamidEl = document.getElementById('steam-ban-steamid');
  const countEl = document.getElementById('steam-ban-count');
  const daysEl = document.getElementById('steam-ban-days');
  const gamesEl = document.getElementById('steam-ban-games');
  if (!modal || !steamidEl || !countEl || !daysEl || !gamesEl) return;

  steamid = String(steamid || '').trim();
  steamidEl.textContent = steamid || '-';
  steamBanModalState.open = true;
  steamBanModalState.steamid = steamid || null;
  const myReqId = ++steamBanModalState.reqId;

  const cached = steamid ? state.steamGameBanInfoCache[steamid] : null;
  if (!cached || cached.ok === false) {
    countEl.textContent = '-';
    daysEl.textContent = '-';
    gamesEl.innerHTML = `<div style="color:var(--text-muted)">封禁信息正在加载中...</div>`;

    // 只拉取当前 SteamID，避免一次性请求太多
    api.getSteamGameBansBatch?.([steamid]).then((r) => {
      if (!r || !r.ok || !r.items || !r.items[steamid]) return;
      state.steamGameBanInfoCache[steamid] = { ...r.items[steamid], fetchedAt: Date.now() };
      // 用户可能已关闭弹窗；不要“自动重新弹出”
      if (!steamBanModalState.open) return;
      if (steamBanModalState.reqId !== myReqId) return;
      if (steamBanModalState.steamid !== steamid) return;

      // 只刷新内容，不改变打开状态
      openSteamBanDetails(steamid);
      renderPlayers(state.players);
    }).catch(() => {});
  } else {
    countEl.textContent = cached.count != null ? cached.count : '-';
    daysEl.textContent = cached.daysSinceLastBan != null ? `${cached.daysSinceLastBan} 天` : '-';
    const daysText = cached.daysSinceLastBan != null ? `${cached.daysSinceLastBan} 天` : '-';

    const games = Array.isArray(cached.games) ? cached.games : [];
    if (!games.length) {
      gamesEl.innerHTML = `<div style="color:var(--text-muted)">暂无可解析的游戏封禁列表</div>`;
    } else {
      gamesEl.innerHTML = games
        .slice(0, 30)
        .map((g) => `<div style="padding:6px 0;border-bottom:1px dashed rgba(30,42,61,0.6)">${escHtml(g.name || '-')} <span style="color:var(--text-muted)">(${daysText})</span></div>`)
        .join('');
    }
  }

  modal.style.display = 'flex';
}

document.getElementById('btn-close-steam-ban-modal')?.addEventListener('click', () => {
  steamBanModalState.open = false;
  steamBanModalState.steamid = null;
  steamBanModalState.reqId++;
  document.getElementById('steam-ban-modal').style.display = 'none';
});
document.getElementById('steam-ban-modal')?.addEventListener('click', (e) => {
  if (e.target === e.currentTarget) {
    steamBanModalState.open = false;
    steamBanModalState.steamid = null;
    steamBanModalState.reqId++;
    e.currentTarget.style.display = 'none';
  }
});

// 玩家操作弹窗
function openPlayerModal(player) {
  currentPlayerTarget = player;
  document.getElementById('modal-player-name').textContent = player.DisplayName || player.Name || '?';
  document.getElementById('modal-steamid').textContent = player.SteamID || '-';
  document.getElementById('modal-ip').textContent = player.Address ? player.Address.split(':')[0] : '-';
  document.getElementById('kick-reason').value = '';
  document.getElementById('ban-reason').value = '';
  document.getElementById('mute-duration').value = '';
  const muteUnitEl = document.getElementById('mute-unit');
  if (muteUnitEl) muteUnitEl.value = 'hours';

  // 传送：选择玩家A(要传送的) + 玩家B(传送到的)
  const fromSel = document.getElementById('teleport-from');
  const toSel = document.getElementById('teleport-to');
  if (fromSel && toSel) {
    fromSel.innerHTML = '';
    toSel.innerHTML = '';
    const list = (state.players && state.players.length) ? state.players : [player];
    list.forEach((p) => {
      const label = p.DisplayName || p.Name || p.SteamID || '-';
      const sid = p.SteamID || '';
      const o1 = document.createElement('option');
      o1.value = sid;
      o1.textContent = label;
      fromSel.appendChild(o1);

      const o2 = document.createElement('option');
      o2.value = sid;
      o2.textContent = label;
      toSel.appendChild(o2);
    });

    const curSid = player.SteamID || '';
    fromSel.value = curSid;
    // 默认目标选择“第一个不是自己的人”
    const firstOther = list.find((p) => (p.SteamID || '') && (p.SteamID !== curSid));
    toSel.value = (firstOther?.SteamID) || curSid;
  }
  document.getElementById('player-modal').style.display = 'flex';
}

document.getElementById('btn-close-modal').onclick = () => { document.getElementById('player-modal').style.display = 'none'; };
document.getElementById('player-modal').onclick = (e) => { if (e.target === e.currentTarget) e.currentTarget.style.display = 'none'; };

async function quickKick(steamid, name) {
  if (!state.connected) { toast('未连接服务器', 'error'); return; }
  const r = await api.rconCommand(`kick ${steamid} 您已被管理员踢出`);
  if (r.ok) { toast(`已踢出 ${name}`, 'success'); setTimeout(refreshPlayers, 2000); }
  else toast('踢出失败: ' + r.error, 'error');
}

async function quickBan(steamid, name) {
  openBanConfigModal({ SteamID: steamid, DisplayName: name, Name: name }, false);
}

document.getElementById('btn-do-kick').onclick = async () => {
  if (!currentPlayerTarget) return;
  const reason = document.getElementById('kick-reason').value || '您已被管理员踢出';
  const r = await api.rconCommand(`kick ${currentPlayerTarget.SteamID} ${reason}`);
  if (r.ok) { toast(`已踢出 ${currentPlayerTarget.DisplayName || currentPlayerTarget.Name}`, 'success'); document.getElementById('player-modal').style.display = 'none'; setTimeout(refreshPlayers, 2000); }
  else toast('踢出失败', 'error');
};

document.getElementById('btn-do-ban').onclick = async () => {
  if (!currentPlayerTarget) return;
  openBanConfigModal(currentPlayerTarget, false);
};

document.getElementById('btn-do-teleport').onclick = async () => {
  const fromSel = document.getElementById('teleport-from');
  const toSel = document.getElementById('teleport-to');
  const fromSteamId = fromSel?.value || '';
  const toSteamId = toSel?.value || '';
  if (!fromSteamId || !toSteamId) { toast('传送目标无效', 'error'); return; }
  if (fromSteamId === toSteamId) { toast('不能传送到自己', 'error'); return; }

  // 目标：把“当前玩家(from)”传送到“所选玩家(to)”
  // Rust 原生命令通常为：teleport <from> <to>（部分服务器可能不支持 RCON 执行该命令）
  const cmd = `teleport ${fromSteamId} ${toSteamId}`;
  const r = await api.rconCommand(cmd);
  if (r && r.ok) toast('传送命令已发送', 'success');
  else toast('传送失败：服务器可能不支持 RCON 传送（需要插件或在游戏内执行）', 'error');
};

document.getElementById('btn-do-mute').onclick = async () => {
  if (!currentPlayerTarget) return;
  const durInput = document.getElementById('mute-duration')?.value;
  let durVal = parseFloat(durInput);
  if (!Number.isFinite(durVal) || durVal <= 0) durVal = 1;

  const unit = document.getElementById('mute-unit')?.value || 'hours';
  // 目前你的观察“看起来只能禁言小时”，因此这里把服务器参数按“小时”处理
  // 若选择“分钟”，则换算为小时发送到 `mute steamid hours`
  let durSend = unit === 'minutes' ? (Math.round((durVal / 60) * 100) / 100) : durVal;
  if (!Number.isFinite(durSend) || durSend <= 0) durSend = 1;

  await api.rconCommand(`mute ${currentPlayerTarget.SteamID} ${durSend}`);
  if (unit === 'minutes') toast(`已禁言 ${durVal} 分钟`, 'success');
  else toast(`已禁言 ${durVal} 小时`, 'success');
};

document.getElementById('btn-do-unmute').onclick = async () => {
  if (!currentPlayerTarget) return;
  await api.rconCommand(`unmute ${currentPlayerTarget.SteamID}`);
  toast('已解除禁言', 'success');
};

// ===== 封禁记录 =====
async function refreshBans() {
  if (!state.connected) return;
  const r = await api.getBans();
  const dbResp = await api.getBanDb?.();
  const localEntries = (dbResp?.ok && Array.isArray(dbResp.db?.entries)) ? dbResp.db.entries : [];
  const tbody = document.getElementById('bans-tbody');
  const serverBans = r.ok ? (r.bans || []) : [];
  const merged = [...serverBans];
  localEntries.slice(0, 300).forEach((e) => {
    if (!e?.steamId) return;
    if (merged.some((x) => String(x.SteamID || '') === String(e.steamId || ''))) return;
    merged.push({
      SteamID: e.steamId,
      Name: e.name || '',
      IP: e.ip || e.ipRange || '-',
      BanTime: e.createdAt ? new Date(e.createdAt).toLocaleString('zh-CN') : '-',
      Reason: `${e.reason || '-'}${e.tempUntil ? ` (临时至 ${new Date(e.tempUntil).toLocaleString('zh-CN')})` : ''}`,
    });
  });
  if (!merged.length) {
    tbody.innerHTML = `<tr class="empty-row"><td colspan="6">
      <div class="empty-state">
        <svg viewBox="0 0 48 48" width="40" height="40" fill="none"><circle cx="24" cy="24" r="18" stroke="#2a3348" stroke-width="2"/><line x1="10" y1="10" x2="38" y2="38" stroke="#2a3348" stroke-width="2"/></svg>
        <p>暂无封禁记录</p>
      </div>
    </td></tr>`;
    return;
  }
  const q = document.getElementById('ban-search').value.toLowerCase();
  const filtered = q ? merged.filter(b => (b.SteamID||'').includes(q)||(b.Name||'').toLowerCase().includes(q)||(b.Reason||'').toLowerCase().includes(q)) : merged;
  tbody.innerHTML = filtered.map(b => `<tr>
    <td class="steamid-cell">${b.SteamID||'-'}</td>
    <td>${escHtml(b.Name||'-')}</td>
    <td>${b.IP||'-'}</td>
    <td>${b.BanTime||'-'}</td>
    <td>${escHtml(b.Reason||'-')}</td>
    <td><button class="btn-xs" onclick="unbanPlayer('${b.SteamID}')">解封</button></td>
  </tr>`).join('');
}

async function unbanPlayer(steamid) {
  const r = await api.rconCommand(`unban ${steamid}`);
  if (r.ok) { toast('已解封 ' + steamid, 'success'); setTimeout(refreshBans, 1500); }
  else toast('解封失败', 'error');
}

// ===== Steam 封禁查询（当前实现为：服务器 banlist 封禁记录查询） =====
async function checkSteamBan() {
  const inputEl = document.getElementById('steamban-search');
  const resultEl = document.getElementById('steamban-result');
  if (!inputEl || !resultEl) return;

  const steamid = (inputEl.value || '').trim();
  if (!steamid) {
    resultEl.classList.add('empty-state');
    resultEl.innerHTML = '<p>请输入 SteamID，然后点击“查询”</p>';
    return;
  }

  resultEl.innerHTML = '<p style="color:var(--text-muted)">查询中…</p>';

  const r = await api.getBans();
  if (!r.ok) {
    resultEl.innerHTML = `<p style="color:var(--red)">查询失败：${escHtml(r.error || '未知错误')}</p>`;
    return;
  }

  const bans = (r.bans || []).filter(b => {
    const sid = String(b.SteamID || '').toLowerCase();
    const q = steamid.toLowerCase();
    return sid === q || sid.includes(q);
  });

  if (!bans.length) {
    resultEl.innerHTML = `<div class="empty-state"><p>未在服务器封禁列表中找到：${escHtml(steamid)}</p></div>`;
    return;
  }

  // 只展示第一条，同时给出原因；如需完整列表可以再扩展成 table
  const b = bans[0];
  resultEl.innerHTML = `
    <div class="empty-state" style="align-items:flex-start;gap:6px">
      <p><b style="color:var(--red)">已封禁</b></p>
      <p>SteamID：${escHtml(b.SteamID || '-')}</p>
      <p>玩家名：${escHtml(b.Name || '-')}</p>
      <p>原因：${escHtml(b.Reason || '-')}</p>
      ${bans.length > 1 ? `<p style="color:var(--text-muted);font-size:12px">匹配到 ${bans.length} 条记录</p>` : ''}
    </div>
  `;
}

document.getElementById('btn-steamban-check')?.addEventListener('click', checkSteamBan);
document.getElementById('steamban-search')?.addEventListener('keydown', (e) => {
  if (e.key === 'Enter') checkSteamBan();
});

document.getElementById('btn-refresh-bans').onclick = refreshBans;
document.getElementById('ban-search').addEventListener('input', refreshBans);
document.getElementById('btn-export-bans')?.addEventListener('click', async () => {
  const r = await api.exportBanDb?.();
  if (r?.ok) toast('封禁库已导出', 'success');
  else toast('导出失败', 'error');
});
document.getElementById('btn-sync-bans')?.addEventListener('click', async () => {
  const r = await api.syncBanDb?.();
  if (!r?.ok) { toast('同步失败', 'error'); return; }
  const msg = (r.result || []).map((x) => `${x.server}:${x.synced}`).join(' | ');
  toast(`同步完成 ${msg}`, 'success', 5000);
});
document.getElementById('btn-ban-add').onclick = () => {
  const steamid = prompt('输入要封禁的SteamID:');
  if (!steamid) return;
  openBanConfigModal({ SteamID: steamid, DisplayName: steamid, Name: steamid }, false);
};

function openBanConfigModal(player, tempMode) {
  currentBanTarget = player;
  document.getElementById('ban-config-steamid').value = player?.SteamID || '';
  document.getElementById('ban-config-reason').value = '违规行为';
  document.getElementById('ban-config-minutes').value = tempMode ? '60' : '0';
  document.getElementById('ban-config-global').checked = true;
  document.getElementById('ban-config-sync').checked = false;
  document.getElementById('ban-config-ip').checked = false;
  document.getElementById('ban-config-modal').style.display = 'flex';
}

async function submitBanConfig() {
  if (!currentBanTarget?.SteamID) return;
  const reason = document.getElementById('ban-config-reason').value || '违规';
  const minutes = Number(document.getElementById('ban-config-minutes').value || 0);
  const globalSync = !!document.getElementById('ban-config-global').checked;
  const syncAllServers = !!document.getElementById('ban-config-sync').checked;
  const withIp = !!document.getElementById('ban-config-ip').checked;
  const ip = String(currentBanTarget.Address || '').split(':')[0] || '';
  const ipRange = withIp && ip ? ip.split('.').slice(0, 3).join('.') + '.*' : '';
  const payload = {
    steamId: currentBanTarget.SteamID,
    reason,
    durationMinutes: minutes,
    globalSync,
    syncAllServers,
    ip,
    ipRange,
  };
  const r = await api.saveBanRule?.(payload);
  if (!r?.ok) {
    toast('封禁失败: ' + (r?.error || '未知错误'), 'error');
    return;
  }
  if (syncAllServers) {
    await api.syncBanDb?.();
  }
  addPlayerHistory(currentBanTarget.SteamID, minutes > 0 ? '临时封禁' : '封禁', reason);
  toast('封禁已生效', 'success');
  document.getElementById('ban-config-modal').style.display = 'none';
  document.getElementById('player-modal').style.display = 'none';
  setTimeout(() => { refreshPlayers(); refreshBans(); }, 1200);
}

document.getElementById('btn-close-ban-config')?.addEventListener('click', () => {
  document.getElementById('ban-config-modal').style.display = 'none';
});
document.getElementById('btn-cancel-ban-config')?.addEventListener('click', () => {
  document.getElementById('ban-config-modal').style.display = 'none';
});
document.getElementById('btn-confirm-ban-config')?.addEventListener('click', submitBanConfig);
document.getElementById('ban-config-modal')?.addEventListener('click', (e) => {
  if (e.target === e.currentTarget) e.currentTarget.style.display = 'none';
});

async function queryBattleLog() {
  if (!state.connected) { toast('请先连接服务器', 'error'); return; }
  const steamid = document.getElementById('battle-steamid').value.trim();
  const lines = Number(document.getElementById('battle-lines').value || 30);
  const tbody = document.getElementById('battle-tbody');
  if (!steamid) {
    tbody.innerHTML = `<tr class="empty-row"><td colspan="8"><div class="empty-state"><p>请输入 SteamID</p></div></td></tr>`;
    return;
  }
  const r = await api.getBattleLog?.(steamid, lines);
  if (!r?.ok || !(r.rows || []).length) {
    tbody.innerHTML = `<tr class="empty-row"><td colspan="8"><div class="empty-state"><p>${escHtml(r?.error || '未查询到战斗记录')}</p></div></td></tr>`;
    return;
  }
  tbody.innerHTML = r.rows.map((x) => `<tr>
    <td>${escHtml(x.date || '-')}</td>
    <td>${escHtml(x.attacker || '-')}</td>
    <td>${escHtml(x.weapon || '-')}</td>
    <td>${escHtml(x.ammo || '-')}</td>
    <td>${escHtml(x.area || '-')}</td>
    <td>${escHtml(x.distance || '-')}</td>
    <td>${escHtml(x.old_hp || '-')}</td>
    <td>${escHtml(x.new_hp || '-')}</td>
  </tr>`).join('');
}
document.getElementById('btn-battle-query')?.addEventListener('click', queryBattleLog);

// ===== 离线玩家 =====
async function refreshOfflinePlayers() {
  const r = await api.getOfflinePlayers();
  const players = r.players || [];
  state.offlinePlayers = players;
  const q = document.getElementById('offline-search').value.toLowerCase();
  const filtered = q ? players.filter(p => (p.DisplayName||p.Name||'').toLowerCase().includes(q)||(p.SteamID||'').includes(q)) : players;
  const tbody = document.getElementById('offline-tbody');
  if (!filtered.length) {
    tbody.innerHTML = `<tr class="empty-row"><td colspan="5">
      <div class="empty-state">
        <svg viewBox="0 0 48 48" width="40" height="40" fill="none"><circle cx="24" cy="18" r="9" stroke="#2a3348" stroke-width="2" stroke-dasharray="3 2"/><path d="M8 42c0-8.837 7.163-16 16-16s16 7.163 16 16" stroke="#2a3348" stroke-width="2" stroke-linecap="round" stroke-dasharray="3 2"/></svg>
        <p>暂无离线玩家记录</p>
      </div>
    </td></tr>`;
    return;
  }
  tbody.innerHTML = filtered.map(p => {
    const pos = p.LastPosition ? `${Math.round(p.LastPosition.x||0)},${Math.round(p.LastPosition.y||0)},${Math.round(p.LastPosition.z||0)}` : (p.LastPos || '-');
    return `<tr>
      <td><b>${escHtml(p.DisplayName||p.Name||'?')}</b></td>
      <td class="steamid-cell">${p.SteamID||'-'}</td>
      <td style="font-size:11px;color:#3d4f6a;font-family:monospace">${pos}</td>
      <td>${p.OfflineTime ? new Date(p.OfflineTime).toLocaleString('zh-CN') : '-'}</td>
      <td><button class="btn-xs btn-xs-danger" onclick="banOfflinePlayer('${p.SteamID}','${escAttr(p.DisplayName||p.Name||'')}')">封禁</button></td>
    </tr>`;
  }).join('');
}

async function banOfflinePlayer(steamid, name) {
  const reason = prompt(`封禁 ${name} 的原因:`) || '违规';
  const r = await api.rconCommand(`ban ${steamid} ${reason}`);
  if (r.ok) toast('封禁成功', 'success'); else toast('封禁失败', 'error');
}

document.getElementById('offline-search').addEventListener('input', refreshOfflinePlayers);
document.getElementById('btn-clear-offline').onclick = async () => {
  if (!confirm('确认清空所有离线玩家记录?')) return;
  await api.clearOfflinePlayers();
  state.offlinePlayers = [];
  await refreshOfflinePlayers();
  renderPermPlayerItems();
  toast('离线记录已清空', 'success');
};

// ===== 权限组 =====
const groupsUIState = {
  groups: [],
  selected: null,
  detail: null,
  permsAll: null,
  permsAllFetchedAt: 0,
};

function getPlayerNameBySteamId(steamid) {
  const sid = String(steamid || '').trim();
  if (!sid) return '-';
  const online = (state.players || []).find((p) => String(p.SteamID || '').trim() === sid);
  if (online) return online.DisplayName || online.Name || '-';
  const offline = (state.offlinePlayers || []).find((p) => String(p.SteamID || '').trim() === sid);
  if (offline) return offline.DisplayName || offline.Name || '-';
  return '-';
}

async function refreshGroups() {
  const listEl = document.getElementById('groups-list');
  const hintEl = document.getElementById('groups-count-hint');
  if (!listEl || !hintEl) return;
  if (!state.connected) {
    listEl.innerHTML = `<div class="empty-state" style="padding:28px 0"><p>请先连接服务器后再刷新权限组</p></div>`;
    hintEl.textContent = '0 个组';
    setGroupSelection(null);
    return;
  }

  listEl.innerHTML = `<div class="empty-state" style="padding:28px 0"><p>正在获取权限组…</p></div>`;
  const r = await api.getGroups();
  if (!r.ok) {
    listEl.innerHTML = `<div class="empty-state" style="padding:28px 0">
      <p>获取权限组失败</p>
      <p style="font-size:12px;color:var(--text-muted);margin-top:8px">${escHtml(r.error || '未知错误')}</p>
    </div>`;
    hintEl.textContent = '0 个组';
    setGroupSelection(null);
    return;
  }

  const groups = Array.isArray(r.groups) ? r.groups : [];
  groupsUIState.groups = groups;
  hintEl.textContent = `${groups.length} 个组`;

  if (!groups.length) {
    const rawPreview = (r.raw || '').trim().slice(0, 600);
    const extra = r.timedOut ? '<p style="font-size:11px;color:var(--text-warn,#d29922);margin-top:6px">RCON 可能超时，可再点一次刷新。</p>' : '';
    listEl.innerHTML = `<div class="empty-state" style="padding:28px 0;text-align:left">
      <p style="text-align:center">未解析到组名（需要 uMod/Oxide）</p>
      <p style="font-size:11px;color:var(--text-muted);margin:8px 0;text-align:center">已尝试：oxide.show groups / o.show groups / perm.show groups / oxide.groups</p>
      ${extra}
      <p style="font-size:10px;color:var(--text-muted);margin-top:6px">服务器原始返回（节选）：</p>
      <pre style="font-size:10px;font-family:monospace;background:var(--bg-input);padding:8px;border-radius:6px;max-height:100px;overflow:auto;white-space:pre-wrap;word-break:break-all;margin:0">${escHtml(rawPreview || '(空)')}</pre>
    </div>`;
    setGroupSelection(null);
    return;
  }

  listEl.innerHTML = groups.map((g) => {
    const active = groupsUIState.selected === g ? 'active' : '';
    return `<div class="group-item ${active}" data-group="${escAttr(g)}">
      <div class="group-item-name">${escHtml(g)}</div>
      <div class="group-item-badge">点击管理</div>
    </div>`;
  }).join('');

  listEl.querySelectorAll('.group-item').forEach((el) => {
    el.addEventListener('click', () => {
      const g = el.getAttribute('data-group') || '';
      setGroupSelection(g);
    });
  });

  // 默认选中第一个
  if (!groupsUIState.selected && groups.length) setGroupSelection(groups[0]);
}

async function deleteGroup(name) {
  if (!confirm(`确认删除权限组 "${name}"?`)) return;
  const r = await api.rconCommand(`oxide.group remove ${name}`);
  if (r.ok) { toast('权限组已删除', 'success'); setTimeout(refreshGroups, 1500); }
  else toast('删除失败', 'error');
}

document.getElementById('btn-refresh-groups').onclick = refreshGroups;
document.getElementById('btn-create-group').onclick = async () => {
  const name = document.getElementById('new-group-name').value.trim();
  if (!name) { toast('请输入权限组名称', 'error'); return; }
  const r = await api.rconCommand(`oxide.group add ${name}`);
  if (r.ok) { toast(`权限组 "${name}" 已创建`, 'success'); document.getElementById('new-group-name').value = ''; setTimeout(refreshGroups, 1500); }
  else toast('创建失败', 'error');
};

function setGroupSelection(group) {
  groupsUIState.selected = group || null;
  groupsUIState.detail = null;
  const nameEl = document.getElementById('group-detail-name');
  const btnAddPerm = document.getElementById('btn-group-add-perm');
  const btnDel = document.getElementById('btn-group-delete');
  const btnRefresh = document.getElementById('btn-group-refresh-detail');
  const permListEl = document.getElementById('group-perm-list');
  const memberAdd = document.getElementById('btn-group-member-add');
  const memberRemove = document.getElementById('btn-group-member-remove');
  if (nameEl) nameEl.textContent = group || '未选择';
  const enabled = !!group;
  [btnAddPerm, btnDel, btnRefresh, memberAdd, memberRemove].forEach((b) => { if (b) b.disabled = !enabled; });
  if (permListEl) permListEl.innerHTML = `<div class="empty-state" style="padding:26px 0"><p>${enabled ? '正在加载组权限…' : '请选择左侧权限组'}</p></div>`;

  document.querySelectorAll('#groups-list .group-item').forEach((el) => {
    const g = el.getAttribute('data-group');
    el.classList.toggle('active', !!group && g === group);
  });

  if (group) loadGroupDetail(group).catch(() => {});
}

async function loadGroupDetail(group) {
  const g = String(group || '').trim();
  if (!g) return;
  const r = await api.getGroupDetail?.(g);
  if (!r || !r.ok) {
    renderGroupPerms(g, [], r?.raw || '', r?.error || '获取组详情失败');
    renderGroupMembers(g, [], r?.raw || '', r?.error || '获取组详情失败');
    return;
  }
  groupsUIState.detail = r;
  renderGroupPerms(g, r.perms || [], r.raw || '', null);
  renderGroupMembers(g, r.users || [], r.raw || '', null);
}

function renderGroupPerms(group, perms, raw, error) {
  const filterEl = document.getElementById('group-perm-filter');
  const permListEl = document.getElementById('group-perm-list');
  if (!permListEl) return;

  const q = String(filterEl?.value || '').trim().toLowerCase();
  const list = (perms || []).filter((p) => !q || String(p).toLowerCase().includes(q));

  if (error) {
    permListEl.innerHTML = `<div class="empty-state" style="padding:26px 0;text-align:left">
      <p style="text-align:center">获取组权限失败</p>
      <p style="font-size:12px;color:var(--text-muted);margin-top:8px;text-align:center">${escHtml(error)}</p>
      ${raw ? `<pre style="font-size:10px;font-family:monospace;background:var(--bg-input);padding:8px;border-radius:6px;max-height:160px;overflow:auto;white-space:pre-wrap;word-break:break-all;margin:10px 0 0">${escHtml(String(raw).slice(0,1200))}</pre>` : ''}
    </div>`;
    return;
  }

  if (!list.length) {
    permListEl.innerHTML = `<div class="empty-state" style="padding:26px 0"><p>该组暂无权限</p></div>`;
    return;
  }

  permListEl.innerHTML = list.map((p) => {
    const perm = String(p);
    return `<div class="perm-chip">
      <code>${escHtml(perm)}</code>
      <div class="perm-actions">
        <button class="btn-xs btn-xs-danger" data-perm="${escAttr(perm)}">移除</button>
      </div>
    </div>`;
  }).join('');

  permListEl.querySelectorAll('button[data-perm]').forEach((btn) => {
    btn.addEventListener('click', async () => {
      const perm = btn.getAttribute('data-perm');
      if (!perm) return;
      const r = await api.groupRevokePerm?.(group, perm);
      if (r && r.ok) { toast('已移除权限', 'success'); await loadGroupDetail(group); }
      else toast('移除失败', 'error');
    });
  });
}

function renderGroupMembers(group, users, raw, error) {
  const listEl = document.getElementById('group-member-list');
  if (!listEl) return;
  const ids = Array.isArray(users) ? users.map((x) => String(x || '').trim()).filter(Boolean) : [];

  if (error) {
    listEl.innerHTML = `<div class="empty-state" style="padding:18px 0;text-align:left">
      <p style="text-align:center">获取成员失败</p>
      <p style="font-size:12px;color:var(--text-muted);margin-top:8px;text-align:center">${escHtml(error)}</p>
      ${raw ? `<pre style="font-size:10px;font-family:monospace;background:var(--bg-input);padding:8px;border-radius:6px;max-height:140px;overflow:auto;white-space:pre-wrap;word-break:break-all;margin:10px 0 0">${escHtml(String(raw).slice(0,1000))}</pre>` : ''}
    </div>`;
    return;
  }

  if (!ids.length) {
    listEl.innerHTML = `<div class="empty-state" style="padding:18px 0"><p>暂无成员数据</p></div>`;
    return;
  }

  listEl.innerHTML = ids.map((sid) => {
    const name = getPlayerNameBySteamId(sid);
    return `<div class="member-chip">
      <div class="member-main">
        <div class="member-name">${escHtml(sid)} · ${escHtml(name)}</div>
        <div class="member-sid">${escHtml(sid)}</div>
      </div>
      <div class="member-actions">
        <button class="btn-xs btn-xs-danger" data-sid="${escAttr(sid)}">移除</button>
      </div>
    </div>`;
  }).join('');

  listEl.querySelectorAll('button[data-sid]').forEach((btn) => {
    btn.addEventListener('click', async () => {
      const sid = btn.getAttribute('data-sid');
      if (!sid) return;
      const r = await api.playerRemoveGroup?.(sid, group);
      if (r && r.ok) {
        toast('成员已移除', 'success');
        await loadGroupDetail(group);
      } else {
        toast('移除失败', 'error');
      }
    });
  });
}

document.getElementById('group-perm-filter')?.addEventListener('input', () => {
  if (groupsUIState.selected && groupsUIState.detail) {
    renderGroupPerms(groupsUIState.selected, groupsUIState.detail.perms || [], groupsUIState.detail.raw || '', null);
  }
});

document.getElementById('btn-group-refresh-detail')?.addEventListener('click', () => {
  if (groupsUIState.selected) loadGroupDetail(groupsUIState.selected);
});

document.getElementById('btn-group-delete')?.addEventListener('click', async () => {
  const g = groupsUIState.selected;
  if (!g) return;
  await deleteGroup(g);
  groupsUIState.selected = null;
  setGroupSelection(null);
  setTimeout(refreshGroups, 1500);
});

// 成员管理（复用 playerAddGroup / playerRemoveGroup）
document.getElementById('btn-group-member-add')?.addEventListener('click', async () => {
  const g = groupsUIState.selected;
  const sid = document.getElementById('group-member-steamid')?.value?.trim();
  if (!g || !sid) { toast('请输入 SteamID', 'error'); return; }
  const r = await api.playerAddGroup?.(sid, g);
  if (r && r.ok) {
    toast('成员已添加到该组', 'success');
    document.getElementById('group-member-steamid').value = '';
    await loadGroupDetail(g);
  } else toast('添加失败', 'error');
});
document.getElementById('btn-group-member-remove')?.addEventListener('click', async () => {
  const g = groupsUIState.selected;
  const sid = document.getElementById('group-member-steamid')?.value?.trim();
  if (!g || !sid) { toast('请输入 SteamID', 'error'); return; }
  const r = await api.playerRemoveGroup?.(sid, g);
  if (r && r.ok) {
    toast('成员已从该组移除', 'success');
    document.getElementById('group-member-steamid').value = '';
    await loadGroupDetail(g);
  } else toast('移除失败', 'error');
});

// ===== 权限选择器弹窗 =====
function openPermPicker() {
  const g = groupsUIState.selected;
  if (!g) return;
  document.getElementById('perm-picker-group').textContent = g;
  document.getElementById('perm-picker-search').value = '';
  document.getElementById('perm-picker-selected').textContent = '0';
  document.getElementById('perm-picker-list').innerHTML = '<div class="empty-state" style="padding:18px 0"><p>加载权限列表中…</p></div>';
  document.getElementById('perm-picker-modal').style.display = 'flex';
  loadAllPermsAndRender();
}

function closePermPicker() {
  document.getElementById('perm-picker-modal').style.display = 'none';
}

async function loadAllPermsAndRender() {
  const now = Date.now();
  const needFetch = !groupsUIState.permsAll || (now - groupsUIState.permsAllFetchedAt) > 10 * 60 * 1000;
  if (needFetch) {
    const r = await api.getPermissions?.();
    if (r && r.ok) {
      groupsUIState.permsAll = r.perms || [];
      groupsUIState.permsAllFetchedAt = now;
    } else {
      groupsUIState.permsAll = [];
      groupsUIState.permsAllFetchedAt = now;
    }
  }
  renderPermPickerList();
}

function renderPermPickerList() {
  const listEl = document.getElementById('perm-picker-list');
  const totalEl = document.getElementById('perm-picker-total');
  const selectedEl = document.getElementById('perm-picker-selected');
  if (!listEl || !totalEl || !selectedEl) return;

  const q = String(document.getElementById('perm-picker-search')?.value || '').trim().toLowerCase();
  const perms = Array.isArray(groupsUIState.permsAll) ? groupsUIState.permsAll : [];
  const filtered = perms.filter((p) => !q || String(p).toLowerCase().includes(q));
  totalEl.textContent = String(perms.length);

  if (!filtered.length) {
    listEl.innerHTML = '<div class="empty-state" style="padding:18px 0"><p>没有匹配权限</p></div>';
    selectedEl.textContent = '0';
    return;
  }

  listEl.innerHTML = filtered.slice(0, 800).map((p) => {
    const perm = String(p);
    return `<label class="perm-row">
      <input type="checkbox" data-perm="${escAttr(perm)}">
      <code>${escHtml(perm)}</code>
    </label>`;
  }).join('');

  const updateSelectedCount = () => {
    selectedEl.textContent = String(listEl.querySelectorAll('input[type=\"checkbox\"]:checked').length);
  };
  listEl.querySelectorAll('input[type=\"checkbox\"]').forEach((cb) => cb.addEventListener('change', updateSelectedCount));
  updateSelectedCount();
}

document.getElementById('btn-group-add-perm')?.addEventListener('click', openPermPicker);
document.getElementById('btn-close-perm-picker')?.addEventListener('click', closePermPicker);
document.getElementById('btn-perm-picker-cancel')?.addEventListener('click', closePermPicker);
document.getElementById('perm-picker-modal')?.addEventListener('click', (e) => { if (e.target === e.currentTarget) closePermPicker(); });
document.getElementById('btn-perm-picker-clear')?.addEventListener('click', () => {
  document.getElementById('perm-picker-search').value = '';
  renderPermPickerList();
});
document.getElementById('perm-picker-search')?.addEventListener('input', renderPermPickerList);

document.getElementById('btn-perm-picker-apply')?.addEventListener('click', async () => {
  const g = groupsUIState.selected;
  if (!g) return;
  const listEl = document.getElementById('perm-picker-list');
  if (!listEl) return;
  const checked = [...listEl.querySelectorAll('input[type=\"checkbox\"]:checked')].map((cb) => cb.getAttribute('data-perm')).filter(Boolean);
  if (!checked.length) { toast('请先勾选权限', 'error'); return; }

  // 逐个添加（简单可靠）
  for (const perm of checked) {
    await api.groupGrantPerm?.(g, perm);
  }
  toast(`已添加 ${checked.length} 项权限`, 'success');
  closePermPicker();
  await loadGroupDetail(g);
});

// ===== 所有插件 =====
async function refreshPlugins() {
  if (!state.connected) return;
  const r = await api.getPlugins();
  const tbody = document.getElementById('allplugins-tbody');
  document.getElementById('plugin-count').textContent = `共 ${r.plugins ? r.plugins.length : 0} 个插件`;
  if (!r.ok || !r.plugins.length) {
    tbody.innerHTML = `<tr class="empty-row"><td colspan="5">
      <div class="empty-state">
        <svg viewBox="0 0 48 48" width="40" height="40" fill="none"><rect x="6" y="6" width="15" height="15" rx="3" stroke="#2a3348" stroke-width="2"/><rect x="27" y="6" width="15" height="15" rx="3" stroke="#2a3348" stroke-width="2"/><rect x="6" y="27" width="15" height="15" rx="3" stroke="#2a3348" stroke-width="2"/><rect x="27" y="27" width="15" height="15" rx="3" stroke="#2a3348" stroke-width="2"/></svg>
        <p>暂无插件数据（需连接服务器）</p>
      </div>
    </td></tr>`;
    return;
  }
  renderPluginsTable(r.plugins);
}

function renderPluginsTable(plugins) {
  const q = document.getElementById('plugin-search').value.toLowerCase();
  const filtered = q ? plugins.filter(p => p.Name.toLowerCase().includes(q)||p.Author.toLowerCase().includes(q)) : plugins;
  const tbody = document.getElementById('allplugins-tbody');
  if (!filtered.length) {
    tbody.innerHTML = `<tr class="empty-row"><td colspan="5"><div class="empty-state"><p>无匹配插件</p></div></td></tr>`;
    return;
  }
  tbody.innerHTML = filtered.map((p, i) => `<tr>
    <td style="color:#e8611a">${i+1}</td>
    <td><b>${escHtml(p.Name)}</b></td>
    <td><span style="color:#58a6ff;font-size:11px">${escHtml(p.Version)}</span></td>
    <td style="color:#7a8aa8">${escHtml(p.Author)}</td>
    <td><div class="td-actions">
      <button class="btn-xs" onclick="reloadPlugin('${escAttr(p.Name)}')">重载</button>
      <button class="btn-xs btn-xs-danger" onclick="unloadPlugin('${escAttr(p.Name)}')">卸载</button>
    </div></td>
  </tr>`).join('');
}

async function reloadPlugin(name) {
  const r = await api.rconCommand(`oxide.reload ${name}`);
  if (r.ok) toast(`插件 ${name} 已重载`, 'success'); else toast('重载失败', 'error');
}
async function unloadPlugin(name) {
  if (!confirm(`确认卸载插件 "${name}"?`)) return;
  const r = await api.rconCommand(`oxide.unload ${name}`);
  if (r.ok) { toast(`插件 ${name} 已卸载`, 'success'); setTimeout(refreshPlugins, 1500); }
  else toast('卸载失败', 'error');
}

document.getElementById('btn-refresh-plugins').onclick = refreshPlugins;
document.getElementById('plugin-search').addEventListener('input', async () => {
  if (!state.connected) return;
  const r = await api.getPlugins();
  renderPluginsTable(r.plugins || []);
});

// ===== 服务器配置 =====
document.querySelectorAll('.weather-btn').forEach(btn => {
  btn.onclick = async () => {
    if (!state.connected) { toast('未连接服务器', 'error'); return; }
    const prev = document.querySelector('.weather-btn.active');
    document.querySelectorAll('.weather-btn').forEach(b => b.disabled = true);
    const r = await api.serverSetWeather(btn.dataset.w);
    document.querySelectorAll('.weather-btn').forEach(b => b.disabled = false);
    if (r.ok) {
      document.querySelectorAll('.weather-btn').forEach(b => b.classList.remove('active'));
      btn.classList.add('active');
      toast('天气已设置: ' + btn.textContent, 'success');
    } else {
      if (prev) {
        document.querySelectorAll('.weather-btn').forEach(b => b.classList.remove('active'));
        prev.classList.add('active');
      }
      toast('设置失败: ' + (r.error || '未知错误'), 'error');
    }
  };
});

// 服务器维护：save/writecfg/status/info
function formatMaintOutputMessage(msg) {
  const s = String(msg || '');
  if (!s.trim()) return '(无回包)';
  const lines = s.split(/\r?\n/);
  const out = lines.map((line) => {
    const l = String(line || '');
    const m1 = l.match(/^\s*server\.description\s*[:=]\s*"([\s\S]*)"\s*$/i);
    if (m1) return m1[1];
    const m2 = l.match(/^\s*server\.description\s*[:=]\s*([\s\S]*)$/i);
    if (m2) return String(m2[1] || '').trim().replace(/^"+|"+$/g, '').trim();
    return l;
  });
  return out.join('\n').trim();
}

function localizeMaintLabel(label) {
  const key = String(label || '').trim();
  const map = {
    'server.save': '保存配置（server.save）',
    'server.writecfg': '写入配置（server.writecfg）',
    status: '服务器状态（status）',
    'server.info': '服务器信息（server.info）'
  };
  return map[key] || key;
}

function appendMaintOutput(label, r) {
  const ta = document.getElementById('server-maint-output');
  if (!ta) return;
  const ts = new Date().toLocaleTimeString('zh-CN', { hour12: false });
  const ok = r && r.ok;
  const rawMsg = ok ? (r.message || '') : (r?.error || '未知错误');
  const msg = ok ? formatMaintOutputMessage(rawMsg) : String(rawMsg || '未知错误');
  ta.value = `${ta.value}${ta.value ? '\n\n' : ''}[${ts}] ${localizeMaintLabel(label)}\n${msg}`.trim();
  ta.scrollTop = ta.scrollHeight;
}

document.getElementById('btn-server-save')?.addEventListener('click', async () => {
  if (!state.connected) { toast('未连接服务器', 'error'); return; }
  const r = await api.serverSave?.();
  appendMaintOutput('server.save', r);
  if (r && r.ok) toast('已执行 server.save', 'success'); else toast('执行失败', 'error');
});
document.getElementById('btn-server-writecfg')?.addEventListener('click', async () => {
  if (!state.connected) { toast('未连接服务器', 'error'); return; }
  const r = await api.serverWriteCfg?.();
  appendMaintOutput('server.writecfg', r);
  if (r && r.ok) toast('已执行 server.writecfg', 'success'); else toast('执行失败', 'error');
});
document.getElementById('btn-server-status')?.addEventListener('click', async () => {
  if (!state.connected) { toast('未连接服务器', 'error'); return; }
  const r = await api.serverStatus?.();
  appendMaintOutput('status', r);
  if (r && r.ok) toast('已获取 status', 'success'); else toast('获取失败', 'error');
});
document.getElementById('btn-server-info')?.addEventListener('click', async () => {
  if (!state.connected) { toast('未连接服务器', 'error'); return; }
  const r = await api.serverInfo?.();
  appendMaintOutput('server.info', r);
  if (r && r.ok) toast('已获取 server.info', 'success'); else toast('获取失败', 'error');
});
document.getElementById('btn-copy-maint-output')?.addEventListener('click', async () => {
  const ta = document.getElementById('server-maint-output');
  const v = ta?.value || '';
  if (!v.trim()) { toast('没有可复制的内容', 'error'); return; }
  await navigator.clipboard.writeText(v);
  toast('已复制输出', 'success');
});
document.getElementById('btn-clear-maint-output')?.addEventListener('click', () => {
  const ta = document.getElementById('server-maint-output');
  if (ta) ta.value = '';
});

async function loadServerConfigSnapshot() {
  if (!state.connected) return;
  const r = await api.serverGetConvars?.([
    'server.hostname',
    'server.description',
    'server.headerimage',
    'server.url',
    'server.tags',
    'heli.bulletdamagescale',
    'spawn.max_density',
    'spawn.min_density',
    'spawn.max_rate',
    'spawn.min_rate',
    'server.maxteamsize'
  ]);
  if (!r || !r.ok) return;
  const v = r.values || {};
  const setVal = (id, val) => { const el = document.getElementById(id); if (el && val != null && val !== '') el.value = val; };
  setVal('cfg-hostname', v['server.hostname']);
  setVal('cfg-desc', v['server.description']);
  setVal('cfg-logo', v['server.headerimage']);
  setVal('team-limit', v['server.maxteamsize']);
  setVal('heli-dmg', v['heli.bulletdamagescale']);
  setVal('res-maxden', v['spawn.max_density']);
  setVal('res-minden', v['spawn.min_density']);
  setVal('res-maxspd', v['spawn.max_rate']);
  setVal('res-minspd', v['spawn.min_rate']);
}

// NPC / CombatLog
document.getElementById('btn-npc-on')?.addEventListener('click', async () => {
  if (!state.connected) { toast('未连接服务器', 'error'); return; }
  const r = await api.serverNpcEnabled?.(true);
  if (r && r.ok) toast('NPC 已开启', 'success'); else toast('NPC 开启失败', 'error');
});
document.getElementById('btn-npc-off')?.addEventListener('click', async () => {
  if (!state.connected) { toast('未连接服务器', 'error'); return; }
  const r = await api.serverNpcEnabled?.(false);
  if (r && r.ok) toast('NPC 已关闭', 'success'); else toast('NPC 关闭失败', 'error');
});
document.getElementById('btn-set-combatlog')?.addEventListener('click', async () => {
  if (!state.connected) { toast('未连接服务器', 'error'); return; }
  const v = parseInt(document.getElementById('combatlog-size')?.value, 10);
  if (!Number.isFinite(v) || v < 0) { toast('请输入有效数值', 'error'); return; }
  const r = await api.serverCombatLog?.(v);
  if (r && r.ok) toast('combatlogsize 已设置', 'success'); else toast('设置失败', 'error');
});

document.getElementById('btn-set-hostname').onclick = async () => {
  const name = document.getElementById('cfg-hostname').value.trim();
  if (!name) { toast('请输入服务器名称', 'error'); return; }
  const r = await api.serverSetHostname(name);
  if (r.ok) toast('服务器名称已修改', 'success'); else toast('修改失败: ' + r.error, 'error');
};

document.getElementById('btn-copy-link').onclick = () => {
  const link = document.getElementById('cfg-serverlink').value.trim();
  if (!link) { toast('请先输入链接', 'error'); return; }
  navigator.clipboard.writeText(link).then(() => toast('链接已复制', 'success'));
};

document.getElementById('btn-set-logo').onclick = async () => {
  const logo = document.getElementById('cfg-logo').value.trim();
  if (!state.connected) { toast('未连接服务器', 'error'); return; }
  const r = await api.serverSetConvar?.('server.headerimage', logo);
  if (r && r.ok) toast('HeaderImage 已设置', 'success'); else toast('设置失败', 'error');
};

document.getElementById('btn-set-desc').onclick = () => {
  const desc = document.getElementById('cfg-desc').value.trim();
  if (!state.connected) { toast('未连接服务器', 'error'); return; }
  (async () => {
    const r = await api.serverSetConvar?.('server.description', desc);
    if (!r || !r.ok) { toast('设置失败', 'error'); return; }

    // 立即读取校验一次，确认确实写入（避免权限不足/插件拦截导致“看似成功”）
    const vr = await api.serverGetConvars?.(['server.description']);
    const now = vr && vr.ok ? String((vr.values || {})['server.description'] || '').trim() : '';
    if (now && now === desc) toast('服务器介绍已保存（已校验）', 'success');
    else toast('服务器介绍已提交（未校验到一致值）', 'info');
  })().catch(() => toast('设置失败', 'error'));
};

document.getElementById('btn-set-team').onclick = async () => {
  const n = document.getElementById('team-limit').value;
  if (!n) { toast('请输入人数', 'error'); return; }
  const r = await api.serverTeamLimit(parseInt(n));
  if (r.ok) toast('组队限制已设置: ' + n, 'success'); else toast('设置失败', 'error');
};
document.getElementById('btn-default-team').onclick = async () => {
  const r = await api.serverTeamLimit(8);
  if (r.ok) toast('组队限制已恢复默认(8)', 'success');
};

document.getElementById('btn-set-time').onclick = async () => {
  const t = document.getElementById('server-time').value;
  if (t === '' || t === null) { toast('请输入时间值', 'error'); return; }
  const r = await api.serverSetTime(parseFloat(t));
  if (r.ok) toast('服务器时间已设置: ' + t, 'success'); else toast('设置失败', 'error');
};

document.getElementById('btn-set-heli-time').onclick = async () => {
  const t = document.getElementById('heli-time').value;
  if (!t) { toast('请输入时间', 'error'); return; }
  const r = await api.rconCommand(`heli.calltimer ${t}`);
  if (r.ok) toast('巡逻时间已设置', 'success'); else toast('设置失败', 'error');
};
document.getElementById('btn-set-heli-dmg').onclick = async () => {
  const d = document.getElementById('heli-dmg').value;
  if (!d) { toast('请输入伤害值', 'error'); return; }
  const r = await api.rconCommand(`heli.bulletdamagescale ${d}`);
  if (r.ok) {
    toast('伤害数值已设置', 'success');
    // 写入配置，防止重启丢失（可手动取消）
  } else toast('设置失败', 'error');
};
document.getElementById('btn-heli-no-gun').onclick = async () => {
  await api.rconCommand('heli.bulletdamagescale 0');
  toast('武直已设为不开枪', 'success');
};
document.getElementById('btn-heli-gun').onclick = async () => {
  await api.rconCommand('heli.bulletdamagescale 1');
  toast('武直已恢复开枪', 'success');
};
document.getElementById('btn-heli-default').onclick = async () => {
  await api.rconCommand('heli.bulletdamagescale 0.5');
  toast('武直已还原默认值', 'success');
};

document.getElementById('btn-scale-on').onclick = async () => {
  await api.rconCommand('server.pvpscale 1');
  toast('承重模式已开启', 'success');
};
document.getElementById('btn-scale-off').onclick = async () => {
  await api.rconCommand('server.pvpscale 0');
  toast('承重模式已关闭', 'success');
};

document.querySelectorAll('[data-res]').forEach(btn => {
  btn.onclick = async () => {
    const type = btn.dataset.res;
    const inputMap = { maxden: 'res-maxden', minden: 'res-minden', maxspd: 'res-maxspd', minspd: 'res-minspd' };
    const val = document.getElementById(inputMap[type])?.value;
    if (!val) { toast('请输入数值', 'error'); return; }
    const cmdMap = {
      maxden: `spawn.max_density ${val}`,
      minden: `spawn.min_density ${val}`,
      maxspd: `spawn.max_rate ${val}`,
      minspd: `spawn.min_rate ${val}`
    };
    const r = await api.rconCommand(cmdMap[type]);
    if (r.ok) toast('设置成功', 'success'); else toast('设置失败', 'error');
  };
});

document.getElementById('btn-confirm-tags').onclick = async () => {
  const checked = [...document.querySelectorAll('.tag-chip input:checked')].map(i => i.value);
  if (checked.length > 4) { toast('最多只能选择4个标签', 'error'); return; }
  // 参考 Rust 服务器标签：server.tags "weekly,vanilla"
  const r = await api.rconCommand(`server.tags "${checked.join(',')}"`);
  if (r.ok) toast('服务器标签已更新', 'success'); else toast('标签设置失败', 'error');
};

// ===== 玩家授权 =====
function showPermResult(msg, ok) {
  const el = document.getElementById('perm-result');
  if (!el) return;
  el.textContent = (ok ? '✓ ' : '✗ ') + msg;
  el.className = `perm-result show ${ok ? 'ok' : 'err'}`;
}

// （旧版 perm-name / btn-grant-user 等控件已移除，授权请使用「玩家授权」页内的网格与按钮。）

// ===== FPS / 实体：解析 RCON 常见格式（含 "convar" = "值"、纯数字、多数字取实体最大值等） =====
function parseFpsFromRconMessage(msg) {
  const s = String(msg || '').trim();
  if (!s) return null;
  const q = s.match(/=\s*"([\d.]+)"|=\s*([\d.]+)\s/);
  if (q) return String(Math.round(parseFloat(q[1] || q[2])));
  const m = s.match(/(\d+\.?\d*)\s*fps/i) || s.match(/fps[:\s]+(\d+\.?\d*)/i);
  if (m) return String(Math.round(parseFloat(m[1])));
  const one = s.match(/^([\d.]+)\s*$/);
  if (one) {
    const v = parseFloat(one[1]);
    if (v >= 1 && v <= 2000) return String(Math.round(v));
  }
  const nums = s.match(/\d+\.?\d*/g);
  if (!nums) return null;
  const vals = nums.map((x) => parseFloat(x)).filter((n) => n >= 1 && n <= 2000);
  if (!vals.length) return null;
  return String(Math.round(vals[0]));
}

function parseEntitiesFromRconMessage(msg) {
  const s = String(msg || '').replace(/,/g, ' ').trim();
  if (!s) return null;

  const low = s.toLowerCase();
  if (/unknown command|command not found|not available|no permission/i.test(low)) return null;

  // 常见直接格式：Entities: 123 / entities = 123 / server.entities = "123"
  const named =
    s.match(/server\.(?:entities)\s*[^0-9-]{0,20}(-?\d+)/i) ||
    s.match(/entities\s*[^0-9-]{0,20}(-?\d+)/i) ||
    s.match(/entity\s*(?:count|#)?\s*[^0-9-]{0,20}(-?\d+)/i);

  if (named && named[1] != null) {
    const n = parseInt(named[1], 10);
    if (!Number.isNaN(n) && n >= 0 && n <= 200000000) return String(n);
  }

  // 纯数字：123
  const sole = s.match(/^(\d+)$/);
  if (sole) return sole[1];

  // 兜底：提取所有数字，尽量避开常见端口号干扰
  const nums = s.match(/\d+/g);
  if (!nums || !nums.length) return null;

  const vals = nums.map((x) => parseInt(x, 10)).filter((n) => n >= 0 && n <= 200000000);
  if (!vals.length) return null;

  const skipPorts = new Set([25575, 28016, 28015, 27015, 27016]);
  const candidates = vals.filter((n) => !skipPorts.has(n) || vals.length === 1);
  return String(Math.max(...(candidates.length ? candidates : vals)));
}

function applyServerStatsFromConsoleText(text) {
  const t = String(text || '');
  if (!t.trim()) return;

  if (/server\.fps\b|["']server\.fps["']\s*=/i.test(t)) {
    const v = parseFpsFromRconMessage(t);
    if (v != null) {
      const el = document.getElementById('stat-fps');
      if (el) el.textContent = v;
    }
  }
  applyJoinQueueStatsFromStatusText(t);
}

function applyJoinQueueStatsFromStatusText(text) {
  const t = String(text || '').toLowerCase();
  if (!t.trim()) return;
  // Rust 常见 status 文本包含: joining: X, queued: Y
  const joiningMatch = /joining[^0-9]*([0-9]+)/i.exec(t);
  const queueMatch = /(queued|queue)[^0-9]*([0-9]+)/i.exec(t);
  if (joiningMatch) {
    const v = Number(joiningMatch[1] || 0);
    const el = document.getElementById('stat-joining');
    if (el) el.textContent = Number.isFinite(v) ? String(v) : '0';
  }
  if (queueMatch) {
    const v = Number(queueMatch[2] || 0);
    const el = document.getElementById('stat-queue');
    if (el) el.textContent = Number.isFinite(v) ? String(v) : '0';
  }
}

let statsPollingInFlight = false;
let statusPollTick = 0;
async function pollServerStats() {
  if (!state.connected) return;
  if (statsPollingInFlight) return;
  statsPollingInFlight = true;

  try {
    const r = await api.rconCommandSilent('server.fps');
    if (r.ok && !r.timeout && r.message) {
      const v = parseFpsFromRconMessage(r.message);
      if (v != null) {
        const el = document.getElementById('stat-fps');
        if (el) el.textContent = v;
      }
    }
    // 每 5 秒拉一次 status，用于“加入中/排队”统计
    statusPollTick = (statusPollTick + 1) % 5;
    if (statusPollTick === 0) {
      const s = await api.rconCommandSilent('status');
      if (s?.ok && !s.timeout && s.message) {
        applyJoinQueueStatsFromStatusText(s.message);
      }
    }
  } catch {}
  finally {
    statsPollingInFlight = false;
  }
}

// ===== FPS/实体 自动更新 =====
setInterval(pollServerStats, 1000);

// ===== 工具函数 =====
function escHtml(str) {
  if (!str) return '';
  return String(str).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;');
}
function escAttr(str) {
  if (!str) return '';
  return String(str).replace(/'/g,"\\'").replace(/"/g,'\\"');
}
function formatDuration(sec) {
  if (!sec) return '-';
  const h = Math.floor(sec / 3600);
  const m = Math.floor((sec % 3600) / 60);
  return h > 0 ? `${h}h${m}m` : `${m}m`;
}

// ===== 主题切换 =====
let currentTheme = 'dark';
function applyTheme(theme) {
  currentTheme = theme === 'light' ? 'light' : 'dark';
  // 同时设置 html/body，避免变量作用域差异导致主题不生效
  document.documentElement.setAttribute('data-theme', currentTheme);
  document.body.setAttribute('data-theme', currentTheme);
  localStorage.setItem('rustadmin-theme', currentTheme);
  const darkIcon = document.getElementById('theme-icon-dark');
  const lightIcon = document.getElementById('theme-icon-light');
  if (darkIcon) darkIcon.style.display = currentTheme === 'dark' ? '' : 'none';
  if (lightIcon) lightIcon.style.display = currentTheme === 'light' ? '' : 'none';
}

document.getElementById('theme-toggle-btn')?.addEventListener('click', () => {
  applyTheme(currentTheme === 'dark' ? 'light' : 'dark');
});

// ===== 最新 Rust 新闻滚动条 =====
const FALLBACK_NEWS = [
  { tag: '大更新', tagClass: '', zh: 'Spring Clean 更新 — 新增装甲梯舱盖(Armored Ladder Hatch)与水轮(Water Wheel)，大量生活质量改进、错误修复与性能优化' },
  { tag: 'DevBlog', tagClass: 'news-tag-warp', zh: 'Shipshape 更新 — 水上及深海居住、建造、战斗全面改进，延长白天时间' },
  { tag: 'DLC', tagClass: 'news-tag-warp', zh: 'Box DLC 上线 — 深海船只改动，船载电气部署，更多新内容' },
  { tag: '大型DLC', tagClass: 'news-tag-warp', zh: 'Naval Update 正式上线 — 可建造船只、深海探索、热带岛屿、幽灵船、改进版AI' },
  { tag: '节日', tagClass: 'news-tag-warp', zh: '农历新年2026 — 马面具、马甲等马年纪念道具上线' },
  { tag: '社区', tagClass: 'news-tag', zh: '社区更新268 — 海军测试、Twitch Drops、圣诞节活动回顾' },
  { tag: '周年庆', tagClass: 'news-tag', zh: 'Rust 十二周年庆典 — 游戏持续保持强劲增长势头' },
];

async function appendNewsDots() {
  const track = document.getElementById('news-ticker-track');
  if (!track) return;
  const content = track.querySelector('.news-ticker-content');
  if (!content) return;
  // 优先从后端获取最新新闻
  let newsData = FALLBACK_NEWS;
  try {
    const liveNews = await api.getRustNews();
    if (liveNews && liveNews.length > 0) {
      newsData = liveNews.map(n => ({
        tag: n.tag || '新闻',
        tagClass: n.tag === 'DEVBLOG' ? 'news-tag-warp' : '',
        zh: n.title ? `${n.title} — ${n.desc}` : (n.zh || n.title || '')
      }));
    }
  } catch {}
  // 构建双倍内容实现无缝滚动
  let html = '';
  for (let i = 0; i < 2; i++) {
    newsData.forEach(news => {
      html += `<span class="news-tag ${news.tagClass || ''}">${escHtml(news.tag)}</span>`;
      html += `<span class="news-item">${escHtml(news.zh)}</span>`;
      html += `<span class="news-dot">●</span>`;
    });
  }
  content.innerHTML = html;
}

// ===== 玩家授权（新界面）状态 =====
const PERM_OPTIONS = [
  { name: '基础权限', perms: [
    { label: '使用箱子', value: 'can_use_storages', code: 'can_use_storages' },
    { label: '使用工作台', value: 'workbench.use', code: 'workbench.use' },
    { label: '建造权限', value: 'building.manage', code: 'building.manage' },
    { label: '友方伤害', value: 'friendlyfire.use', code: 'friendlyfire.use' },
  ]},
  { name: '经济权限', perms: [
    { label: '给予物品', value: 'inventory.give', code: 'inventory.give' },
    { label: '给予金币', value: 'economics.grant', code: 'economics.grant' },
    { label: '给予积分', value: 'sr.grant', code: 'sr.grant' },
    { label: '交易权限', value: 'trading.use', code: 'trading.use' },
  ]},
  { name: '管理权限', perms: [
    { label: '踢出玩家', value: 'player.kick', code: 'player.kick' },
    { label: '封禁玩家', value: 'player.ban', code: 'player.ban' },
    { label: '传送玩家', value: 'player.teleport', code: 'player.teleport' },
    { label: '聊天管理', value: 'chat.enabled', code: 'chat.enabled' },
  ]},
  { name: 'VIP权限', perms: [
    { label: 'VIP权限', value: 'vip.use', code: 'vip.use' },
    { label: 'VIP飞行', value: 'vip.fly', code: 'vip.fly' },
    { label: 'VIP传送', value: 'vip.teleport', code: 'vip.teleport' },
    { label: 'VIP保护', value: 'vip.protect', code: 'vip.protect' },
  ]},
];

// ===== 管理员指令（模板中 {参数名} 可多处出现，发送时全部替换） =====
const ADMIN_COMMANDS = [
  {
    category: '基础查询与维护',
    icon: '📋',
    commands: [
      { name: '保存地图', desc: '立即保存当前地图与世界状态', code: 'server.save', example: 'server.save' },
      { name: '写入配置', desc: '把当前 convar 写入配置文件', code: 'server.writecfg', example: 'server.writecfg' },
      { name: '服务器状态', desc: '显示在线、帧率、内存等状态', code: 'status', example: 'status' },
      { name: '服务器信息', desc: '显示服务器基础配置信息', code: 'server.info', example: 'server.info' },
      { name: '在线列表', desc: '输出在线玩家 JSON 列表', code: 'playerlist', example: 'playerlist' },
      { name: '封禁列表', desc: '查看当前封禁列表', code: 'banlist', example: 'banlist' }
    ]
  },
  {
    category: '玩家管理',
    icon: '👤',
    commands: [
      { name: '全服广播', desc: '向全服发送聊天公告', code: 'say {message}', example: 'say 服务器将在 10 分钟后重启' },
      { name: '踢出玩家', desc: '踢出在线玩家（建议附带原因）', code: 'kick {steamid} {reason}', example: 'kick 76561198012345678 违反规则' },
      { name: '封禁玩家', desc: '封禁玩家并写入 banlist', code: 'ban {steamid} {reason}', example: 'ban 76561198012345678 使用外挂' },
      { name: '解封玩家', desc: '从封禁列表中移除', code: 'unban {steamid}', example: 'unban 76561198012345678' },
      { name: '禁言玩家', desc: '需服务器/插件支持 mute 指令', code: 'mute {steamid} {minutes}', example: 'mute 76561198012345678 60' },
      { name: '解除禁言', desc: '需服务器/插件支持 unmute', code: 'unmute {steamid}', example: 'unmute 76561198012345678' }
    ]
  },
  {
    category: '传送与天气时间',
    icon: '🌤',
    commands: [
      { name: '传送到领地柜', desc: '传送到玩家最近领地柜（服务器支持时）', code: 'teleport2owneditem {steamid}', example: 'teleport2owneditem 76561198012345678' },
      { name: '坐标传送', desc: '按 XYZ 坐标传送', code: 'teleport {x} {y} {z}', example: 'teleport 0 100 0' },
      { name: '设置时间', desc: '设置服务器游戏时间（0-24）', code: 'env.time {hour}', example: 'env.time 12' },
      { name: '晴天', desc: '清空天气效果', code: 'weather.reset', example: 'weather.reset' },
      { name: '暴雨', desc: '加载暴雨预设（推荐）', code: 'weather.load Storm', example: 'weather.load Storm' },
      { name: '浓雾', desc: '加载浓雾预设', code: 'weather.load Fog', example: 'weather.load Fog' }
    ]
  },
  {
    category: '服务器配置',
    icon: '⚙️',
    commands: [
      { name: '修改主机名', desc: '修改服务器名称（支持中文）', code: 'server.hostname "{name}"', example: 'server.hostname "我的 Rust 服"' },
      { name: '修改介绍', desc: '修改服务器介绍文本', code: 'server.description "{message}"', example: 'server.description "欢迎新玩家加入"' },
      { name: '设置队伍上限', desc: '设置最大组队人数', code: 'server.maxteamsize {n}', example: 'server.maxteamsize 8' },
      { name: 'NPC 开关', desc: 'true=开启，false=关闭', code: 'global.npc_enabled {bool}', example: 'global.npc_enabled true' },
      { name: '战斗日志长度', desc: '设置 combatlog 条数', code: 'server.combatlogsize {n}', example: 'server.combatlogsize 30' },
      { name: '武直机枪伤害倍率', desc: '0=不开枪，1=原始倍率', code: 'heli.bulletdamagescale {v}', example: 'heli.bulletdamagescale 0.5' }
    ]
  },
  {
    category: '资源刷新与经济插件',
    icon: '💰',
    commands: [
      { name: '资源最大密度', desc: '资源节点刷新密度上限', code: 'spawn.max_density {v}', example: 'spawn.max_density 1' },
      { name: '资源最小密度', desc: '资源节点刷新密度下限', code: 'spawn.min_density {v}', example: 'spawn.min_density 0.35' },
      { name: '资源最大速率', desc: '资源刷新速率上限', code: 'spawn.max_rate {v}', example: 'spawn.max_rate 1' },
      { name: '资源最小速率', desc: '资源刷新速率下限', code: 'spawn.min_rate {v}', example: 'spawn.min_rate 0.35' },
      { name: '给予物品（插件）', desc: '需支持 inventory.give 的插件', code: 'inventory.give {steamid} {shortname} {amount}', example: 'inventory.give 76561198012345678 wood 1000' },
      { name: '充值金币（Economics）', desc: '需 Economics 插件', code: 'economics.deposit {steamid} {amount}', example: 'economics.deposit 76561198012345678 5000' }
    ]
  },
  {
    category: 'Oxide 插件管理',
    icon: '🔌',
    commands: [
      { name: 'Oxide 版本', desc: '显示 Oxide/uMod 版本', code: 'oxide.version', example: 'oxide.version' },
      { name: '插件列表', desc: '显示已加载插件', code: 'oxide.plugins', example: 'oxide.plugins' },
      { name: '重载插件', desc: '插件名不要带 .cs', code: 'oxide.reload {plugin}', example: 'oxide.reload Vanish' },
      { name: '卸载插件', desc: '从内存卸载插件', code: 'oxide.unload {plugin}', example: 'oxide.unload Vanish' },
      { name: '加载插件', desc: '重新加载已存在插件文件', code: 'oxide.load {plugin}', example: 'oxide.load Vanish' },
      { name: '重载全部插件', desc: '高风险，可能造成短暂卡顿', code: 'oxide.reload *', example: 'oxide.reload *', dangerous: true, confirm: '将重载所有 Oxide 插件，可能造成短暂卡顿，确定执行？' }
    ]
  },
  {
    category: 'GM命令 1.5（集成）',
    icon: '🧰',
    commands: [
      { name: '无敌开关', desc: '1 开启 / 0 关闭', code: 'god {bool}', example: 'god 1' },
      { name: 'PVE 开关', desc: '1 开启 / 0 关闭', code: 'pve {bool}', example: 'pve 1' },
      { name: '建筑稳定性开关', desc: '1 开启 / 0 关闭', code: 'stability {bool}', example: 'stability 1' },
      { name: '海平面高度', desc: '通常设为 0', code: 'sv env.oceanlevel {v}', example: 'sv env.oceanlevel 0' },
      { name: '传送到地图标记', desc: '传送到当前地图标记位置', code: 'teleport2marker', example: 'teleport2marker' },
      { name: '武直巡逻时长(分钟)', desc: '设置武直存在时长', code: 'heli.lifetimeminutes {n}', example: 'heli.lifetimeminutes 15' },
      { name: '武直机枪开关', desc: '1 开启 / 0 关闭', code: 'heli.guns {bool}', example: 'heli.guns 1' },
      { name: '天气-雨强度', desc: '0-1', code: 'weather.rain {v}', example: 'weather.rain 1' },
      { name: '天气-雾强度', desc: '0-1', code: 'weather.fog {v}', example: 'weather.fog 0.5' },
      { name: '天气-云强度', desc: '0-1', code: 'weather.cloud {v}', example: 'weather.cloud 1' },
      { name: '天气-风强度', desc: '0-1', code: 'weather.wind {v}', example: 'weather.wind 1' },
      { name: '实体半径查询', desc: '查询半径范围内实体数量', code: 'entity.find_radius {n}', example: 'entity.find_radius 50' },
      { name: '聊天禁言(名字)', desc: '按名字禁言聊天', code: 'mutechat {name}', example: 'mutechat ABC' },
      { name: '聊天解禁(名字)', desc: '解除聊天禁言', code: 'unmutechat {name}', example: 'unmutechat ABC' },
      { name: '腐蚀倍率', desc: '1 默认 / 0 关闭', code: 'decay.scale {v}', example: 'decay.scale 0' },
      { name: '生成动物-熊', code: 'entity.spawn bear', example: 'entity.spawn bear' },
      { name: '生成动物-狼', code: 'entity.spawn wolf', example: 'entity.spawn wolf' },
      { name: '生成动物-鹿', code: 'entity.spawn stag', example: 'entity.spawn stag' },
      { name: '生成动物-马', code: 'entity.spawn horse', example: 'entity.spawn horse' },
      { name: '生成科学家(M249)', code: 'entity.spawn scientist_gunner', example: 'entity.spawn scientist_gunner' },
      { name: '生成普通科学家', code: 'entity.spawn Scientist', example: 'entity.spawn Scientist' },
      { name: '生成重装科学家', code: 'spawn heavyscientist', example: 'spawn heavyscientist' },
      { name: '生成武直', code: 'heli.call', example: 'heli.call' },
      { name: '武直到我位置', code: 'heli.calltome', example: 'heli.calltome' },
      { name: '当前点投放武直补给', code: 'heli.drop', example: 'heli.drop' },
      { name: '生成坦克', code: 'entity.spawn bradleyapc', example: 'entity.spawn bradleyapc' },
      { name: '生成货船', code: 'spawn cargoshiptest', example: 'spawn cargoshiptest' },
      { name: '生成小直升机', code: 'entity.spawn minicopter', example: 'entity.spawn minicopter' },
      { name: '生成划艇', code: 'entity.spawn rowboat', example: 'entity.spawn rowboat' },
      { name: '生成 RHIB 快艇', code: 'spawn rhib', example: 'spawn rhib' },
      { name: '生成双人潜艇', code: 'entity.spawn submarineduo.entity', example: 'entity.spawn submarineduo.entity' },
      { name: '生成单人潜艇', code: 'entity.spawn submarinesolo.entity', example: 'entity.spawn submarinesolo.entity' },
      { name: '生成空投箱', code: 'entity.spawn supply_drop', example: 'entity.spawn supply_drop' },
      { name: '生成精英箱', code: 'entity.spawn crate_elite', example: 'entity.spawn crate_elite' },
      { name: '生成坦克箱', code: 'entity.spawn bradley_crate', example: 'entity.spawn bradley_crate' },
      { name: '生成武直箱', code: 'entity.spawn heli_crate', example: 'entity.spawn heli_crate' },
      { name: '生成油井', code: 'entity.spawn survey_crater_oil', example: 'entity.spawn survey_crater_oil' },
      { name: '生成采油机', code: 'entity.spawn pumpjack-static', example: 'entity.spawn pumpjack-static' },
      { name: '生成采矿机', code: 'entity.spawn MiningQuarry', example: 'entity.spawn MiningQuarry' },
      { name: '生成领地柜', code: 'entity.spawn cupboard.tool', example: 'entity.spawn cupboard.tool' },
      { name: '生成大型熔炉', code: 'entity.spawn furnace.large', example: 'entity.spawn furnace.large' },
      { name: '封禁ID', desc: '按 SteamID 直接封禁', code: 'banid {steamid} {reason}', example: 'banid 76561198012345678 违规行为' },
      { name: '进入旁观', desc: '进入旁观指定玩家（需支持）', code: 'spectate {steamid}', example: 'spectate 76561198012345678' },
      { name: '退出旁观并重生', code: 'respawn me', example: 'respawn me' },
      { name: '解锁当前瞄准实体', code: 'ent unlock', example: 'ent unlock' },
      { name: '锁定当前瞄准实体', code: 'ent lock', example: 'ent lock' },
      { name: '查询当前瞄准实体所有者', code: 'ent who', example: 'ent who' },
      { name: '解锁全部蓝图', desc: '管理员本地角色生效', code: 'inventory.unlockall', example: 'inventory.unlockall' },
      { name: '给自己物品', code: 'giveto {shortname} {amount}', example: 'giveto wood 1000' },
      { name: '给所有玩家物品', code: 'giveall {shortname} {amount}', example: 'giveall wood 1000' },
      { name: '绑定穿墙飞行键(C)', desc: '客户端绑定命令，需在客户端控制台执行', code: 'bind c noclip', example: 'bind c noclip' },
      { name: '绑定删除瞄准实体键(X)', desc: '客户端绑定命令，危险操作', code: 'bind x ent kill', example: 'bind x ent kill', dangerous: true, confirm: '该快捷键会直接删除瞄准实体，确认继续？' },
      { name: '生成鸡', code: 'entity.spawn chicken', example: 'entity.spawn chicken' },
      { name: '生成野猪', code: 'entity.spawn boar', example: 'entity.spawn boar' },
      { name: '生成石矿节点', code: 'entity.spawn stone-ore', example: 'entity.spawn stone-ore' },
      { name: '生成硫矿节点', code: 'entity.spawn sulfur-ore', example: 'entity.spawn sulfur-ore' },
      { name: '生成金属矿节点', code: 'entity.spawn Metal-ore', example: 'entity.spawn Metal-ore' },
      { name: '生成僵尸', code: 'entity.spawn zombie', example: 'entity.spawn zombie' },
      { name: '生成持刀僵尸', code: 'entity.spawn murderer', example: 'entity.spawn murderer' },
      { name: '生成和平科学家', code: 'entity.spawn scientistpeacekeeper', example: 'entity.spawn scientistpeacekeeper' },
      { name: '生成路堆科学家', code: 'entity.spawn scientistjunkpile', example: 'entity.spawn scientistjunkpile' },
      { name: '生成货机', code: 'entity.spawn cargo_plane', example: 'entity.spawn cargo_plane' },
      { name: '生成科考队 CH47', code: 'entity.spawn ch47scientists.entity', example: 'entity.spawn ch47scientists.entity' },
      { name: '生成可驾驶 CH47', code: 'entity.spawn ch47.entity', example: 'entity.spawn ch47.entity' },
      { name: '生成轿车', code: 'entity.spawn sedan', example: 'entity.spawn sedan' },
      { name: '生成热气球', code: 'spawn hotair', example: 'spawn hotair' },
      { name: '生成工作矿车', code: 'spawn workcart.entity', example: 'spawn workcart.entity' },
      { name: '生成自动炮台(科学家)', code: 'entity.spawn sentry.scientist.static', example: 'entity.spawn sentry.scientist.static' },
      { name: '生成普通桶(蓝)', code: 'entity.spawn loot-barrel-1', example: 'entity.spawn loot-barrel-1' },
      { name: '生成普通桶(红)', code: 'entity.spawn loot-barrel-2', example: 'entity.spawn loot-barrel-2' },
      { name: '生成油桶', code: 'entity.spawn oil_barrel', example: 'entity.spawn oil_barrel' },
      { name: '生成食物箱', code: 'entity.spawn foodbox', example: 'entity.spawn foodbox' },
      { name: '生成工具箱', code: 'entity.spawn crate_tools', example: 'entity.spawn crate_tools' },
      { name: '生成普通箱', code: 'entity.spawn crate_normal', example: 'entity.spawn crate_normal' },
      { name: '生成医疗箱', code: 'entity.spawn crate_normal_2_medical', example: 'entity.spawn crate_normal_2_medical' },
      { name: '生成食物箱(普通)', code: 'entity.spawn crate_normal_2_food', example: 'entity.spawn crate_normal_2_food' },
      { name: '生成黑客锁箱', code: 'entity.spawn codelockedhackablecrate', example: 'entity.spawn codelockedhackablecrate' },
      { name: '生成水泵', code: 'spawn water.pump.deployed', example: 'spawn water.pump.deployed' },
      { name: '查询地道贴图目录', code: 'world.rendertunnels', example: 'world.rendertunnels' },
      { name: '生成树-冷杉', code: 'entity.spawn douglas_fir_a', example: 'entity.spawn douglas_fir_a' },
      { name: '生成树-山毛榉', code: 'entity.spawn american_beech_a', example: 'entity.spawn american_beech_a' },
      { name: '生成树-橡树', code: 'entity.spawn oak_b', example: 'entity.spawn oak_b' },
      { name: '生成树-沼泽树', code: 'entity.spawn swamp_tree_a', example: 'entity.spawn swamp_tree_a' }
    ]
  }
];

// ===== 使用日志状态 =====
let usageLogData = [];
let usageLogFilter = 'all';

const USAGE_FILTER_BTN_ID = {
  all: 'usage-filter-all',
  rcon_command: 'usage-filter-cmd',
  player_permission: 'usage-filter-perm',
  server_config: 'usage-filter-config',
};

function renderUsageLog() {
  const tbody = document.getElementById('usage-tbody');
  if (!tbody) return;
  const activeBtnId = USAGE_FILTER_BTN_ID[usageLogFilter] || 'usage-filter-all';
  document.querySelectorAll('#panel-usagelog .filter-btn').forEach(b => {
    b.classList.toggle('active', b.id === activeBtnId);
  });
  const filtered = usageLogFilter === 'all'
    ? usageLogData
    : usageLogData.filter(l => l.action?.startsWith(usageLogFilter));
  if (!filtered.length) {
    tbody.innerHTML = `<tr class="empty-row"><td colspan="3"><div class="empty-state"><p>暂无日志记录</p></div></td></tr>`;
    return;
  }
  const typeMap = {
    'server_connect': ['badge-connect', '连接'],
    'server_disconnect': ['badge-other', '断开'],
    'server_error': ['badge-error', '错误'],
    'rcon_command': ['badge-command', '指令'],
    'player_permission': ['badge-perm', '权限'],
    'server_config': ['badge-config', '配置'],
    'app_launched': ['badge-connect', '启动'],
    'app_closed': ['badge-other', '关闭'],
  };
  tbody.innerHTML = filtered.slice(0, 200).map(l => {
    const [tagClass, tagLabel] = typeMap[l.action] || ['badge-other', l.action || '其他'];
    const time = l.time ? new Date(l.time).toLocaleString('zh-CN') : '-';
    const details = l.details ? (l.details.command || JSON.stringify(l.details).substring(0, 80)) : '-';
    return `<tr>
      <td style="color:var(--text-muted);font-size:11px;white-space:nowrap">${time}</td>
      <td><span class="log-type-badge log-${tagClass}">${tagLabel}</span></td>
      <td style="font-size:11px;font-family:monospace;color:var(--text-secondary)">${escHtml(details)}</td>
    </tr>`;
  }).join('');
  document.getElementById('usage-log-count').textContent = `共 ${filtered.length} 条记录（最多显示200条）`;
}

async function loadUsageLog() {
  usageLogData = await api.getUsageLog();
  renderUsageLog();
}

document.getElementById('usage-filter-all')?.addEventListener('click', () => { usageLogFilter = 'all'; renderUsageLog(); });
document.getElementById('usage-filter-cmd')?.addEventListener('click', () => { usageLogFilter = 'rcon_command'; renderUsageLog(); });
document.getElementById('usage-filter-perm')?.addEventListener('click', () => { usageLogFilter = 'player_permission'; renderUsageLog(); });
document.getElementById('usage-filter-config')?.addEventListener('click', () => { usageLogFilter = 'server_config'; renderUsageLog(); });
document.getElementById('btn-export-log')?.addEventListener('click', async () => {
  const r = await api.exportUsageLog();
  if (r.ok) toast('日志已导出到桌面', 'success');
  else toast('导出失败', 'error');
});
document.getElementById('btn-clear-log')?.addEventListener('click', async () => {
  if (!confirm('确认清空所有使用日志？')) return;
  await api.clearUsageLog();
  usageLogData = [];
  renderUsageLog();
  toast('日志已清空', 'success');
});

// 定期上报使用日志到服主（echo）
async function reportUsageToOwner() {
  if (!state.connected) { toast('请先连接服务器', 'error'); return; }
  const logs = await api.getUsageLog();
  if (!logs.length) { toast('暂无日志可上报', 'info'); return; }
  const today = logs.filter(l => l.time && new Date(l.time).toDateString() === new Date().toDateString());
  if (today.length === 0) { toast('今日暂无操作记录', 'info'); return; }
  const summary = `📊 RustAdmin 使用日志 [${new Date().toLocaleDateString('zh-CN')}]: ${today.length} 条操作已记录`;
  await api.rconCommand(`say ${summary}`);
  toast(`已发送日志摘要至游戏内，共 ${today.length} 条`, 'success');
}

// ===== 玩家授权（新UI） =====
let permOnlineTab = 'online';
let permSelectedPlayers = [];
let permSelectedPerms = [];

function switchPermTab(tab) {
  permOnlineTab = tab;
  document.getElementById('perm-tab-online').classList.toggle('active', tab === 'online');
  document.getElementById('perm-tab-offline').classList.toggle('active', tab === 'offline');
  document.getElementById('perm-player-list-online').style.display = tab === 'online' ? '' : 'none';
  document.getElementById('perm-player-list-offline').style.display = tab === 'offline' ? '' : 'none';
}

function togglePermPlayer(steamid, name) {
  const idx = permSelectedPlayers.indexOf(steamid);
  if (idx >= 0) {
    permSelectedPlayers.splice(idx, 1);
  } else {
    permSelectedPlayers.push(steamid);
  }
  renderPermPlayerItems();
  updatePermSelectedInfo();
}

function updatePermSelectedInfo() {
  const info = document.getElementById('perm-selected-info');
  if (permSelectedPlayers.length === 0) {
    info.className = 'perm-selected-info none-selected';
    info.innerHTML = '<span>⚠️</span> 尚未选择任何玩家，请从上方列表中选择';
  } else {
    info.className = 'perm-selected-info';
    info.innerHTML = `<span>✅</span> 已选择 ${permSelectedPlayers.length} 名玩家: <b>${permSelectedPlayers.join(', ')}</b>`;
  }
}

function renderPermPlayerItems() {
  const listOnline = document.getElementById('perm-player-list-online');
  const listOffline = document.getElementById('perm-player-list-offline');
  const search = document.getElementById('perm-player-search').value.toLowerCase();

  const onlineFiltered = state.players.filter(p =>
    (p.DisplayName||p.Name||'').toLowerCase().includes(search) || (p.SteamID||'').includes(search)
  );
  const offlineFiltered = state.offlinePlayers || [];

  const renderList = (players, listEl, isOnline) => {
    if (!players.length) {
      listEl.innerHTML = `<div class="perm-player-empty">${isOnline ? '暂无在线玩家' : '暂无曾玩玩家记录'}</div>`;
      return;
    }
    listEl.innerHTML = players.map(p => {
      const selected = permSelectedPlayers.includes(p.SteamID);
      return `<div class="perm-player-item ${selected ? 'selected' : ''}" onclick="togglePermPlayer('${p.SteamID}','${escAttr(p.DisplayName||p.Name||'')}')">
        <div class="perm-player-avatar">👤</div>
        <div class="perm-player-info">
          <div class="perm-player-name">${escHtml(p.DisplayName||p.Name||'?')}</div>
          <div class="perm-player-steamid">${p.SteamID||'-'}</div>
        </div>
        <div class="perm-player-badges">
          <span class="perm-player-badge ${isOnline ? 'perm-badge-online' : 'perm-badge-offline'}">${isOnline ? '在线' : '离线'}</span>
          ${selected ? '<span class="perm-player-badge perm-badge-selected">已选</span>' : ''}
        </div>
      </div>`;
    }).join('');
  };

  renderList(onlineFiltered, listOnline, true);
  renderList(offlineFiltered.filter(p =>
    (p.DisplayName||p.Name||'').toLowerCase().includes(search) || (p.SteamID||'').includes(search)
  ), listOffline, false);
}

async function refreshPermOnline() {
  if (!state.connected) return;
  const r = await api.getPlayers();
  if (r.ok) state.players = r.players || [];
  renderPermPlayerItems();
}

async function refreshPermOffline() {
  const r = await api.getOfflinePlayers();
  state.offlinePlayers = (r && r.players) ? r.players : [];
  renderPermPlayerItems();
}

function renderPermGrid() {
  const grid = document.getElementById('perm-perm-grid');
  let html = '<div style="display:grid;grid-template-columns:1fr 1fr;gap:8px">';
  PERM_OPTIONS.forEach(group => {
    html += `<div style="background:var(--bg-input);border:1px solid var(--border);border-radius:var(--radius);padding:10px">
      <div style="font-size:11px;font-weight:600;color:var(--accent);margin-bottom:8px;text-transform:uppercase;letter-spacing:0.5px">${group.name}</div>`;
    group.perms.forEach(perm => {
      const selected = permSelectedPerms.includes(perm.value);
      html += `<div class="perm-perm-item ${selected ? 'selected' : ''}" onclick="togglePerm('${perm.value}')">
        <span class="perm-perm-name">${perm.label}</span>
        <div class="perm-perm-check">${selected ? '✓' : ''}</div>
      </div>`;
    });
    html += '</div>';
  });
  html += '</div>';
  grid.innerHTML = html;
}

function togglePerm(permValue) {
  const idx = permSelectedPerms.indexOf(permValue);
  if (idx >= 0) permSelectedPerms.splice(idx, 1);
  else permSelectedPerms.push(permValue);
  renderPermGrid();
}

async function permGrantSelected() {
  if (!state.connected) { toast('请先连接服务器', 'error'); return; }
  if (!permSelectedPlayers.length) { toast('请先选择玩家', 'error'); return; }
  if (!permSelectedPerms.length) { toast('请先选择要授予的权限', 'error'); return; }
  for (const sid of permSelectedPlayers) {
    for (const p of permSelectedPerms) {
      await api.rconCommand(`oxide.grant user ${sid} ${p}`);
    }
  }
  showPermResult(`已授予 ${permSelectedPlayers.length} 名玩家 ${permSelectedPerms.length} 项权限`, true);
}

async function permRevokeSelected() {
  if (!state.connected) { toast('请先连接服务器', 'error'); return; }
  if (!permSelectedPlayers.length) { toast('请先选择玩家', 'error'); return; }
  if (!permSelectedPerms.length) { toast('请先选择要撤销的权限', 'error'); return; }
  for (const sid of permSelectedPlayers) {
    for (const p of permSelectedPerms) {
      await api.rconCommand(`oxide.revoke user ${sid} ${p}`);
    }
  }
  showPermResult(`已撤销 ${permSelectedPlayers.length} 名玩家的 ${permSelectedPerms.length} 项权限`, true);
}

async function permAddAdmin() {
  if (!state.connected) { toast('请先连接服务器', 'error'); return; }
  if (!permSelectedPlayers.length) { toast('请先选择玩家', 'error'); return; }
  for (const sid of permSelectedPlayers) {
    await api.rconCommand(`oxide.usergroup add ${sid} admin`);
  }
  showPermResult(`已将 ${permSelectedPlayers.length} 名玩家设为管理员`, true);
}

async function permRemoveAdmin() {
  if (!state.connected) { toast('请先连接服务器', 'error'); return; }
  if (!permSelectedPlayers.length) { toast('请先选择玩家', 'error'); return; }
  for (const sid of permSelectedPlayers) {
    await api.rconCommand(`oxide.usergroup remove ${sid} admin`);
  }
  showPermResult(`已移除 ${permSelectedPlayers.length} 名玩家的管理员权限`, true);
}

async function permCustomGrant() {
  if (!state.connected) { toast('请先连接服务器', 'error'); return; }
  if (!permSelectedPlayers.length) { toast('请先选择玩家', 'error'); return; }
  const code = document.getElementById('perm-custom-code').value.trim();
  if (!code) { toast('请输入权限代码', 'error'); return; }
  for (const sid of permSelectedPlayers) {
    await api.rconCommand(`oxide.grant user ${sid} ${code}`);
  }
  showPermResult(`已授予自定义权限 ${code} 给 ${permSelectedPlayers.length} 名玩家`, true);
}

async function permGiveCoins() {
  if (!state.connected) { toast('请先连接服务器', 'error'); return; }
  if (!permSelectedPlayers.length) { toast('请先选择玩家', 'error'); return; }
  const amount = document.getElementById('perm-coins').value.trim();
  if (!amount) { toast('请输入金币数量', 'error'); return; }
  for (const sid of permSelectedPlayers) {
    await api.rconCommand(`economics.deposit ${sid} ${amount}`);
  }
  showPermResult(`已向 ${permSelectedPlayers.length} 名玩家发放 ${amount} 金币`, true);
}

async function permGivePoints() {
  if (!state.connected) { toast('请先连接服务器', 'error'); return; }
  if (!permSelectedPlayers.length) { toast('请先选择玩家', 'error'); return; }
  const amount = document.getElementById('perm-points').value.trim();
  if (!amount) { toast('请输入积分数量', 'error'); return; }
  for (const sid of permSelectedPlayers) {
    await api.rconCommand(`sr add ${sid} ${amount}`);
  }
  showPermResult(`已向 ${permSelectedPlayers.length} 名玩家发放 ${amount} 积分`, true);
}

// ===== 管理员指令面板（新版 adm-cmd-* 布局） =====
const ADM_CMD_PARAM_LABELS = {
  steamid: 'Steam ID',
  shortname: '物品 shortname',
  amount: '数量',
  message: '广播内容',
  reason: '原因',
  item: '物品 shortname',
  minutes: '时长（分钟）',
  name: '玩家名称',
  hour: '时间（0–24 点）',
  x: '坐标 X',
  y: '坐标 Y',
  z: '坐标 Z',
  v: '数值（如 0–1）',
  n: '数值',
  bool: 'true / false',
  plugin: '插件名（不要带 .cs）'
};

function admCmdParamLabel(key) {
  return ADM_CMD_PARAM_LABELS[key] || key;
}

function admCmdRowIcon(cmd, catIcon) {
  if (cmd && cmd.icon) return cmd.icon;
  const n = (cmd && cmd.name) ? cmd.name : '';
  if (/保存|save/i.test(n)) return '💾';
  if (/列表|list|banlist|playerlist/i.test(n)) return '📋';
  if (/广播|^say|全服/i.test(n)) return '📣';
  if (/oxide|插件|reload|unload|^加载|^卸载/i.test(n)) return '🔌';
  if (/踢|封|解|禁言|mute|旁观|spectate/i.test(n)) return '👤';
  if (/传|坐标|teleport|领地/i.test(n)) return '📍';
  if (/时间|雨|雾|天气|队伍|env\.|maxteam/i.test(n)) return '🌤';
  if (/主机名|hostname|npc|quit|进程|关服/i.test(n)) return '⚙️';
  if (/金币|economics|积分|\bsr\b|给予物品|扣除/i.test(n)) return '🎁';
  if (/版本|oxide\.version/i.test(n)) return '📌';
  return catIcon || '▸';
}

function buildAdminCommandFromRow(btn, template) {
  const card = btn.closest('.adm-cmd-item') || btn.closest('.cmd-card');
  if (!card) return { error: '内部错误' };
  let finalCode = template;
  const quickEl = document.getElementById('cmd-quick-steamid');
  const quickSid = quickEl && quickEl.value.trim() ? quickEl.value.trim() : '';
  const inputs = card.querySelectorAll('.adm-cmd-param-input, .cmd-param-input');
  const wrapTextParam = (key, value, tpl) => {
    const k = String(key || '').toLowerCase();
    const raw = String(value || '').trim();
    if (!raw) return raw;
    if (!['message', 'reason', 'name'].includes(k)) return raw;
    // 若模板本身已写成 "{name}" 这种形式，避免二次加引号
    if (String(tpl || '').includes(`"{${key}}"`)) return raw;
    if (/^".*"$/.test(raw)) return raw;
    return `"${raw.replace(/"/g, '\\"')}"`;
  };
  for (const input of inputs) {
    const key = input.dataset.param;
    let val = input.value.trim();
    if (!val && key === 'steamid' && quickSid) val = quickSid;
    if (!val) {
      return { error: `请填写「${input.getAttribute('aria-label') || key}」` };
    }
    val = wrapTextParam(key, val, template);
    const re = new RegExp(`\\{${key}\\}`, 'g');
    finalCode = finalCode.replace(re, val);
  }
  if (/\{[^}]+\}/.test(finalCode)) {
    return { error: '仍有未替换的参数占位符，请检查模板' };
  }
  return { code: finalCode };
}

function filterAdminCmdCards() {
  const q = (document.getElementById('cmd-global-search')?.value || '').toLowerCase().trim();
  const category = (document.getElementById('cmd-category-filter')?.value || 'all').toLowerCase();
  document.querySelectorAll('#cmd-layout .adm-cmd-group').forEach((sec) => {
    const secCat = String(sec.getAttribute('data-category') || '').toLowerCase();
    if (category !== 'all' && secCat !== category) {
      sec.style.display = 'none';
      return;
    }
    let visible = 0;
    sec.querySelectorAll('.adm-cmd-item').forEach((card) => {
      const hay = (card.getAttribute('data-search') || '').toLowerCase();
      const show = !q || hay.includes(q);
      card.classList.toggle('adm-cmd-item-hidden', !show);
      if (show) visible++;
    });
    sec.style.display = visible ? '' : 'none';
  });
}

function getAdminCategoryKey(name) {
  return String(name || '').trim().toLowerCase();
}

function setupAdminCategoryFilter() {
  const el = document.getElementById('cmd-category-filter');
  if (!el) return;
  const old = el.value || 'all';
  const options = ['<option value="all">全部分类</option>'];
  for (const cat of ADMIN_COMMANDS) {
    const label = String(cat.category || '').trim();
    if (!label) continue;
    const key = getAdminCategoryKey(label);
    options.push(`<option value="${escAttr(key)}">${escHtml(label)}</option>`);
  }
  el.innerHTML = options.join('');
  el.value = options.some((x) => x.includes(`value="${old}"`)) ? old : 'all';
}

function applyAdminCompactMode() {
  const compact = !!document.getElementById('cmd-compact-toggle')?.checked;
  const root = document.querySelector('#cmd-layout .adm-cmd-layout');
  if (!root) return;
  root.classList.toggle('adm-cmd-layout-compact', compact);
}

function renderAdminCommands() {
  const layout = document.getElementById('cmd-layout');
  if (!layout) return;
  let html = '<div class="adm-cmd-layout adm-cmd-text-layout">';
  ADMIN_COMMANDS.forEach((cat) => {
    const catKey = getAdminCategoryKey(cat.category);
    html += `<section class="adm-cmd-group" data-category="${escAttr(catKey)}">
      <h2 class="adm-cmd-group-title">
        <span class="adm-cmd-group-ico" aria-hidden="true">${cat.icon}</span>
        <span>${escHtml(cat.category)}</span>
        <span class="adm-cmd-group-count">${cat.commands.length} 条</span>
      </h2>
      <div class="adm-cmd-list">`;
    cat.commands.forEach((cmd) => {
      const seen = new Set();
      const paramList = [];
      const matches = cmd.code.match(/\{([^}]+)\}/g) || [];
      matches.forEach((m) => {
        const name = m.replace(/[{}]/g, '');
        if (!seen.has(name)) {
          seen.add(name);
          paramList.push(name);
        }
      });
      const searchBlob = `${cmd.name} ${cmd.desc || ''} ${cmd.code} ${cmd.example || ''}`.toLowerCase();
      const rowIcon = admCmdRowIcon(cmd, cat.icon);
      let paramsHtml = '';
      if (paramList.length) {
        paramsHtml = `<div class="adm-cmd-fields cmd-text-params">${paramList.map((p) => {
          const ph = p === 'steamid' ? '765611989…' : (p === 'bool' ? 'true' : admCmdParamLabel(p));
          const lab = admCmdParamLabel(p);
          return `<label class="adm-cmd-field">
            <span class="adm-cmd-field-caption"><span class="adm-cmd-field-title">${escHtml(lab)}</span><span class="adm-cmd-field-key">{${escHtml(p)}}</span></span>
            <input type="text" class="adm-cmd-param-input cfg-input" data-param="${escAttr(p)}"
              placeholder="${escAttr(ph)}" aria-label="${escAttr(lab + ' ' + p)}" autocomplete="off" spellcheck="false" onclick="event.stopPropagation()">
          </label>`;
        }).join('')}</div>`;
      } else {
        paramsHtml = '<div class="adm-cmd-no-params">无需参数，可直接发送</div>';
      }
      const dangerous = cmd.dangerous ? '1' : '';
      const confirmMsg = (cmd.confirm || '确认执行此指令？').replace(/"/g, '&quot;');
      const codeJs = JSON.stringify(cmd.code);
      const ex = cmd.example != null ? cmd.example : '';
      const exJs = JSON.stringify(ex || cmd.code);
      const tplAttr = escAttr(cmd.code);
      html += `<article class="adm-cmd-item" data-search="${escAttr(searchBlob)}">
        <div class="adm-cmd-head">
          <div class="adm-cmd-ico cmd-text-ico" aria-hidden="true">${rowIcon}</div>
          <div class="adm-cmd-text">
            <h3 class="adm-cmd-title cmd-text-title">${escHtml(cmd.name)}</h3>
            ${cmd.desc ? `<p class="adm-cmd-desc cmd-text-desc">${escHtml(cmd.desc)}</p>` : ''}
          </div>
          <div class="adm-cmd-actions cmd-text-actions">
            <button type="button" class="adm-cmd-btn adm-cmd-btn-primary cmd-send-btn" data-need-confirm="${dangerous}" data-confirm="${confirmMsg}"
              data-template="${tplAttr}">发送指令</button>
            <button type="button" class="adm-cmd-btn adm-cmd-btn-ghost"
              data-template="${tplAttr}" data-action="copy">复制指令</button>
          </div>
        </div>
        ${paramsHtml}
        <div class="adm-cmd-meta cmd-text-meta">
          <div class="adm-cmd-meta-block cmd-text-meta-block">
            <span class="adm-cmd-meta-label">命令</span>
            <code class="adm-cmd-code">${escHtml(cmd.code)}</code>
          </div>
          <div class="adm-cmd-meta-block cmd-text-meta-block">
            <span class="adm-cmd-meta-label">示例</span>
            <code class="adm-cmd-code adm-cmd-code-muted">${escHtml(ex)}</code>
          </div>
        </div>
      </article>`;
    });
    html += '</div></section>';
  });
  html += '</div>';
  layout.innerHTML = html;
  setupAdminCategoryFilter();
  applyAdminCompactMode();
  filterAdminCmdCards();
}

document.getElementById('cmd-global-search')?.addEventListener('input', filterAdminCmdCards);
document.getElementById('cmd-category-filter')?.addEventListener('change', filterAdminCmdCards);
document.getElementById('cmd-compact-toggle')?.addEventListener('change', applyAdminCompactMode);
document.getElementById('btn-cmd-refresh')?.addEventListener('click', () => {
  renderAdminCommands();
  toast('指令列表已刷新', 'info');
});

async function writeClipboardCompat(text) {
  const v = String(text || '');
  if (!v) return false;
  try {
    await navigator.clipboard.writeText(v);
    return true;
  } catch {}
  try {
    const ta = document.createElement('textarea');
    ta.value = v;
    ta.setAttribute('readonly', 'readonly');
    ta.style.position = 'fixed';
    ta.style.left = '-9999px';
    ta.style.top = '-9999px';
    document.body.appendChild(ta);
    ta.select();
    const ok = document.execCommand && document.execCommand('copy');
    document.body.removeChild(ta);
    return !!ok;
  } catch {}
  return false;
}

async function copyAdminCmdSmart(btn, template) {
  const built = buildAdminCommandFromRow(btn, template);
  const txt = built && built.code ? built.code : String(template || '');
  const ok = await writeClipboardCompat(txt);
  if (ok) toast('已复制指令', 'success');
  else toast('复制失败：系统剪贴板不可用', 'error');
}

// 管理员指令：事件委托（避免 inline onclick 在部分环境失效）
document.getElementById('cmd-layout')?.addEventListener('click', (e) => {
  const btn = e.target.closest('button');
  if (!btn) return;
  const tpl = btn.getAttribute('data-template');
  if (!tpl) return;
  if (btn.classList.contains('cmd-send-btn')) {
    sendAdminCmdWithParams(btn, tpl);
    return;
  }
  if (btn.getAttribute('data-action') === 'copy') {
    copyAdminCmdSmart(btn, tpl);
  }
});

// 兜底：仍允许外部/控制台调用
window.sendAdminCmdWithParams = sendAdminCmdWithParams;
window.copyAdminCmdSmart = copyAdminCmdSmart;

function appendAdminCmdOutput(cmd, r) {
  const ta = document.getElementById('admincmd-output');
  if (!ta) return;
  const ts = new Date().toLocaleTimeString('zh-CN', { hour12: false });
  const status = !r ? '失败' : (r.ok ? (r.timeout ? '超时' : '成功') : '失败');
  const body = (!r || !r.ok)
    ? String(r?.error || '未知错误')
    : (r.timeout ? '命令超时（服务器未及时回包）' : String(r.message || '(无回包，命令可能已执行)'));
  ta.value = `${ta.value}${ta.value ? '\n\n' : ''}[${ts}] ${status}\n> ${cmd}\n${body}`.trim();
  ta.scrollTop = ta.scrollHeight;
}

async function sendAdminCmdWithParams(btn, template) {
  if (!state.connected) { toast('请先连接服务器', 'error'); return; }
  if (btn.dataset.needConfirm === '1') {
    const msg = btn.getAttribute('data-confirm') || '确认执行？';
    if (!confirm(msg)) return;
  }
  const built = buildAdminCommandFromRow(btn, template);
  if (built.error) { toast(built.error, 'error'); return; }
  const oldText = btn.textContent;
  btn.disabled = true;
  btn.textContent = '发送中...';
  try {
    const r = await api.rconCommand(built.code);
    appendAdminCmdOutput(built.code, r);
    if (r && r.ok && !r.timeout) toast(`已发送: ${built.code.length > 56 ? built.code.slice(0, 56) + '…' : built.code}`, 'success');
    else if (r && r.timeout) toast('命令已发送但服务器回包超时', 'info');
    else toast('发送失败: ' + ((r && r.error) || '未知错误'), 'error');
  } finally {
    btn.disabled = false;
    btn.textContent = oldText || '发送指令';
  }
}

document.getElementById('btn-copy-admincmd-output')?.addEventListener('click', async () => {
  const ta = document.getElementById('admincmd-output');
  const v = ta?.value || '';
  if (!v.trim()) { toast('没有可复制的内容', 'error'); return; }
  await navigator.clipboard.writeText(v);
  toast('已复制执行结果', 'success');
});
document.getElementById('btn-clear-admincmd-output')?.addEventListener('click', () => {
  const ta = document.getElementById('admincmd-output');
  if (ta) ta.value = '';
});

// 支持直接点击代码块复制（除手动框选复制外）
document.getElementById('cmd-layout')?.addEventListener('click', async (e) => {
  const codeEl = e.target.closest('.adm-cmd-code');
  if (!codeEl) return;
  const txt = (codeEl.textContent || '').trim();
  if (!txt) return;
  try {
    await navigator.clipboard.writeText(txt);
    toast('代码已复制', 'success');
  } catch {}
});

// 玩家授权搜索
document.getElementById('perm-player-search')?.addEventListener('input', renderPermPlayerItems);

// ===== 物品发放系统 =====
// 全量物品见 renderer/rust_items.json（与 RustLabs 分类对应），进入本页时加载
let rustItemCatalog = [];
let rustItemCatalogPromise = null;
const ITEMSHOP_PRESET_KEY = 'rustadmin-item-presets';
// 兜底补充：若 rust_items.json 缺失这些常用项，会自动并入
const ITEMSHOP_SUPPLEMENT_ITEMS = [
  { name: 'Assault Rifle', shortname: 'rifle.ak', cat: 'weapon', image: 'https://rustlabs.com/img/items180/rifle.ak.png' },
  { name: 'LR-300 Assault Rifle', shortname: 'rifle.lr300', cat: 'weapon', image: 'https://rustlabs.com/img/items180/rifle.lr300.png' },
  { name: 'M39 Rifle', shortname: 'rifle.m39', cat: 'weapon', image: 'https://rustlabs.com/img/items180/rifle.m39.png' },
  { name: 'L96 Rifle', shortname: 'rifle.l96', cat: 'weapon', image: 'https://rustlabs.com/img/items180/rifle.l96.png' },
  { name: 'M249', shortname: 'lmg.m249', cat: 'weapon', image: 'https://rustlabs.com/img/items180/lmg.m249.png' },
  { name: 'HMLMG', shortname: 'hmlmg', cat: 'weapon', image: 'https://rustlabs.com/img/items180/hmlmg.png' },
  { name: 'MP5A4', shortname: 'smg.mp5', cat: 'weapon', image: 'https://rustlabs.com/img/items180/smg.mp5.png' },
  { name: 'Pistol Bullet', shortname: 'ammo.pistol', cat: 'ammo', image: 'https://rustlabs.com/img/items180/ammo.pistol.png' },
  { name: '5.56 Rifle Ammo', shortname: 'ammo.rifle', cat: 'ammo', image: 'https://rustlabs.com/img/items180/ammo.rifle.png' },
  { name: 'Explosive 5.56 Rifle Ammo', shortname: 'ammo.rifle.explosive', cat: 'ammo', image: 'https://rustlabs.com/img/items180/ammo.rifle.explosive.png' },
  { name: 'High Velocity 5.56 Rifle Ammo', shortname: 'ammo.rifle.hv', cat: 'ammo', image: 'https://rustlabs.com/img/items180/ammo.rifle.hv.png' },
  { name: 'Rocket', shortname: 'ammo.rocket.basic', cat: 'ammo', image: 'https://rustlabs.com/img/items180/ammo.rocket.basic.png' }
];

function readItemPresets() {
  try {
    const raw = localStorage.getItem(ITEMSHOP_PRESET_KEY);
    const arr = JSON.parse(raw || '[]');
    return Array.isArray(arr) ? arr : [];
  } catch {
    return [];
  }
}

function writeItemPresets(presets) {
  try {
    localStorage.setItem(ITEMSHOP_PRESET_KEY, JSON.stringify(Array.isArray(presets) ? presets : []));
    return true;
  } catch {
    return false;
  }
}

function mapLabsCategoryToShopCat(labs) {
  const L = String(labs || '').toLowerCase();
  if (L === 'weapon') return 'weapon';
  if (L === 'ammunition') return 'ammo';
  if (L === 'attire') return 'armor';
  if (L === 'medical') return 'medical';
  if (L === 'component' || L === 'resources') return 'resource';
  return 'tool';
}

/** 仅允许 RustLabs CDN，避免任意 URL 注入 */
function safeRustItemImageUrl(url) {
  if (!url || typeof url !== 'string') return '';
  const u = url.trim();
  if (!/^https:\/\//i.test(u)) return '';
  try {
    const host = new URL(u).hostname.toLowerCase();
    if (host === 'rustlabs.com' || host.endsWith('.rustlabs.com')) return u;
  } catch {}
  return '';
}

function itemShopIconCellHtml(item) {
  const url = safeRustItemImageUrl(item.image || '');
  const emoji = getItemEmoji(item.cat);
  if (!url) {
    return `<div class="itemshop-item-icon">${emoji}</div>`;
  }
  /* 仅保留一种主视觉：图片 onload 后隐藏 emoji，避免透明 PNG 与旧 emoji 叠在一起 */
  return `<div class="itemshop-item-icon-wrap">
    <span class="itemshop-item-icon-fallback">${emoji}</span>
    <img class="itemshop-item-img" src="${escHtml(url)}" alt="" loading="lazy" decoding="async" referrerpolicy="no-referrer"
      onload="var p=this.previousElementSibling;if(p)p.style.display='none';"
      onerror="this.style.display='none';">
  </div>`;
}

function getItemShopCatalogMeta(shortname) {
  return rustItemCatalog.find(i => i.shortname === shortname);
}

function getItemShopCatalog() {
  return rustItemCatalog;
}

async function ensureRustItemCatalog() {
  if (rustItemCatalog.length) return rustItemCatalog;
  if (!rustItemCatalogPromise) {
    rustItemCatalogPromise = fetch('rust_items.json')
      .then(r => {
        if (!r.ok) throw new Error('HTTP ' + r.status);
        return r.json();
      })
      .then(data => {
        const seen = new Set();
        const out = [];
        for (const row of data) {
          const sn = String(row.shortName || row.shortname || '').trim();
          if (!sn || seen.has(sn)) continue;
          seen.add(sn);
          out.push({
            id: row.id != null ? String(row.id) : '',
            name: row.displayName || row.name || sn,
            shortname: sn,
            cat: mapLabsCategoryToShopCat(row.category),
            image: safeRustItemImageUrl(row.image)
          });
        }
        for (const s of ITEMSHOP_SUPPLEMENT_ITEMS) {
          const sn = String(s.shortname || '').trim();
          if (!sn || seen.has(sn)) continue;
          seen.add(sn);
          out.push({
            id: s.id != null ? String(s.id) : '',
            name: s.name || sn,
            shortname: sn,
            cat: s.cat || 'tool',
            image: safeRustItemImageUrl(s.image || '')
          });
        }
        out.sort((a, b) => a.name.localeCompare(b.name, 'en'));
        rustItemCatalog = out;
        return out;
      })
      .catch(e => {
        console.error('rust_items.json', e);
        toast('物品目录加载失败，请检查 rust_items.json 或使用下方手动输入', 'error');
        rustItemCatalog = [];
        return [];
      });
  }
  return rustItemCatalogPromise;
}

function syncItemShopAfterPlayersRefresh() {
  const panel = document.getElementById('panel-itemshop');
  if (!panel || !panel.classList.contains('active')) return;
  const onlineIds = new Set(state.players.map(p => p.SteamID));
  if (itemShopState.targetMode === 'online') {
    itemShopState.selectedPlayers = itemShopState.selectedPlayers.filter(id => onlineIds.has(id));
    renderItemShopPlayerList();
  } else {
    const playerList = document.getElementById('itemshop-player-list');
    const targetInfo = document.getElementById('itemshop-target-info');
    if (playerList) {
      playerList.innerHTML = '<div class="itemshop-all-hint">将发放给全体在线玩家（人数随列表刷新更新）</div>';
    }
    if (targetInfo) {
      targetInfo.innerHTML = '目标：<b>全体在线玩家</b>（<b id="item-target-count">' + state.players.length + '</b> 名）';
    }
  }
  updateItemShopSummary();
}

function setupItemShopGridDelegation() {
  const grid = document.getElementById('itemshop-items-grid');
  if (!grid || grid._itemShopDelegated) return;
  grid._itemShopDelegated = true;
  grid.addEventListener('click', (e) => {
    const card = e.target.closest('.itemshop-item');
    if (!card) return;
    const sn = card.dataset.shortname;
    const nm = card.dataset.name;
    if (!sn) return;
    toggleItemSelection(sn, nm || sn);
  });
}

function addCustomShortnameToSelection() {
  const input = document.getElementById('item-custom-shortname');
  const v = (input && input.value) ? input.value.trim() : '';
  if (!v) {
    toast('请输入 shortname', 'error');
    return;
  }
  if (itemShopState.selectedItems.some(i => i.shortname === v)) {
    toast('已在已选列表中', 'info');
    return;
  }
  const meta = rustItemCatalog.find(i => i.shortname === v);
  itemShopState.selectedItems.push({
    shortname: v,
    name: meta ? meta.name : v,
    quantity: 1,
    image: meta && meta.image ? meta.image : ''
  });
  if (input) input.value = '';
  renderItemShopGrid();
  renderItemShopSelectedList();
  updateItemShopSummary();
}

// 物品发放状态
let itemShopState = {
  selectedItems: [], // [{shortname, name, quantity}]
  selectedPlayers: [], // [steamid]
  targetMode: 'online', // 'online' | 'all'
  currentCategory: 'all',
  itemSearch: '',
  presets: []
};

// 切换物品分类
function switchItemCat(cat) {
  itemShopState.currentCategory = cat;
  document.querySelectorAll('.itemshop-tab-btn').forEach(btn => {
    btn.classList.toggle('active', btn.dataset.cat === cat);
  });
  renderItemShopGrid();
}

// 切换目标模式
function switchItemTarget(mode) {
  itemShopState.targetMode = mode;
  const playerList = document.getElementById('itemshop-player-list');
  const targetInfo = document.getElementById('itemshop-target-info');
  const sidEl = document.getElementById('item-target-steamid');
  
  if (mode === 'all') {
    // 若填写了 SteamID，则强制走单人发放，避免误用全服逻辑
    const sid = String(sidEl?.value || '').trim();
    if (/^\d{10,20}$/.test(sid)) {
      itemShopState.targetMode = 'online';
      const radioOnline = document.querySelector('input[name="item-target"][value="online"]');
      if (radioOnline) radioOnline.checked = true;
      toast('已填写 SteamID：将按单人发放（不走全服）', 'info');
      renderItemShopPlayerList();
      updateItemShopSummary();
      return;
    }
    itemShopState.selectedPlayers = [];
    if (playerList) playerList.innerHTML = '<div class="itemshop-all-hint">将发放给全体在线玩家（人数随列表刷新更新）</div>';
    if (targetInfo) targetInfo.innerHTML = '目标：<b>全体在线玩家</b>（<b id="item-target-count">' + state.players.length + '</b> 名）';
  } else {
    itemShopState.selectedPlayers = [];
    renderItemShopPlayerList();
  }
  updateItemShopSummary();
}

// 渲染物品选择网格
function renderItemShopGrid() {
  const grid = document.getElementById('itemshop-items-grid');
  if (!grid) return;
  setupItemShopGridDelegation();
  const search = (document.getElementById('item-search')?.value || '').toLowerCase();
  itemShopState.itemSearch = search;
  const catalog = getItemShopCatalog();
  if (!catalog.length) {
    grid.innerHTML = '<div class="itemshop-empty-hint">正在加载物品目录…</div>';
    updateItemSelectedCount();
    return;
  }

  let filtered = catalog;
  if (itemShopState.currentCategory !== 'all') {
    filtered = filtered.filter(i => i.cat === itemShopState.currentCategory);
  }
  if (search) {
    filtered = filtered.filter(i => {
      const nm = String(i.name != null ? i.name : '').toLowerCase();
      const sn = String(i.shortname != null ? i.shortname : '').toLowerCase();
      return nm.includes(search) || sn.includes(search);
    });
  }

  const hint = (!search && itemShopState.currentCategory === 'all' && filtered.length > 400)
    ? '<div class="itemshop-catalog-hint">共 ' + filtered.length + ' 条，建议用分类或搜索缩小范围</div>'
    : '';

  grid.innerHTML = hint + filtered.map(item => {
    const selected = itemShopState.selectedItems.find(i => i.shortname === item.shortname);
    return `<div class="itemshop-item ${selected ? 'selected' : ''}" data-shortname="${escHtml(item.shortname)}" data-name="${escHtml(item.name)}">
      ${itemShopIconCellHtml(item)}
      <div class="itemshop-item-name">${escHtml(item.name)}</div>
      <div class="itemshop-item-shortname">${escHtml(item.shortname)}</div>
      ${selected ? `<span class="itemshop-item-badge">✓</span>` : ''}
    </div>`;
  }).join('');

  updateItemSelectedCount();
}

// 获取物品 emoji（无图标 URL 或图片加载失败时显示）
function getItemEmoji(cat) {
  const emojis = {
    weapon: '🔫',
    ammo: '💣',
    armor: '🛡️',
    resource: '⛏️',
    tool: '🔧',
    medical: '💊'
  };
  return emojis[cat] || '📦';
}

// 切换物品选择
function toggleItemSelection(shortname, name) {
  const idx = itemShopState.selectedItems.findIndex(i => i.shortname === shortname);
  if (idx >= 0) {
    itemShopState.selectedItems.splice(idx, 1);
  } else {
    const meta = getItemShopCatalogMeta(shortname);
    itemShopState.selectedItems.push({
      shortname,
      name,
      quantity: 1,
      image: meta && meta.image ? meta.image : ''
    });
  }
  renderItemShopGrid();
  renderItemShopSelectedList();
  updateItemShopSummary();
}

// 渲染已选物品列表
function renderItemShopSelectedList() {
  const list = document.getElementById('itemshop-selected-list');
  if (!list) return;
  if (!itemShopState.selectedItems.length) {
    list.innerHTML = '<div class="itemshop-empty-hint">👈 请从左侧选择要发放的物品</div>';
    return;
  }
  
  list.innerHTML = itemShopState.selectedItems.map(item => {
    const url = safeRustItemImageUrl(item.image || '') || (getItemShopCatalogMeta(item.shortname)?.image || '');
    const safeUrl = safeRustItemImageUrl(url);
    const cat = getItemShopCatalogMeta(item.shortname)?.cat || 'tool';
    const emoji = getItemEmoji(cat);
    const thumb = `<span class="itemshop-selected-thumb-inner">
      <span class="itemshop-selected-thumb-fallback">${emoji}</span>
      ${safeUrl ? `<img class="itemshop-selected-thumb" src="${escHtml(safeUrl)}" alt="" loading="lazy" referrerpolicy="no-referrer"
        onload="var p=this.previousElementSibling;if(p)p.style.display='none';"
        onerror="this.style.display='none';">` : ''}
    </span>`;
    return `
    <div class="itemshop-selected-item">
      <span class="itemshop-selected-thumb-cell">${thumb}</span>
      <span class="itemshop-selected-name">${escHtml(item.name)}</span>
      <div class="itemshop-selected-qty">
        <label>数量:</label>
        <input type="number" class="cfg-input cfg-input-xs item-qty-input"
          data-shortname="${escAttr(item.shortname)}"
          value="${item.quantity}" min="1">
      </div>
      <button type="button" class="itemshop-remove-btn" data-remove-shortname="${escAttr(item.shortname)}">✕</button>
    </div>`;
  }).join('');
}

// 更新物品数量
function updateItemQuantity(shortname, qty) {
  const item = itemShopState.selectedItems.find(i => i.shortname === shortname);
  if (item) {
    item.quantity = Math.max(1, parseInt(qty) || 1);
    updateItemShopSummary();
  }
}

function syncSelectedItemQuantitiesFromDom() {
  const list = document.getElementById('itemshop-selected-list');
  if (!list) return;
  list.querySelectorAll('.item-qty-input').forEach((el) => {
    const sn = String(el.getAttribute('data-shortname') || '').trim();
    if (!sn) return;
    updateItemQuantity(sn, el.value);
  });
}

// 从选择中移除物品
function removeItemFromSelection(shortname) {
  const idx = itemShopState.selectedItems.findIndex(i => i.shortname === shortname);
  if (idx >= 0) {
    itemShopState.selectedItems.splice(idx, 1);
    renderItemShopGrid();
    renderItemShopSelectedList();
    updateItemShopSummary();
  }
}

// 更新已选物品计数
function updateItemSelectedCount() {
  const el = document.getElementById('item-selected-count');
  if (el) el.textContent = `已选 ${itemShopState.selectedItems.length} 种物品`;
}

// 批量设置数量
function setBulkQuantity() {
  const bulkEl = document.getElementById('bulk-quantity');
  const qty = Math.max(1, parseInt(bulkEl && bulkEl.value) || 1);
  itemShopState.selectedItems.forEach(item => item.quantity = qty);
  renderItemShopSelectedList();
  updateItemShopSummary();
  toast(`已将所有物品数量设为 ${qty}`, 'info');
}

// 渲染玩家选择列表
function renderItemShopPlayerList() {
  const list = document.getElementById('itemshop-player-list');
  const targetInfo = document.getElementById('itemshop-target-info');
  if (!list || !targetInfo) return;
  
  if (!state.players.length) {
    list.innerHTML = '<div class="itemshop-empty-hint">暂无在线玩家</div>';
    targetInfo.innerHTML = '已选择 <b id="item-target-count">0</b> 名玩家';
    return;
  }
  
  list.innerHTML = state.players.map(p => {
    const selected = itemShopState.selectedPlayers.includes(p.SteamID);
    return `<div class="itemshop-player-item ${selected ? 'selected' : ''}" 
      onclick="toggleItemPlayer('${p.SteamID}')">
      <span class="itemshop-player-check">${selected ? '✓' : ''}</span>
      <span class="itemshop-player-name">${escHtml(p.DisplayName || p.Name || '?')}</span>
      <span class="itemshop-player-sid">${p.SteamID}</span>
    </div>`;
  }).join('');
  
  targetInfo.innerHTML = '已选择 <b id="item-target-count">' + itemShopState.selectedPlayers.length + '</b> 名玩家';
}

// 切换玩家选择
function toggleItemPlayer(steamid) {
  const idx = itemShopState.selectedPlayers.indexOf(steamid);
  if (idx >= 0) {
    itemShopState.selectedPlayers.splice(idx, 1);
  } else {
    itemShopState.selectedPlayers.push(steamid);
  }
  renderItemShopPlayerList();
  updateItemShopSummary();
}

// 更新摘要
function updateItemShopSummary() {
  const itemCount = itemShopState.selectedItems.length;
  let playerCount = 0;
  if (itemShopState.targetMode === 'all') {
    playerCount = state.players.length;
  } else {
    playerCount = itemShopState.selectedPlayers.length;
  }
  const totalCmds = itemCount * playerCount;
  
  const elI = document.getElementById('summary-item-count');
  const elP = document.getElementById('summary-player-count');
  const elT = document.getElementById('summary-total-cmd');
  if (elI) elI.textContent = itemCount;
  if (elP) elP.textContent = playerCount;
  if (elT) elT.textContent = totalCmds;
}

// 发送物品
async function sendItemShopItems() {
  if (!state.connected) { toast('请先连接服务器', 'error'); return; }
  // 发送前强制同步一次输入框数量（避免未失焦时仍用旧值）
  syncSelectedItemQuantitiesFromDom();

  if (!itemShopState.selectedItems.length) {
    toast('请先选择要发放的物品', 'error'); return;
  }

  let targets = [];
  const directSid = String(document.getElementById('item-target-steamid')?.value || '').trim();
  if (/^\d{10,20}$/.test(directSid)) {
    // 明确指定 SteamID 时，强制单人精准发放
    // 同时确保 UI 不会被“全体在线”误导
    itemShopState.targetMode = 'online';
    const radioOnline = document.querySelector('input[name="item-target"][value="online"]');
    if (radioOnline) radioOnline.checked = true;
    targets = [directSid];
  } else if (itemShopState.targetMode === 'all') {
    targets = state.players.map(p => p.SteamID).filter(Boolean);
  } else {
    targets = [...itemShopState.selectedPlayers];
  }

  if (!targets.length) {
    if (itemShopState.targetMode === 'all') {
      toast('当前没有在线玩家，请稍后刷新玩家列表再试', 'error');
    } else {
      toast('请先选择目标玩家', 'error');
    }
    return;
  }
  
  // 确认发放
  const totalCmds = itemShopState.selectedItems.length * targets.length;
  if (!confirm(`确认向 ${targets.length} 名玩家发放 ${itemShopState.selectedItems.length} 种物品（共 ${totalCmds} 次指令）？`)) {
    return;
  }
  
  toast(`开始发放物品...`, 'info');
  appendAdminCmdOutput('itemshop.send', { ok: true, message: `开始执行：玩家 ${targets.length}，物品 ${itemShopState.selectedItems.length}，总计 ${totalCmds} 次` });
  let successCount = 0;
  let failCount = 0;
  let firstFailDetail = '';
  let doneCount = 0;

  const isRconFailureText = (msg) => /unknown command|command not found|invalid|syntax|error|failed|no permission|not allowed/i.test(String(msg || ''));
  const tryGiveItem = async (steamid, shortname, qty) => {
    const meta = getItemShopCatalogMeta(shortname) || {};
    const itemId = String(meta.id || '').trim();
    const sid = String(steamid || '').trim();
    const amount = Math.max(1, parseInt(qty, 10) || 1);

    const cmds = [];
    if (itemShopState.targetMode === 'all' && !directSid) {
      // 全体发放优先走 giveall（部分服仅支持该形式）
      cmds.push(`inventory.giveall ${shortname} ${amount}`);
      cmds.push(`giveall ${shortname} ${amount}`);
    }
    // 单人发放：仅按 SteamID 尝试，避免按名字误发/失败
    // GM命令 1.5：giveto / giveall 是主要口径，优先尝试
    cmds.push(`giveto ${sid} ${shortname} ${amount}`);
    cmds.push(`giveto ${sid} "${shortname}" ${amount}`);
    // 常见顺序变体：giveto <steamid> <amount> <shortname>
    cmds.push(`giveto ${sid} ${amount} ${shortname}`);
    cmds.push(`giveto ${sid} ${amount} "${shortname}"`);
    // 其它兼容（部分服/插件才有）
    cmds.push(`inventory.give ${sid} ${shortname} ${amount}`);
    cmds.push(`inventory.give "${shortname}" ${amount} ${sid}`);
    cmds.push(`inventory.give ${shortname} ${amount} ${sid}`);
    cmds.push(`inv.giveplayer ${sid} ${shortname} ${amount}`);
    cmds.push(`inv.giveplayer ${sid} "${shortname}" ${amount}`);

    if (itemId) {
      cmds.push(`inventory.giveid ${itemId} ${amount} ${sid}`);
    }
    // 去重
    const uniqCmds = [...new Set(cmds.filter(Boolean))];
    let last = null;
    const samples = [];
    for (const c of uniqCmds) {
      let r = null;
      try {
        r = await api.rconCommand(c);
      } catch (e) {
        r = { ok: false, error: e?.message || String(e || 'unknown') };
      }
      last = { cmd: c, res: r };
      if (samples.length < 5) {
        const brief = String(r?.message || r?.error || '').replace(/\s+/g, ' ').slice(0, 120);
        samples.push(`${c} -> ${r && r.ok ? 'ok' : 'fail'} ${brief}`);
      }
      if (r && r.ok && !isRconFailureText(r.message)) return { ok: true, cmd: c, res: r };
    }
    return { ok: false, cmd: last?.cmd || uniqCmds[0], res: last?.res || { ok: false, error: 'unknown' }, samples };
  };
  
  try {
    for (const steamid of targets) {
      for (const item of itemShopState.selectedItems) {
        const rr = await tryGiveItem(steamid, item.shortname, item.quantity);
        if (rr.ok) successCount++;
        else {
          failCount++;
          if (!firstFailDetail) {
            const em = rr?.res?.message || rr?.res?.error || '未知错误';
            firstFailDetail = `${rr?.cmd || 'n/a'} -> ${String(em).slice(0, 120)}`;
          if (rr?.samples?.length) {
            appendAdminCmdOutput('itemshop.try', { ok: false, error: rr.samples.join('\n') });
          }
          }
        }
        doneCount++;
        if (doneCount % 10 === 0 || doneCount === totalCmds) {
          appendAdminCmdOutput('itemshop.progress', { ok: true, message: `进度 ${doneCount}/${totalCmds}，成功 ${successCount}，失败 ${failCount}` });
        }
      }
    }
  } catch (e) {
    const em = e?.message || String(e || '未知错误');
    appendAdminCmdOutput('itemshop.exception', { ok: false, error: em });
    toast('发放中断：' + em, 'error');
    return;
  }
  
  if (failCount === 0) {
    toast(`物品发放完成！成功 ${successCount} 次`, 'success');
    appendAdminCmdOutput('itemshop.done', { ok: true, message: `完成：成功 ${successCount} / ${totalCmds}` });
  } else {
    toast(`发放完成：成功 ${successCount} 次，失败 ${failCount} 次`, 'error');
    appendAdminCmdOutput('itemshop.done', { ok: false, error: `完成：成功 ${successCount}，失败 ${failCount}` });
    if (firstFailDetail) {
      appendAdminCmdOutput('itemshop.send', { ok: false, error: firstFailDetail });
    }
  }
}

// 清空选择
function clearItemShopSelection() {
  itemShopState.selectedItems = [];
  itemShopState.selectedPlayers = [];
  itemShopState.targetMode = 'online';
  const radioOnline = document.querySelector('input[name="item-target"][value="online"]');
  if (radioOnline) radioOnline.checked = true;
  renderItemShopGrid();
  renderItemShopSelectedList();
  renderItemShopPlayerList();
  updateItemShopSummary();
  updateItemSelectedCount();
  toast('已清空所有选择', 'info');
}

// 保存预设
async function saveItemPreset() {
  if (!itemShopState.selectedItems.length) {
    toast('请先选择物品', 'error'); return;
  }
  
  const nameEl = document.getElementById('item-preset-name');
  const typed = String(nameEl?.value || '').trim();
  const autoName = '预设-' + new Date().toLocaleString('zh-CN', { hour12: false }).replace(/[/: ]/g, '-');
  const finalName = typed || autoName;
  
  const preset = {
    name: finalName,
    items: [...itemShopState.selectedItems],
    createdAt: new Date().toISOString()
  };
  
  // 从本地存储加载现有预设
  let presets = readItemPresets();
  presets = presets.filter((p) => p && p.name !== preset.name);
  presets.push(preset);
  if (!writeItemPresets(presets)) {
    toast('预设保存失败（存储写入异常）', 'error');
    return;
  }
  
  itemShopState.presets = presets;
  renderPresetSelect();
  renderPresetList();
  if (nameEl) nameEl.value = '';
  toast(`预设 "${finalName}" 已保存`, 'success');
}

// 加载预设
function loadItemPreset() {
  const select = document.getElementById('item-preset-select');
  const presetName = select.value;
  if (!presetName) return;
  
  const presets = readItemPresets();
  const preset = presets.find(p => p.name === presetName);
  if (!preset) return;
  
  itemShopState.selectedItems = [...preset.items];
  renderItemShopGrid();
  renderItemShopSelectedList();
  updateItemShopSummary();
  toast(`已加载预设 "${presetName}"（${preset.items.length} 种物品）`, 'success');
  select.value = '';
}

// 删除预设
async function deleteItemPreset(name) {
  if (!confirm(`确认删除预设 "${name}"？`)) return;
  
  let presets = readItemPresets();
  presets = presets.filter(p => p.name !== name);
  if (!writeItemPresets(presets)) {
    toast('删除失败（存储写入异常）', 'error');
    return;
  }
  
  itemShopState.presets = presets;
  renderPresetSelect();
  renderPresetList();
  toast(`预设 "${name}" 已删除`, 'info');
}

// 渲染预设选择下拉框
function renderPresetSelect() {
  const select = document.getElementById('item-preset-select');
  if (!select) return;
  const presets = readItemPresets();
  
  select.innerHTML = '<option value="">-- 加载预设 --</option>' + 
    presets.map(p => `<option value="${p.name}">${p.name} (${p.items.length}种)</option>`).join('');
}

// 渲染预设列表
function renderPresetList() {
  const list = document.getElementById('itemshop-preset-list');
  if (!list) return;
  const presets = readItemPresets();
  
  if (!presets.length) {
    list.innerHTML = '<div class="itemshop-preset-empty">暂无保存的预设</div>';
    return;
  }
  
  list.innerHTML = presets.map(p => `
    <div class="itemshop-preset-item">
      <div class="itemshop-preset-name">${p.name}</div>
      <div class="itemshop-preset-info">${p.items.length} 种物品</div>
      <div class="itemshop-preset-actions">
        <button class="cfg-btn cfg-btn-xs" onclick="loadPresetByName('${p.name}')">加载</button>
        <button class="cfg-btn cfg-btn-xs cfg-btn-danger" onclick="deleteItemPreset('${p.name}')">删除</button>
      </div>
    </div>
  `).join('');
}

// 通过名称加载预设
function loadPresetByName(name) {
  const select = document.getElementById('item-preset-select');
  select.value = name;
  loadItemPreset();
}

// 兼容 inline onclick：确保按钮可直接调用
window.saveItemPreset = saveItemPreset;
window.loadItemPreset = loadItemPreset;
window.deleteItemPreset = deleteItemPreset;
window.loadPresetByName = loadPresetByName;
window.sendItemShopItems = sendItemShopItems;
window.clearItemShopSelection = clearItemShopSelection;
window.setBulkQuantity = setBulkQuantity;
window.switchItemTarget = switchItemTarget;
window.switchItemCat = switchItemCat;
window.toggleItemPlayer = toggleItemPlayer;
window.updateItemQuantity = updateItemQuantity;
window.removeItemFromSelection = removeItemFromSelection;

// 物品搜索输入
document.getElementById('item-search')?.addEventListener('input', () => {
  renderItemShopGrid();
});

document.getElementById('item-custom-add')?.addEventListener('click', addCustomShortnameToSelection);
document.getElementById('item-custom-shortname')?.addEventListener('keydown', (e) => {
  if (e.key === 'Enter') addCustomShortnameToSelection();
});

// 填写 SteamID 时，强制单人发放模式（不走全服）
document.getElementById('item-target-steamid')?.addEventListener('input', () => {
  const sidEl = document.getElementById('item-target-steamid');
  const sid = String(sidEl?.value || '').trim();
  if (/^\d{10,20}$/.test(sid)) {
    itemShopState.targetMode = 'online';
    itemShopState.selectedPlayers = [];
    const radioOnline = document.querySelector('input[name="item-target"][value="online"]');
    if (radioOnline) radioOnline.checked = true;
    const targetInfo = document.getElementById('itemshop-target-info');
    if (targetInfo) targetInfo.innerHTML = '目标：<b>SteamID</b>（<b id="item-target-count">1</b> 名）';
    updateItemShopSummary();
  }
});

// 已选物品列表：委托处理“删项 / 数量变更”
document.getElementById('itemshop-selected-list')?.addEventListener('click', (e) => {
  const btn = e.target.closest('.itemshop-remove-btn');
  if (!btn) return;
  const sn = String(btn.getAttribute('data-remove-shortname') || '').trim();
  if (!sn) return;
  removeItemFromSelection(sn);
});
document.getElementById('itemshop-selected-list')?.addEventListener('input', (e) => {
  const inp = e.target.closest('.item-qty-input');
  if (!inp) return;
  const sn = String(inp.getAttribute('data-shortname') || '').trim();
  if (!sn) return;
  updateItemQuantity(sn, inp.value);
});

// 初始化物品发放Tab
function initItemShop() {
  itemShopState.presets = readItemPresets();
  setupItemShopGridDelegation();
  renderItemShopGrid();
  renderItemShopPlayerList();
  renderPresetSelect();
  renderPresetList();
  updateItemShopSummary();
  syncItemShopAfterPlayersRefresh();
  ensureRustItemCatalog()
    .then(() => {
      renderItemShopGrid();
      updateItemShopSummary();
    })
    .catch(e => {
      console.error('[RustAdmin] rust_items.json', e);
      toast('物品目录加载异常，可用手动输入 shortname', 'error');
    });
}

// ===== 开发者模式（密码保护） =====
let devPanelVisible = false;

// 开发者密码弹窗事件
document.addEventListener('keydown', async (e) => {
  // Ctrl+Shift+D 打开开发者密码弹窗
  if (e.ctrlKey && e.shiftKey && e.key === 'D') {
    e.preventDefault();
    openDevPasswordModal();
  }
});

// 打开密码验证弹窗
function openDevPasswordModal() {
  document.getElementById('dev-password-modal').style.display = 'flex';
  document.getElementById('dev-password-input').value = '';
  document.getElementById('dev-password-error').style.display = 'none';
  document.getElementById('dev-config-panel').style.display = 'none';
  document.querySelector('.dev-modal').style.display = 'block';
  document.getElementById('dev-password-input').focus();
}

// 关闭开发者弹窗
document.getElementById('btn-close-dev-modal')?.addEventListener('click', () => {
  document.getElementById('dev-password-modal').style.display = 'none';
  devPanelVisible = false;
});

document.getElementById('btn-close-dev-config')?.addEventListener('click', () => {
  document.getElementById('dev-password-modal').style.display = 'none';
  devPanelVisible = false;
});

// 密码验证
document.getElementById('btn-verify-dev-password')?.addEventListener('click', verifyDevPassword);
document.getElementById('dev-password-input')?.addEventListener('keydown', (e) => {
  if (e.key === 'Enter') verifyDevPassword();
});

async function verifyDevPassword() {
  const password = document.getElementById('dev-password-input').value;
  const errorEl = document.getElementById('dev-password-error');
  
  const result = await api.devVerifyPassword(password);
  
  if (result.ok) {
    errorEl.style.display = 'none';
    document.querySelector('.dev-modal').style.display = 'none';
    document.getElementById('dev-config-panel').style.display = 'block';
    devPanelVisible = true;
    
    // 加载配置
    document.getElementById('dev-qqbot-url').value = result.config.qqBotUrl || '';
    updateDevReportStatus(result.config.hasReportedFirstUse);
  } else {
    errorEl.style.display = 'flex';
    document.getElementById('dev-password-input').value = '';
    document.getElementById('dev-password-input').focus();
  }
}

// 更新上报状态显示
function updateDevReportStatus(reported) {
  const dot = document.querySelector('.dev-status-dot');
  const text = document.getElementById('dev-report-text');
  if (!text) return;
  if (reported) {
    dot?.classList.add('active');
    text.textContent = '已上报（' + new Date().toLocaleString('zh-CN') + '）';
  } else {
    dot?.classList.remove('active');
    text.textContent = '未上报';
  }
}

// 测试 QQ 机器人
document.getElementById('btn-test-qqbot')?.addEventListener('click', async () => {
  const url = document.getElementById('dev-qqbot-url').value.trim();
  if (!url) { toast('请输入 QQ 机器人地址', 'error'); return; }
  toast('正在测试...', 'info', 5000);
  const result = await api.devTestQqBot(url);
  if (result.ok) toast('QQ 机器人连接成功！', 'success');
  else toast('连接失败: ' + (result.error || 'HTTP ' + result.status), 'error');
});

// 保存开发者配置
document.getElementById('btn-save-dev-config')?.addEventListener('click', async () => {
  const qqBotUrl = document.getElementById('dev-qqbot-url').value.trim();
  const config = await api.devGetConfig();
  config.qqBotUrl = qqBotUrl;
  await api.devSaveConfig(config);
  toast('配置已保存', 'success');
});

// 重置上报状态（用于测试）
document.getElementById('btn-reset-report')?.addEventListener('click', async () => {
  const config = await api.devGetConfig();
  config.hasReportedFirstUse = false;
  await api.devSaveConfig(config);
  updateDevReportStatus(false);
  toast('已重置上报状态，重新启动应用后将再次上报', 'info');
});

// ===== 初始化 =====
(async function init() {
  // 加载主题
  const savedTheme = localStorage.getItem('rustadmin-theme');
  applyTheme(savedTheme || 'dark');
  // 初始化新闻
  appendNewsDots();
  // 加载服务器列表
  await loadServerList();
  // 加载使用日志
  loadUsageLog();
  // 每日自动上报（每小时检查一次）
  setInterval(reportUsageToOwner, 3600000);
  toast('RustAdmin 已就绪', 'info', 2000);
})();
