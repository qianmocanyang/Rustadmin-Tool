# PC 端（Electron）

本目录用于放置 PC 端构建入口与说明。

- 入口：`pc/main.js`
- 实际主进程逻辑：`../main.js`
- 预加载脚本：`../preload.js`

常用命令（在项目根目录执行）：

- `npm start`
- `npm run build:nsis`
- `npm run build:portable`
